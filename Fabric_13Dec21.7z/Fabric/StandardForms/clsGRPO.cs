﻿using Fabric.Classes;
using Fabric.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fabric
{
    class clsGRPO : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();


        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "OPDN";
        public const string rowTable = "PDN1";
        public const string objType = "20";
        public const string matrixUID = "38";
        const string buttonGenerateUID = "btGen";
        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == true)
            {
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                {
                    if (pVal.ItemUID == "btGen")
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                        {
                            return;
                        }
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                        int i = oApplication.MessageBox("Do you want to generate document?",1,"Yes","No","");
                        if (i == 1)
                        {
                            GeneratePurchaseChallan(docEntry);
                        }
                    }
                }
            }
            else
            {
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                {
                    oForm = oApplication.Forms.Item(pVal.FormUID);

                    #region Jober Code controls
                    SAPbouiCOM.Item oNewItem = oForm.Items.Add("stJoberC", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                    SAPbouiCOM.Item oItem = oForm.Items.Item("30");
                    oNewItem.Left = oItem.Left;
                    oNewItem.Top = oForm.Items.Item("30").Top + oItem.Height + 5;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width;
                    SAPbouiCOM.StaticText oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                    oStaticText.Caption = "Jober Code";

                    oNewItem = oForm.Items.Add("U_JoberC", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                    oItem = oForm.Items.Item("29");
                    oNewItem.Left = oItem.Left;
                    oNewItem.Top = oForm.Items.Item("stJoberC").Top;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width;
                    oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                    oEdit.DataBind.SetBound(true, headerTable, "U_JoberC");

                    objclsCommon.AddChooseFromList(oForm, "CFL_JB", "2");
                    oEdit.ChooseFromListUID = "CFL_JB";
                    oEdit.ChooseFromListAlias = "CardCode";
                    #endregion

                    #region Create Generate Challan Button

                    oNewItem = oForm.Items.Add(buttonGenerateUID, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                    oItem = oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel));
                    oNewItem.Left = oItem.Left + oItem.Width + 10;
                    oNewItem.Top = oItem.Top;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width * 2;
                    SAPbouiCOM.Button oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                    oButton.Caption = "Generate Challan";

                    #endregion

                    oNewItem.EnableinUpdateMode();
                }

                #region F_et_CHOOSE_FROM_LIST

                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                {
                    SAPbouiCOM.DataTable oDataTable = null;
                    oForm = oApplication.Forms.Item(pVal.FormUID);
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                    oDataTable = oCFLEvento.SelectedObjects;
                    string sCFL_ID = oCFLEvento.ChooseFromListUID;
                    string Value = string.Empty;
                    if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                    {
                        return;
                    }
                    if (oCFLEvento.ChooseFromListUID == "CFL_JB")
                    {
                        oEdit = oForm.Items.Item("U_JoberC").Specific;
                        try
                        {
                            oEdit.String = oDataTable.GetValue(CommonFields.CardCode, 0).ToString();
                        }
                        catch { }
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                        }
                    }
                }


                #endregion

            }
        }


        public void GeneratePurchaseChallan(string docEntry)
        {
            SAPbobsCOM.GeneralService oGeneralService;
            SAPbobsCOM.GeneralData oGeneralData;

            SAPbobsCOM.GeneralData oChild;
            SAPbobsCOM.GeneralDataCollection oChildren;
            SAPbobsCOM.GeneralDataParams oGeneralParams;

            SAPbobsCOM.CompanyService oCompService;
            oCompService = oCompany.GetCompanyService();
            oGeneralService = oCompService.GetGeneralService("PURCHAL");
            oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);
            oGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);

            oGeneralData.SetProperty("Series", oRs.Fields.Item("DISP_SER").Value);
            oGeneralData.SetProperty("U_CardCode", oRs.Fields.Item("U_CardCode").Value);
            oGeneralData.SetProperty("U_CardName", oRs.Fields.Item("U_CardName").Value);
             
            try
            {
                oGeneralData.SetProperty("U_DocDate", DateTime.Parse(oRs.Fields.Item("U_DispDate").Value.ToString()));
            }
            catch { }
            oGeneralData.SetProperty("U_Port", oRs.Fields.Item("U_PRTOFDSHG").Value);
           
            // Adding data to Detail Line

            oChildren = oGeneralData.Child("DISP_PLAN1");
            while (!oRs.EoF)
            {
                oChild = oChildren.Add();
                oChild.SetProperty("U_ItemCode", oRs.Fields.Item("U_ItemCode").Value);
                 
                oRs.MoveNext();
            }

            oGeneralParams = oGeneralService.Add(oGeneralData);
            string NewDocEntry = oGeneralParams.GetProperty("DocEntry").ToString();

        }
    }
}
