﻿using Fabric.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fabric.Custom_Forms
{
    class clsReceiptJobWork : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Folder oFolder;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;

        public const string headerTable = "@RECEIPT_JOBWORK";
        public const string rowTable = "@RECEIPT_JOBWORK1";

        public const string objType = "RECEIPT_JOBWORK";
        public const string formMenuUID = "RECEIPT_JOBWORK";
        const string formTitle = "Receipt JobWork";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";
        bool multiItemSelected = false;
        string cflSelected = "";
        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == false)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == "RECEIPT_JOBWORK")
                {
                    LoadForm(pVal.MenuUID);
                }

            }


        }

        public void LoadForm(string formMenuid)
        {
            objclsCommon.LoadXML(formMenuid, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
        }
    }
}
