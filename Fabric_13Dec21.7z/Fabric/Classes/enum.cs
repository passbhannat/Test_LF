﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fabric.Classes
{
    public enum YesNoEnum
    {
        [Description("Yes")]
        Y,
        [Description("No")]
        N,
    }

    public enum SAPButtonEnum
    {
        Add = 1,
        Cancel = 2,
    }

    public enum ManageItemType
    {
        Series= 1,
        Batch = 2,
    }

    public enum SAPMenuEnum
    {
        AddRecord = 1282,
        FindRecord = 1281,
        FirstRecord = 1290,
        LastRecord = 1291,
        NextRecord = 1288,
        PreviousRecord = 1289,
        RefreshRecord = 1304,
        RemoveRecord = 1283,
        CancelRecord = 1284,
        CloseRecord = 1286,
        CloseRow = 1299,
        DuplicateRow = 1294,
        DuplicateRecord = 1287,
        AddRow = 1292,
        DeleteRow = 1293,
        LayoutManager = 5895,
        UDFForm = 6913,
        SystemInitialisation = 8192,
        SalesAR = 2048,
        Modules = 43520
    }

    public enum SAPFormUIDEnum
    {
        MainMenu = 169,
        SalesOrder = 139,
        Delivery = 140,
        ARInvoice = 133,
        PurchaseOrder = 142,
        GRPO = 143,
        APInvoice = 141,
        GoodsReceipt = 721,
        ProductionOrder = 65211,
        ReceiptFromProduction = 65214,
        IssuerForProduction = 65213,
        ServiceContract = 60126,

        IncomingPayment = 170,
        OutgoingPayment = 426,
        BatchInWard = 41,
        SerialInWard = 21,
        ItemMaster = 150
    }

    public enum SAPCustomFormUIDEnum
    {

        [Description("Cutting Merging")]
        CUTTING_MERGING,

        [Description("Import License")]
        IMPORT_LICENSE,

        [Description("Create Production Plan UDO")]
        PROD_PLAN_UDO,

        [Description("Production Planning")]
        PROD_PLAN,

        [Description("Production Process Master")]
        PROD_PROC_MASTER,

        [Description("Production Activity Master")]
        PROD_ACT_MASTER,

        [Description("Product Activity Master")]
        PR_ACT_MASTER,

        

        //[Description("GRPOBARCODESCAN")]
        //GRPOBARCODESCAN,
    }

    public enum SAPFieldEnum
    {
        CardCode,
        ItemCode
    }

    public enum SAPUDFFieldType
    {
        Alpha,
        Text,
        Integer,
        Date,
        Time,
        Amount,
        Quantity,
        Percent,
        UnitTotal,
        Rate,
        Price,
        Link,
        YN,
        YNA,
        CompliesNotComplies,
        RetestMonth,
        BarCodeType,
        TransactionType,
        ProcessType,
        Active_InActive,
        DocumentStatus,
        ItemCategory,
        FabricType,
        TakaType
    }

    public enum SAPMaskModeEnum
    {
        All = -1,
        Ok = 1,
        Add = 2,
        Find = 4,
        View = 8
    }

    public enum TableType
    {
        StandardTable,
        CustomTable
    }

    public enum Department
    {
        [Description("Quality")]
        Quality,
        [Description("Production")]
        Production,
        [Description("Stores")]
        Stores,
    }


}
