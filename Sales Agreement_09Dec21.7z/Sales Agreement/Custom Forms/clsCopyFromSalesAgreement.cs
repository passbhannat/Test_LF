﻿using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using SalesAgreement.Classes;
using System.Linq;
using SalesAgreement.Standard_Forms;

namespace SalesAgreement.Custom_Form
{
    class clsCopyFromSalesAgreement : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Folder oFolder;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formMenuUID = "COPYFROMSALESAGR";
        const string formTitle = "Copy From Sales Agreement";
        const string gridDocumentsUID = "grdDoc";
        const string gridItemsUID = "grdItems";
        DateTime minDate = new DateTime(2000, 01, 01);

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btCopy")
                            {
                                SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridItemsUID);
                                List<clsItemEntity> _clsItemEntityList = new List<clsItemEntity>();
                                for (int i = 0; i < dataTable.Rows.Count; i++)
                                {
                                    if (dataTable.GetValue("Selection", i) == "Y")
                                    {
                                        clsItemEntity _clsItemEntity = new clsItemEntity();

                                        _clsItemEntity.LineId = dataTable.GetValue("LineNum", i);
                                        _clsItemEntity.DocEntry = dataTable.GetValue("DocEntry", i);
                                        _clsItemEntity.DocNum = dataTable.GetValue("DocNum", i);
                                        _clsItemEntityList.Add(_clsItemEntity);
                                    }
                                }
                                if (_clsItemEntityList.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("Please select row", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oForm.Items.Item("2").Click(BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = clsVariables.BaseForm;
                                oMatrix = oBaseForm.Items.Item(clsSalesOrder.matrixUID).Specific;
                                int rowNo = 1;
                                int firstDocEntry = 0;
                                for (int i = 0; i < _clsItemEntityList.Count; i++)
                                {
                                    int lineId = _clsItemEntityList[i].LineId;
                                    int docEntry = _clsItemEntityList[i].DocEntry;
                                    int docNum = _clsItemEntityList[i].DocNum;
                                    if (i == 0)
                                    {
                                        firstDocEntry = docEntry;
                                     //   oRs = objclsCommon.returnRecord("SELECT * FROM \"" + clsSalesAggrement.headerTable + "\" WHERE DocEntry = '" + docEntry + "' ");

                                    }
                                    oRs = objclsCommon.returnRecord("SELECT * FROM \"" + clsSalesAggrement.rowTable + "\" WHERE DocEntry = '" + docEntry + "' AND LineId='" + lineId + "'");

                                    #region Item Tab
                                    if (!oRs.EoF)
                                    {
                                        oBaseForm.Items.Item("112").Click(BoCellClickType.ct_Regular);

                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", rowNo)).String = oRs.Fields.Item("U_ItemCode").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", rowNo)).String = oRs.Fields.Item("U_OpenQty").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseQty", rowNo)).String = oRs.Fields.Item("U_OpenQty").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseEn", rowNo)).String = oRs.Fields.Item("DocEntry").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", rowNo)).String = oRs.Fields.Item("Object").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseLine", rowNo)).String = oRs.Fields.Item("LineId").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", rowNo)).String = oRs.Fields.Item("U_WhsCode").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", rowNo)).String = oRs.Fields.Item("U_Price").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", rowNo)).String = oRs.Fields.Item("U_DiscPer").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", rowNo)).String = oRs.Fields.Item("U_TaxCode").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PackDesc", rowNo)).String = oRs.Fields.Item("U_PackDesc").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GrWt", rowNo)).String = oRs.Fields.Item("U_GRWT").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_AddDescp", rowNo)).String = oRs.Fields.Item("U_AddDescp").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRNO", rowNo)).String = oRs.Fields.Item("U_SRNO").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NeWt", rowNo)).String = oRs.Fields.Item("U_NeWt").Value.ToString();
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", rowNo)).String = oRs.Fields.Item("U_BPCatNo").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10002037", rowNo)).String = oRs.Fields.Item("U_DistRule").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("31", rowNo)).String = oRs.Fields.Item("U_Project").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("163", rowNo)).String = oRs.Fields.Item("U_FreeText").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1980000354", rowNo)).String = oRs.Fields.Item("U_LegText").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PONum", rowNo)).String = oRs.Fields.Item("U_PONum").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PUOM", rowNo)).String = oRs.Fields.Item("U_PUOM").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("256", rowNo)).String = oRs.Fields.Item("U_ItemDet").Value.ToString(); } catch { }

                                        //Add Fields
                                        rowNo++;

                                    }
                                    #endregion

                                }
                                DateTime date;
                                string datevalue = "";
                                oRs = objclsCommon.returnRecord("SELECT * FROM \"" + clsSalesAggrement.headerTable + "\" WHERE DocEntry = '" + firstDocEntry + "' ");
                                if (!oRs.EoF)
                                {
                                    ((SAPbouiCOM.EditText)oBaseForm.Items.Item("14").Specific).String = oRs.Fields.Item("U_NumAtCa").Value.ToString();
                                    try
                                    {
                                        date = oRs.Fields.Item("U_PostDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)oBaseForm.Items.Item("46").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }

                                    #region Payment Terms
                                    oBaseForm.Items.Item("114").Click(BoCellClickType.ct_Regular);
                                    try { ((SAPbouiCOM.ComboBox)oBaseForm.Items.Item("40").Specific).Select(oRs.Fields.Item("U_ShipTo").Value.ToString(), BoSearchKey.psk_ByValue); } catch { }
                                    try { ((SAPbouiCOM.ComboBox)oBaseForm.Items.Item("226").Specific).Select(oRs.Fields.Item("U_BillTo").Value.ToString(), BoSearchKey.psk_ByValue); } catch { }

                                    #endregion

                                    #region Payment Terms
                                    oBaseForm.Items.Item("138").Click(BoCellClickType.ct_Regular); 
                                    try { ((SAPbouiCOM.ComboBox)oBaseForm.Items.Item("47").Specific).Select( oRs.Fields.Item("U_GroupNum").Value.ToString(),BoSearchKey.psk_ByValue); } catch { }
                                    try { ((SAPbouiCOM.ComboBox)oBaseForm.Items.Item("148").Specific).Select(oRs.Fields.Item("U_PayMeth").Value.ToString(), BoSearchKey.psk_ByValue); } catch { }
                                    try { ((SAPbouiCOM.EditText)oBaseForm.Items.Item("157").Specific).String = oRs.Fields.Item("U_Project").Value.ToString(); } catch { }

                                    #endregion

                                    #region UDF
                                    SAPbouiCOM.Form udfForm = oApplication.Forms.Item(oBaseForm.UDFFormUID);
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EMD").Specific).String = oRs.Fields.Item("U_EMD").Value.ToString(); } catch { }
                                    try {
                                        date = oRs.Fields.Item("U_EMDDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EMDDate").Specific).String = datevalue;
                                        }
                                    } catch { } 
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EMDAmt").Specific).String = oRs.Fields.Item("U_EMDAmt").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_EMDValid").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EMDValid").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                //    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EMDValid").Specific).String = oRs.Fields.Item("U_EMDValid").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EMDDetails").Specific).String = oRs.Fields.Item("U_EMDDetails").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_EMDRDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EMDRDate").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LCNo").Specific).String = oRs.Fields.Item("U_LCNo").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_LCSDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LCSDate").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_LCEDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LCEDate").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LCAMT").Specific).String = oRs.Fields.Item("U_LCAMT").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Purchase").Specific).String = oRs.Fields.Item("U_Purchase").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Overhead").Specific).String = oRs.Fields.Item("U_Overhead").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_DeliveryTerm").Specific).String = oRs.Fields.Item("U_DeliveryTerm").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_OffeNo").Specific).String = oRs.Fields.Item("U_OffeNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PaymentTerm").Specific).String = oRs.Fields.Item("U_PaymentTerm").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Insurance").Specific).String = oRs.Fields.Item("U_Insurance").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ConPF").Specific).String = oRs.Fields.Item("U_ConPF").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_VehicleNo").Specific).String = oRs.Fields.Item("U_VehicleNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_NoofPack").Specific).String = oRs.Fields.Item("U_NoofPack").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LRNo").Specific).String = oRs.Fields.Item("U_LRNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Location").Specific).String = oRs.Fields.Item("U_Location").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_REVNO").Specific).String = oRs.Fields.Item("U_REVNO").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_REVDATE").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_REVDATE").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PriceBasis").Specific).String = oRs.Fields.Item("U_PriceBasis").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PackDetails").Specific).String = oRs.Fields.Item("U_PackDetails").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Returnable").Specific).String = oRs.Fields.Item("U_Returnable").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_RMName").Specific).String = oRs.Fields.Item("U_RMName").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Owner_IT").Specific).String = oRs.Fields.Item("U_Owner_IT").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Note").Specific).String = oRs.Fields.Item("U_Note").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Shippedper").Specific).String = oRs.Fields.Item("U_Shippedper").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BOLNo").Specific).String = oRs.Fields.Item("U_BOLNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_SBNo").Specific).String = oRs.Fields.Item("U_SBNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PortS").Specific).String = oRs.Fields.Item("U_PortS").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PordD").Specific).String = oRs.Fields.Item("U_PordD").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_FinalD").Specific).String = oRs.Fields.Item("U_FinalD").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ShipingMasrks").Specific).String = oRs.Fields.Item("U_ShipingMasrks").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_CaseNo").Specific).String = oRs.Fields.Item("U_CaseNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_NETWT").Specific).String = oRs.Fields.Item("U_NETWT").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ORIGIN").Specific).String = oRs.Fields.Item("U_ORIGIN").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Type").Specific).String = oRs.Fields.Item("U_Type").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Packing").Specific).String = oRs.Fields.Item("U_Packing").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ContainerNo").Specific).String = oRs.Fields.Item("U_ContainerNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_SealNo").Specific).String = oRs.Fields.Item("U_SealNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_GrWt").Specific).String = oRs.Fields.Item("U_GRWT").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_CARBOYS").Specific).String = oRs.Fields.Item("U_CARBOYS").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ShipBillNo").Specific).String = oRs.Fields.Item("U_ShipBillNo").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_ShipBillDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ShipBillDate").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_DrwbkAmt").Specific).String = oRs.Fields.Item("U_DrwbkAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_CompositeContract").Specific).String = oRs.Fields.Item("U_CompositeContract").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Composite").Specific).String = oRs.Fields.Item("U_Composite").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Documents").Specific).String = oRs.Fields.Item("U_Documents").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_po_loi_basic_rate").Specific).String = oRs.Fields.Item("U_po_loi_basic_rate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_eway_bill_no").Specific).String = oRs.Fields.Item("U_eway_bill_no").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_eway_bill_date").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_eway_bill_date").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_To").Specific).String = oRs.Fields.Item("U_To").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_CC").Specific).String = oRs.Fields.Item("U_CC").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BCC").Specific).String = oRs.Fields.Item("U_BCC").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_contact_person_at_factory").Specific).String = oRs.Fields.Item("U_contact_person_at_factory").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ShopOrderNo").Specific).String = oRs.Fields.Item("U_ShopOrderNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Plant").Specific).String = oRs.Fields.Item("U_Plant").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_ChallanDate2").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ChallanDate2").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_AmendmentNo").Specific).String = oRs.Fields.Item("U_AmendmentNo").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_AmendmentDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_AmendmentDate").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_LRDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LRDate").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_TransporterBillNo").Specific).String = oRs.Fields.Item("U_TransporterBillNo").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_TransporterBillDate").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_TransporterBillDate").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_TransporterBillAmt").Specific).String = oRs.Fields.Item("U_TransporterBillAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_IGST").Specific).String = oRs.Fields.Item("U_IGST").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_SupplyType").Specific).String = oRs.Fields.Item("U_SupplyType").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_SignAdd").Specific).String = oRs.Fields.Item("U_SignAdd").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LogoRequire").Specific).String = oRs.Fields.Item("U_LogoRequire").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PaymentTerm_1").Specific).String = oRs.Fields.Item("U_PaymentTerm_1").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PaymentTerm_2").Specific).String = oRs.Fields.Item("U_PaymentTerm_2").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PaymnetTerm_3").Specific).String = oRs.Fields.Item("U_PaymnetTerm_3").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EPC_ReceivedAmt").Specific).String = oRs.Fields.Item("U_EPC_ReceivedAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EPC_ClaimAmt").Specific).String = oRs.Fields.Item("U_EPC_ClaimAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EPC_PendingAmt").Specific).String = oRs.Fields.Item("U_EPC_PendingAmt").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_ChallanDate1").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ChallanDate1").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BillToID").Specific).String = oRs.Fields.Item("U_BillToID").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_ShiplToID").Specific).String = oRs.Fields.Item("U_ShiplToID").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PaymnetTerm_4").Specific).String = oRs.Fields.Item("U_PaymnetTerm_4").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EPC_PendingAmt1").Specific).String = oRs.Fields.Item("U_EPC_PendingAmt1").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_SignAddP").Specific).String = oRs.Fields.Item("U_SignAddP").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_SDATE").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_SDATE").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_EDATE").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EDATE").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_Vehicle_Capacity").Specific).String = oRs.Fields.Item("U_Vehicle_Capacity").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_FreightAmount").Specific).String = oRs.Fields.Item("U_FreightAmount").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_FreightCostActual").Specific).String = oRs.Fields.Item("U_FreightCostActual").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PrintType").Specific).String = oRs.Fields.Item("U_PrintType").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PaymnetTerm_5").Specific).String = oRs.Fields.Item("U_PaymnetTerm_5").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_EPC_PendingAmt3").Specific).String = oRs.Fields.Item("U_EPC_PendingAmt3").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LRReceived").Specific).String = oRs.Fields.Item("U_LRReceived").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_PODis").Specific).String = oRs.Fields.Item("U_PODis").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BGRequire").Specific).String = oRs.Fields.Item("U_BGRequire").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BGPersantage").Specific).String = oRs.Fields.Item("U_BGPersantage").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_LCRequired").Specific).String = oRs.Fields.Item("U_LCRequired").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BGNo").Specific).String = oRs.Fields.Item("U_BGNo").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_BGDt").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BGDt").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BGAmt").Specific).String = oRs.Fields.Item("U_BGAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_AmdNo").Specific).String = oRs.Fields.Item("U_AmdNo").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_AmdDt").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_AmdDt").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_BGExp").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BGExp").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_BGClaim").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_BGClaim").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }
                                    try { ((SAPbouiCOM.EditText)udfForm.Items.Item("U_FDRNO").Specific).String = oRs.Fields.Item("U_FDRNO").Value.ToString(); } catch { }
                                    try
                                    {
                                        date = oRs.Fields.Item("U_FDRDATE").Value;
                                        if (date > minDate)
                                        {
                                            datevalue = date.ToString("yyyyMMdd");
                                            ((SAPbouiCOM.EditText)udfForm.Items.Item("U_FDRDATE").Specific).String = datevalue;
                                        }
                                    }
                                    catch { }


                                    #endregion

                                }
                            }

                            else if (pVal.ItemUID == "btNext")
                            {
                                SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridDocumentsUID);
                                List<string> list = new List<string>();
                                for (int i = 0; i < dataTable.Rows.Count; i++)
                                {
                                    string chk = dataTable.GetValue("Selection", i);
                                    if (chk == "Y")
                                    {
                                        list.Add(dataTable.GetValue("DocEntry", i).ToString());
                                    }
                                }
                                string sodocentry = String.Join(",", list);
                                FillItemGrid("N", sodocentry);
                                oFolder = oForm.Items.Item("fld2").Specific;
                                oFolder.Select();
                            }

                            else if (pVal.ItemUID == "btSelAll")
                            {
                                SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridDocumentsUID);
                                List<string> list = new List<string>();
                                for (int i = 0; i < dataTable.Rows.Count; i++)
                                {
                                    string chk = dataTable.GetValue("Selection", i);
                                    if (chk == "Y")
                                    {
                                        list.Add(dataTable.GetValue("DocEntry", i).ToString());
                                    }
                                }
                                string sodocentry = String.Join(",", list);
                                FillItemGrid("Y", sodocentry);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "btCopyFrom")
                            {

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID, "");
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID, string cardcode)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("CardCode", BoDataType.dt_LONG_TEXT, 50);
                    oForm.DataSources.UserDataSources.Item("CardCode").ValueEx = cardcode;
                    oFolder = oForm.Items.Item("fld1").Specific;
                    oFolder.Select();
                    FillGrid("N");
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void FillGrid(string selection)
        {
            oForm = oApplication.Forms.ActiveForm;
            string cardcode = oForm.DataSources.UserDataSources.Item("CardCode").ValueEx;
            sbQuery.Length = 0;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("call Proc_SalesAgr_CopyFromSalesAgr_Documents ( '" + selection + "','" + cardcode + "')");
            }
            else
            {
                sbQuery.Append("EXEC Proc_SalesAgr_CopyFromSalesAgr_Documents '" + selection + "','" + cardcode + "' ");
                //sbQuery.Append("SELECT '"+ selection + "' AS 'Selection',DocEntry,DocNum,U_DocDate AS DocDate,U_CardCode AS CardCode,U_CardName CardName,U_NumAtCa 'Customer Ref No.'FROM \"" + clsSalesAggrement.headerTable + "\" WHERE Status = 'O' AND  AND U_CardCode='" + cardcode + "' ");
            }
            objclsCommon.FillGrid(oForm.UniqueID, gridDocumentsUID, gridDocumentsUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridDocumentsUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;
        }

        private void FillItemGrid(string selection, string docentry)
        {
            oForm = oApplication.Forms.ActiveForm;
            sbQuery.Length = 0;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
            }
            else
            {
                sbQuery.Append("EXEC Proc_SalesAgr_CopyFromSalesAgr_Items '" + selection + "','" + docentry + "' ");

                //sbQuery.Append(" SELECT 'N' AS 'Selection',U_ItemCode AS ItemCode ,U_ItemName as ItemName,U_Qty as Quantity,U_OpenQty AS OpenQty,T1.DocEntry,T2.DocNum,T1.LineId as LineNum ");
                //sbQuery.Append(" FROM \"" + clsSalesAggrement.rowTable + "\" T1 ");
                //sbQuery.Append(" INNER JOIN \"" + clsSalesAggrement.headerTable + "\" T2 ON T1.DocEntry = T2.DocEntry ");
                //sbQuery.Append(" WHERE T2.U_Status = 'O' AND T2.DocEntry  in (" + docentry + ") ");
                //sbQuery.Append(" AND T1.U_ItemCode IS NOT NULL AND T1.U_OpenQty > 0 ");
            }
            objclsCommon.FillGrid(oForm.UniqueID, gridItemsUID, gridItemsUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridItemsUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;
        }
    }
}
