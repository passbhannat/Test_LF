using Fabric;
using Fabric.Classes;
using Fabric.Extensions;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;
using System;
using System.Reflection;
using Fabric.Custom_Form;

namespace Fabric.Classes
{
    class SAPMain : Connection
    {
        public static ILog logger;

        #region Variables

        clsCommon objclsComman = new clsCommon();
        clsFabricMaster _clsFabricMaster = new clsFabricMaster();
        
        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();
            PrepareMenus();
            PrepareEvents();
        }

        private void PrepareMenus()
        {
            logger.DebugFormat("> {0}", nameof(PrepareMenus));
            // 8192 - System Initialisation
            // 43520 - Main Menu
            objclsComman.AddMenu(BoMenuType.mt_STRING, "8192", "FUDO", "Create Fabric UDO", 5);
            objclsComman.AddMenu(BoMenuType.mt_POPUP, "43520", "FAB", "Fabric Addon", 17);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "FAB", "FABMASTER", "Fabric Master", 2);
        }

        private void RemoveMenusFromSAP()
        {
            objclsComman.RemoveMenu("FUDO");
            objclsComman.RemoveMenu("FABMASTER");

        }

        /// <summary>
        /// Create Event Handler 
        /// </summary>
        private void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", nameof(PrepareEvents));
            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
            oApplication.LayoutKeyEvent += new _IApplicationEvents_LayoutKeyEventEventHandler(oApplication_LayoutKeyEvent);
        }


        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.FormTypeEx == "FABMASTER")
                {
                    _clsFabricMaster.ItemEvent(ref pVal, out BubbleEvent);
                }            
                 
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            SAPbouiCOM.Form oForm = null;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }

                if (pVal.BeforeAction == true)
                {
                    //if (pVal.MenuUID == "MTUDO")
                    //{
                    //    oApplication.StatusBar.SetText("Please wait....", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    //    objclsComman.CreateDataBase();
                    //    oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    //}
                    //else
                    
                    if (pVal.MenuUID == "FUDO")
                    {
                        oApplication.StatusBar.SetText("Please wait....", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        objclsComman.CreateDataBase();
                        oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    }
                }

                if (pVal.MenuUID == "FABMASTER" || (oForm != null && oForm.TypeEx == "FABMASTER"))
                {
                    _clsFabricMaster.MenuEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.FormTypeEx == "FABMASTER")
                {
                    _clsFabricMaster.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                    RemoveMenusFromSAP();
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
            }
        }

        void oApplication_LayoutKeyEvent(ref LayoutKeyInfo eventInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (eventInfo.BeforeAction == true)
            {
                if (eventInfo.FormUID.Contains("SALESAGR"))
                {
                    eventInfo.LayoutKey = clsVariables.DocEntry;
                }
            }
        }
        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion
    }
}
