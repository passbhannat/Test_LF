﻿using Fabric.Classes;
using Fabric.Extensions;
using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace Fabric.Custom_Form
{
    class clsFabricMaster : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Folder oFolder;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@FABMASTER";
        public const string rowTable = "@FABMASTER1";
        public const string freightrowTable = "@FABMASTER2";
        public const string objType = "FABMASTER";
        public const string formMenuUID = "FABMASTER";
        const string formTitle = "Fabric Master";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";
        bool multiItemSelected = false;
        string cflSelected = "";
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                                {
                                    string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
                                    if (cardcode == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Customer is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    string duedate = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_DueDate", 0).Trim();
                                    if (duedate == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Due date is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        oApplication.StatusBar.SetText("Row level data is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        if (i == 0)
                                        {
                                            string itemcode = oDbDataSource.GetValue("U_ItemCode", i);
                                            if (itemcode == string.Empty)
                                            {
                                                oApplication.StatusBar.SetText("Item Code is mandatory for Row No: " + (i + 1).ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                                BubbleEvent = false;
                                                return;
                                            }
                                        }
                                    }
                                }
                            }

                            else if (pVal.ItemUID == "btCanc")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Status", 0).Trim();
                                if (status == "L")
                                {
                                    oApplication.StatusBar.SetText("Document is already cancelled.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (oForm.Mode != BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                int i = oApplication.MessageBox("Do you really want to cancel document?", 1, "Yes", "No", "");
                                if (i == 1)
                                {
                                    string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                    objclsCommon.SelectRecord("UPDATE \"" + headerTable + "\" SET U_Status = 'L' WHERE DocEntry = '" + docEntry + "'");
                                    objclsCommon.RefreshRecord();
                                }
                            }

                        }

                        else if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == "U_TaxCode")
                                {
                                    string placeofsupply = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PlaSuppC", 0).Trim();

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                    oMatrix.FlushToDataSource();
                                    string rowWarehouse = oDbDataSource.GetValue("U_WhsCode", pVal.Row - 1);
                                    string rowState = objclsCommon.SelectRecord("SELECT State FROM OWHS T0 WHERE WhsCode = '" + rowWarehouse + "' ");
                                    List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();

                                    if (placeofsupply == rowState)
                                    {
                                        clsCFLEntityList.Add(new clsCFLEntity { Alias = "TfcId", CondVal = "6", Operation = BoConditionOperation.co_EQUAL });
                                        objclsCommon.AddChooseFromList_WithList(oForm, "CFL_TAX", clsCFLEntityList);
                                    }
                                    else
                                    {
                                        clsCFLEntityList.Add(new clsCFLEntity { Alias = "TfcId", CondVal = "5", Operation = BoConditionOperation.co_EQUAL });
                                        objclsCommon.AddChooseFromList_WithList(oForm, "CFL_TAX", clsCFLEntityList);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.FormTypeEx == formMenuUID && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).ToString();
                                if (docNum.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    return;
                                }
                            }
                            else if (pVal.ItemUID == "U_IsRound")
                            {
                                string isround = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(pVal.ItemUID, 0).ToString();
                                if (isround == "Y")
                                {
                                    oForm.Items.Item("U_RoundSum").Enable();
                                }
                                else
                                {
                                    oForm.Items.Item("U_RoundSum").Disable();
                                }
                            }
                            else if (pVal.ItemUID == "U_UseBill")
                            {

                                string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
                                string billTo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BillTo", 0).Trim();

                                string state = objclsCommon.SelectRecord("SELECT State FROM CRD1 T1 WHERE CardCode='" + cardcode + "' AND Address= '" + billTo + "' AND AdresType ='B' ");
                                string stateName = objclsCommon.SelectRecord("SELECT Name  FROM OCST T0 WHERE Code = '" + state + "' ");

                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_PlaSuppC", 0, state);
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_PlaSuppN", 0, stateName);
                            }
                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_BP" || oCFLEvento.ChooseFromListUID == "CFL_BPN")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                                string cardcode = oDataTable.GetValue(CommonFields.CardCode, 0).ToString();
                                oCombo = oForm.Items.Item("U_CntCode").Specific;
                                objclsCommon.FillCombo(oCombo, objclsCommon.FillContactPersonQuery(cardcode));

                                oDbDataSource.SetValue("U_CntCode", 0, oDataTable.GetValue("CntctPrsn", 0).ToString());


                                oCombo = oForm.Items.Item("U_BillTo").Specific;
                                objclsCommon.FillCombo(oCombo, objclsCommon.FillAddressQuery(cardcode, "B"));

                                oCombo = oForm.Items.Item("U_ShipTo").Specific;
                                objclsCommon.FillCombo(oCombo, objclsCommon.FillAddressQuery(cardcode, "S"));

                                string shipTo = oDataTable.GetValue("ShipToDef", 0).ToString();
                                oDbDataSource.SetValue("U_ShipTo", 0, shipTo);
                                string fulladdress = objclsCommon.GetFullBPAddress(cardcode, shipTo, "S");
                                string state = objclsCommon.GetBPAddressState(cardcode, shipTo, "S");
                                string stateName = objclsCommon.SelectRecord("SELECT Name  FROM OCST T0 WHERE Code = '" + state + "' ");
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_PlaSuppC", 0, state);
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_PlaSuppN", 0, stateName);


                                string billTo = oDataTable.GetValue("BillToDef", 0).ToString();
                                oDbDataSource.SetValue("U_BillTo", 0, billTo);
                                fulladdress = objclsCommon.GetFullBPAddress(cardcode, billTo, "B");
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Address", 0, fulladdress);

                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_PLACE")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_PlaSuppC", 0, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue("U_PlaSuppN", 0, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_EMP")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_Owner", 0, oDataTable.GetValue(CommonFields.empID, 0).ToString());
                                oDbDataSource.SetValue("U_OwnerN", 0, oDataTable.GetValue(CommonFields.lastName, 0).ToString() + " , " + oDataTable.GetValue(CommonFields.firstName, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITEM" || oCFLEvento.ChooseFromListUID == "CFL_ITEMN")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                string itemcode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                oDbDataSource.SetValue("U_ItemCode", pVal.Row - 1, itemcode);
                                oDbDataSource.SetValue("U_ItemName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oDbDataSource.SetValue("U_Qty", pVal.Row - 1, "1");
                                string defaultWhs = oDataTable.GetValue("DfltWH", 0).ToString();
                                if (defaultWhs == string.Empty)
                                {
                                    defaultWhs = objclsCommon.SelectRecord(objclsCommon.GetCompanyDefaultQuery());
                                }
                                oDbDataSource.SetValue("U_WhsCode", pVal.Row - 1, defaultWhs);
                                string instock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode));
                                oDbDataSource.SetValue("U_InStock", pVal.Row - 1, instock);
                                string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, defaultWhs));
                                oDbDataSource.SetValue("U_QtyWhs", pVal.Row - 1, stock);
                                string commited = objclsCommon.SelectRecord(objclsCommon.GetItemCommittedQuery(itemcode, defaultWhs));
                                oDbDataSource.SetValue("U_CommQty", pVal.Row - 1, commited);
                                string ordered = objclsCommon.SelectRecord(objclsCommon.GetItemOrderedQuery(itemcode, defaultWhs));
                                oDbDataSource.SetValue("U_OrdQty", pVal.Row - 1, ordered);
                                if (oDataTable.Rows.Count > 1)
                                {
                                    multiItemSelected = true;
                                    cflSelected = oCFLEvento.ChooseFromListUID;
                                }

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_WHS")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_WhsCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                string itemcode = oDbDataSource.GetValue("U_ItemCode", pVal.Row - 1);
                                string defaultWhs = oDbDataSource.GetValue("U_WhsCode", pVal.Row - 1);
                                string instock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode));
                                oDbDataSource.SetValue("U_InStock", pVal.Row - 1, instock);
                                string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, defaultWhs));
                                oDbDataSource.SetValue("U_QtyWhs", pVal.Row - 1, stock);
                                string commited = objclsCommon.SelectRecord(objclsCommon.GetItemCommittedQuery(itemcode, defaultWhs));
                                oDbDataSource.SetValue("U_CommQty", pVal.Row - 1, commited);
                                string ordered = objclsCommon.SelectRecord(objclsCommon.GetItemOrderedQuery(itemcode, defaultWhs));
                                oDbDataSource.SetValue("U_OrdQty", pVal.Row - 1, ordered);
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_TAX")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_TaxCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue("U_TaxRate", pVal.Row - 1, oDataTable.GetValue("Rate", 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                CalculateLineTotal(pVal.FormUID, pVal.Row);
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_DISTR")
                            {

                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_DistRule", pVal.Row - 1, oDataTable.GetValue(CommonFields.OcrCode, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_PRJR")
                            {

                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_Project", pVal.Row - 1, oDataTable.GetValue(CommonFields.PrjCode, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == BoEventTypes.et_COMBO_SELECT)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
  
                        }
                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (clsVariables.boolCFLSelected)
                            {
                                clsVariables.boolCFLSelected = false;
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                clsVariables.RowNo = 0;
                                clsVariables.ColNo = 0;
                                if (multiItemSelected == true)
                                {
                                    multiItemSelected = false;
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    oMatrix = oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    string itemcode = "";
                                    string itemname = "";
                                    bool fillItemDetails = false;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        itemcode = oDbDataSource.GetValue("U_ItemCode", i).ToString();
                                        itemname = oDbDataSource.GetValue("U_ItemName", i).ToString();

                                        if ((itemcode == string.Empty && itemname != string.Empty) || (itemcode != string.Empty && itemname == string.Empty))
                                        {
                                            fillItemDetails = true;
                                            if (itemcode == string.Empty)
                                            {
                                                itemcode = objclsCommon.SelectRecord("SELECT ItemCode FROM OITM WHERE ItemName = '" + itemname + "'");
                                            }
                                            if (itemname == string.Empty)
                                            {
                                                itemname = objclsCommon.SelectRecord("SELECT ItemName FROM OITM WHERE ItemCode = '" + itemcode + "'");
                                            }
                                        }
                                        if (fillItemDetails == true)
                                        {
                                            fillItemDetails = false;
                                            oDbDataSource.SetValue("U_ItemCode", i, itemcode);
                                            oDbDataSource.SetValue("U_ItemName", i, itemname);
                                            oDbDataSource.SetValue("U_Qty", i, "1");
                                            string defaultWhs = objclsCommon.SelectRecord("SELECT DfltWH FROM OITM WHERE ItemName = '" + itemname + "'");
                                            if (defaultWhs == string.Empty)
                                            {
                                                defaultWhs = objclsCommon.SelectRecord(objclsCommon.GetCompanyDefaultQuery());
                                            }
                                            oDbDataSource.SetValue("U_WhsCode", i, defaultWhs);
                                            string instock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode));
                                            oDbDataSource.SetValue("U_InStock", i, instock);
                                            string stock = objclsCommon.SelectRecord(objclsCommon.GetItemStockQuery(itemcode, defaultWhs));
                                            oDbDataSource.SetValue("U_QtyWhs", i, stock);
                                            string commited = objclsCommon.SelectRecord(objclsCommon.GetItemCommittedQuery(itemcode, defaultWhs));
                                            oDbDataSource.SetValue("U_CommQty", i, commited);
                                            string ordered = objclsCommon.SelectRecord(objclsCommon.GetItemOrderedQuery(itemcode, defaultWhs));
                                            oDbDataSource.SetValue("U_OrdQty", i, ordered);
                                        }
                                    }
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                    oMatrix.LoadFromDataSource();
                                }
                            }
                        }
                        #endregion

                        #region F_ItemChanged
                        if (pVal.ItemChanged == true)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == "U_Qty" || pVal.ColUID == "U_Price" || pVal.ColUID == "U_DiscPer")
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                    clsVariables.ColNo = oPos.ColumnIndex;
                                    clsVariables.RowNo = oPos.rowIndex;

                                    CalculateLineTotal(pVal.FormUID, pVal.Row);
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                            else if (pVal.ItemUID == "U_DiscPer")
                            {
                                double totalBefDisc = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotalBef", 0).ToString());
                                double discper = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_DiscPer", 0).ToString());
                                double discamt = totalBefDisc * discper / 100;
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_DiscSum", 0, discamt.ToString());
                                CalculateSubTotal(oForm.UniqueID);
                                CalculateFooter(oForm.UniqueID);
                            }
                            else if (pVal.ItemUID == "U_DiscSum")
                            {
                                double totalBefDisc = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotalBef", 0).ToString());
                                double discamt = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_DiscSum", 0).ToString());
                                double discper = discamt * 100 / totalBefDisc;
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_DiscPer", 0, discper.ToString());
                                CalculateFooter(oForm.UniqueID);
                            }
                            else if (pVal.ItemUID == "U_RoundSum")
                            {
                                CalculateFooter(oForm.UniqueID);
                            }

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                        || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                        string canceled = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Canceled", 0).Trim();
 

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Status", 0);
                        if (status == "C")
                        {
                            oForm.Mode = BoFormMode.fm_VIEW_MODE;
                        }
                        else
                        {
                            oForm.Mode = BoFormMode.fm_OK_MODE;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    //string FormID;
                    //if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    //{
                    //    oForm = oApplication.Forms.Item(FormID);
                    //    oForm.Select();
                    //    return;
                    //}
                    objclsCommon.LoadXML(menuID, "U_ItemCode", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.LayoutManager), true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                     
                    //oCombo = oForm.Items.Item("U_DocCur").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"CurrCode\", T0.\"CurrName\" FROM OCRN T0");

                    //oCombo = oForm.Items.Item("U_SlpCode").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"SlpCode\", T0.\"SlpName\" FROM OSLP T0 ORDER BY T0.\"SlpCode\" ");


                    //oCombo = oForm.Items.Item("U_Trnsp").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"TrnspCode\", T0.\"TrnspName\" FROM OSHP T0");

                    //oCombo = oForm.Items.Item("U_LangCode").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"Code\", T0.\"Name\" FROM OLNG T0");

                    //oCombo = oForm.Items.Item("U_GroupNum").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"GroupNum\", T0.\"PymntGroup\" FROM OCTG T0");

                    //oCombo = oForm.Items.Item("U_PayMeth").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"CrTypeCode\", T0.\"CrTypeName\" FROM OCRP T0");

                    //oCombo = oForm.Items.Item("U_Branch").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"BPLId\", T0.\"BPLName\" FROM OBPL T0 WHERE \"Disabled\" = 'N' ");

                    List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                    clsCFLEntityList.Add(new clsCFLEntity { Alias = "CardType", CondVal = "C", Operation = BoConditionOperation.co_EQUAL });
                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_BP", clsCFLEntityList);

                    oMatrix = oForm.Items.Item(matrixUID).Specific;
                    oMatrix.CommonSetting.EnableArrowKey = true;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    //oCombo = oMatrix.GetCellSpecific("U_SlpCode", 1);
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"SlpCode\", T0.\"SlpName\" FROM OSLP T0 ORDER BY T0.\"SlpCode\" ");

                    //oCombo = oMatrix.GetCellSpecific("U_Location", 1);
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"Code\", T0.\"Location\" FROM OLCT T0 ORDER BY T0.\"Code\" ");
                     
                }
                 
                oMatrix = oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                //oForm.Items.Item("DocNum").EnableinFindMode();
                //oForm.Items.Item("DocEntry").EnableinFindMode();
                //oForm.Items.Item("Status").EnableinFindMode();
                //oForm.Items.Item("CANCELED").EnableinFindMode();
                //oForm.Items.Item("DocEntry").EnableinFindMode();
                //string autoCode = objclsCommon.SelectRecord("SELECT MAX(Cast(Code as numeric(19,6))) FROM \"" + headerTable + "\"");
                //int iAutoCode = autoCode == string.Empty ? 1 : int.Parse(autoCode);
                //iAutoCode = iAutoCode + 1;
                oFolder = oForm.Items.Item("fld1").Specific;
                oFolder.Select();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsCommon.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void CalculateLineTotal(string formuid, int rowNo)
        {
            oForm = oApplication.Forms.Item(formuid);
            double headerDiscPer = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_DiscPer", 0));

            oMatrix = oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            double qty = double.Parse(oDbDataSource.GetValue("U_Qty", rowNo - 1));
            double price = double.Parse(oDbDataSource.GetValue("U_Price", rowNo - 1));
            double taxrate = double.Parse(oDbDataSource.GetValue("U_TaxRate", rowNo - 1));
            double discper = double.Parse(oDbDataSource.GetValue("U_DiscPer", rowNo - 1));

            double discAmount = (qty * price) * discper / 100;
            double rowTotal1 = qty * price;
            double rowTotal2 = qty * price * discper / 100;
            double rowTotal = rowTotal1 - rowTotal2;
            double taxamount = (rowTotal * taxrate / 100) - (rowTotal * taxrate / 100) * headerDiscPer / 100;

            oDbDataSource.SetValue("U_LineTot", rowNo - 1, rowTotal.ToString());
            oDbDataSource.SetValue("U_DiscSum", rowNo - 1, discAmount.ToString());
            oDbDataSource.SetValue("U_TaxSum", rowNo - 1, taxamount.ToString());
            oMatrix.LoadFromDataSource();
            CalculateSubTotal(formuid);
        }

        public void CalculateSubTotal(string formuid)
        {
            oForm = oApplication.Forms.Item(formuid);
            oMatrix = oForm.Items.Item(matrixUID).Specific;

            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            double dblTotalbeforeDiscount = 0;
            double totalTax = 0;
            double headerDiscPer = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_DiscPer", 0));

            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                double qty = double.Parse(oDbDataSource.GetValue("U_Qty", i));
                double price = double.Parse(oDbDataSource.GetValue("U_Price", i));
                double taxrate = double.Parse(oDbDataSource.GetValue("U_TaxRate", i));
                double discper = double.Parse(oDbDataSource.GetValue("U_DiscPer", i));

                double discAmount = (qty * price) * discper / 100;
                double rowTotal1 = qty * price;
                double rowTotal2 = qty * price * discper / 100;
                double rowTotal = rowTotal1 - rowTotal2;
                double taxamount = (rowTotal * taxrate / 100) - (rowTotal * taxrate / 100) * headerDiscPer / 100;

                double dblTotal = double.Parse(oDbDataSource.GetValue("U_LineTot", i));
                dblTotalbeforeDiscount = dblTotalbeforeDiscount + dblTotal;
                totalTax = totalTax + taxamount;
            }
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotalBef", 0, dblTotalbeforeDiscount.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TaxSum", 0, totalTax.ToString());
            CalculateFooter(formuid);
        }

        private void CalculateFooter(string formuid)
        {
            oForm = oApplication.Forms.Item(formuid);
            double totalBefDisc = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotalBef", 0));
            double discAmt = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_DiscSum", 0));
            double freight = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Freight", 0));
            double tax = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TaxSum", 0));

            //oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TaxSum", 0, dblTotalbeforeDiscount.ToString());
            //double freightTaxAmount = 0; //+this.oForm.controls['FreightTaxAmount'].value;
            double freightTaxAmount = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FreightT", 0));

            double totalAfterDisc = totalBefDisc - discAmt;
            double totalTaxAmount = tax + freightTaxAmount;
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TaxSum", 0, totalTaxAmount.ToString());
            double doctotal = totalBefDisc - discAmt + freight + totalTaxAmount;
            double fractionAmount = +(doctotal % 1);
            string isRound = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_IsRound", 0).ToString();
            if (isRound == "N")
            {
                if (fractionAmount >= 0.50)
                {
                    fractionAmount = +(1 - fractionAmount);
                }
                else
                {
                    fractionAmount = -fractionAmount;
                }
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_RoundSum", 0, fractionAmount.ToString());
            }
            else
            {
                fractionAmount = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_RoundSum", 0));
            }
            doctotal = doctotal + fractionAmount;
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_DocTotal", 0, Math.Round(doctotal, 2).ToString());

        }
    }
}
