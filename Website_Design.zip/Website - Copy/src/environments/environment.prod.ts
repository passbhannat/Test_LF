var ip = window.location.origin 
export const environment = {
  production: true,
  //apiEndpoint: 'http://192.168.1.235:90/api',
  //apiEndpoint: 'http://202.189.235.90:8091/PortalAPI/api',
  apiEndpoint: ip +'/PortalAPI/api',
  refPath:""
};
