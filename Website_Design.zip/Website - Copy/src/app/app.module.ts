import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { LoginComponent } from './pages/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { PageContentComponent } from './layout/page-content/page-content.component';
import { GuestTopNavComponent } from './layout/guest/guest-top-nav/guest-top-nav.component';
import { GuestFooterComponent } from './layout/guest/guest-footer/guest-footer.component';
import { GuestLayoutComponent } from './layout/guest/guest-layout/guest-layout.component';
import { LandingPageComponent } from './pages/landing-page/landing-page.component';
import { AppRoutingModule } from './/app-routing.module';
import { AuthorisedSideNavComponent } from './layout/authorised/authorised-side-nav/authorised-side-nav.component';
import { AuthorisedLayoutComponent } from './layout/authorised/authorised-layout/authorised-layout.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { AuthorisedTopNavComponent } from './layout/authorised/authorised-top-nav/authorised-top-nav.component';
import { AuthorisedSideNavTogglerComponent } from './layout/authorised/authorised-side-nav-toggler/authorised-side-nav-toggler.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { ResetPasswordComponent } from './pages/resetpassword/resetpassword.component';
import { SalesOrderComponent } from './pages/salesorder/salesorder.component';
import { SalesInvoiceComponent } from './pages/salesinvoice/salesinvoice.component';
import { SalesCreditComponent } from './pages/salescredit/salescredit.component';
import { SalesCreditStandAloneComponent } from './pages/salescreditstandalone/salescreditstandalone.component';
 
import { CollectionReportComponent } from './pages/reports/collectionreport/collectionreport.component';
import { OrderDetailsReportComponent } from './pages/reports/orderdetailsreport/orderdetailsreport.component';
import { LedgerReportComponent } from './pages/reports/ledgerreport/ledgerreport.component';
import { OpportunityReportComponent } from './pages/reports/opportunityreport/opportunityreport.component';
import { OutstandingReportComponent } from './pages/reports/outstandingreport/outstandingreport.component';
import { QuotationDetailsReportComponent } from './pages/reports/quotationdetailsreport/quotationdetailsreport.component';

import { PurchaseReportComponent } from './pages/reports/purchasereport/purchasereport.component';
import { SalesReportComponent } from './pages/reports/salesreport/salesreport.component';
import { StockSummaryReportComponent } from './pages/reports/stocksummaryreport/stocksummaryreport.component';
import { ItemStockReportComponent } from './pages/reports/itemstockreport/itemstockreport.component';
import { DispatchPlanningReportComponent } from './pages/reports/dispatchplanningreport/dispatchplanningreport.component';


import { ExpandMenu } from './directives/expand.directive';
import { FieldErrorDisplayComponent } from './field-error-display/field-error-display.component';
import { ModalmessageComponent } from './modals/modalmessage/modalmessage.component';
import { ModalTaxCodeComponent } from './modals/modaltaxcode/modaltaxcode.component';
import { ModalItemComponent } from './modals/modalitem/modalitem.component';
import { ModalbpartnerComponent } from './modals/modalbpartner/modalbpartner.component';
import { ModalEmployeeComponent } from './modals/modalemployee/modalemployee.component';
import { ModalDealerComponent } from './modals/modaldealer/modaldealer.component';
import { ModalSOComponent } from './modals/modalso/modalso.component';
import { ModalInvoiceComponent } from './modals/modalinvoice/modalinvoice.component';
import { KeysPipe } from './pipes/keys.pipe';
import { SearchPipe } from './pipes/search.pipe';
import {DatePipe} from '@angular/common';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
//import { Ng2SearchPipeModule } from 'ng2-search-filter';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ResetPasswordComponent,
    PageContentComponent,
    GuestTopNavComponent,
    GuestFooterComponent,
    GuestLayoutComponent,
    LandingPageComponent,
    AuthorisedSideNavComponent,
    AuthorisedLayoutComponent,
    DashboardComponent,
    AuthorisedTopNavComponent,
    AuthorisedSideNavTogglerComponent,
    RegistrationComponent,
    
    SalesOrderComponent,
    SalesInvoiceComponent,
    SalesCreditComponent,
    SalesCreditStandAloneComponent,
    
    CollectionReportComponent,
    OrderDetailsReportComponent,
    LedgerReportComponent,
    OpportunityReportComponent,
    OutstandingReportComponent,
    QuotationDetailsReportComponent,
    PurchaseReportComponent,
    SalesReportComponent,
    StockSummaryReportComponent,
    ItemStockReportComponent,
    DispatchPlanningReportComponent,
    ExpandMenu,
    FieldErrorDisplayComponent,
    ModalmessageComponent,
    ModalTaxCodeComponent,
    ModalbpartnerComponent,
    ModalItemComponent,
    ModalEmployeeComponent,
    ModalDealerComponent,
    ModalSOComponent,
    ModalInvoiceComponent,
    KeysPipe,
    SearchPipe
  ],
  imports: [
    BrowserAnimationsModule,
    HttpClientModule, 
    AppRoutingModule,
    BrowserModule,
    FormsModule, 
    ReactiveFormsModule,
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
