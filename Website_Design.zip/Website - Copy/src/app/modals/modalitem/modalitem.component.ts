import { Component, OnInit,Input, Output ,EventEmitter} from '@angular/core';
import { Common_Service   } from '../../common/common_service'; 
@Component({
  selector: 'app-modalitem',
  templateUrl: './modalitem.component.html',
  styleUrls: ['./modalitem.component.css'],
})
export class ModalItemComponent implements OnInit {

  @Input() display_Item;
  @Input() whsCode;
  
  @Output() change:EventEmitter<string>=new EventEmitter<string>();
  @Output() itemcode:EventEmitter<string>=new EventEmitter<string>();
  
  public isloading=false;
  public pageNumber=0;
  public totalRowsCount:0;
  public totalPageCount:number;
  public array_AllData:Array<any>=[];  
  itemSearch="";

  constructor(private _common_service: Common_Service) { }

  ngOnInit() {
  }
 
  ngOnChanges(changes: any) {
    if(this.display_Item=="block"){
      this.isloading=true;
      this.firstPage();
    }
  }

  showAllRecords(pageNumber){
    this.isloading=true;
    let searchText = "";//((document.getElementById("txtItemSearch") as HTMLInputElement).value);;//this.businessPartnerForm.controls['SearchText'].value;
    let noOfShowEntry=10;
    this._common_service.Item_Get_AllData(searchText,pageNumber,noOfShowEntry,this.whsCode).subscribe(
      data=>{this.array_AllData=data;
        // if(data.length>0){
        //   this.totalRowsCount=data[0].TotalRowsCount ;
        //   this.totalPageCount=Math.ceil(data[0].TotalRowsCount /noOfShowEntry);
        // }
        // else{
        //     this.totalRowsCount=0;
        //     this.totalPageCount=0;
        // }
        this.isloading=false;
      },
      error=>{ 
        this.isloading=false;
        alert(error);
      }
      );

    }

   
firstPage(){
  this.pageNumber=1;
  this.showAllRecords(this.pageNumber-1);
}
nextPage(){
  if(this.pageNumber==this.totalPageCount)  {
    return;
  }
  this.pageNumber=this.pageNumber+1;
  this.showAllRecords(this.pageNumber-1);
}
previousPage(){ 
  
  if(this.pageNumber==1)  {
    return;
  }
  this.pageNumber=this.pageNumber-1;
  this.showAllRecords(this.pageNumber-1);
}
lastPage(){
  this.pageNumber=Math.ceil(this.totalRowsCount/10);
  this.showAllRecords(this.pageNumber-1);
}
  
click_Row=function(event,rowID){
  if(rowID!=''){
    this.itemcode.emit(rowID);
    this.close_Modal();
  }
}

close_Modal=function(){
  this.change.emit('none');
}

}
