import { Component, OnInit,Input, Output ,EventEmitter} from '@angular/core';
import { Common_Service   } from '../../common/common_service'; 
@Component({
  selector: 'app-modaltaxcode',
  templateUrl: './modaltaxcode.component.html',
  styleUrls: ['./modaltaxcode.component.css'],
})
export class ModalTaxCodeComponent implements OnInit {

  @Input() display_TaxCode;
  @Input() freight;
  
  @Output() change:EventEmitter<string>=new EventEmitter<string>();
  @Output() taxcode:EventEmitter<string>=new EventEmitter<string>();
  
  public isloading=false;
  public pageNumber=0;
  public totalRowsCount:0;
  public totalPageCount:number;
  public array_AllData:Array<any>=[];  
  taxCodeSearch="";

  constructor(private _common_Service: Common_Service) { }

  ngOnInit() {
  }
 
  ngOnChanges(changes: any) {
    if(this.display_TaxCode=="block"){
      this.isloading=true;
      this.showAllRecords();
    }
  }

  showAllRecords(){
    this.isloading=true;
   // let searchText = ((document.getElementById("txtSearch") as HTMLInputElement).value);;//this.businessPartnerForm.controls['SearchText'].value;
    
    this._common_Service.TaxCode_DropDownValues('AR',this.freight).subscribe(
      data=>{this.array_AllData=data;
        this.isloading=false;
      },
      error=>{ 
        this.isloading=false;
        alert(error);
      }
      );

    }
  
click_Row=function(event,rowID,taxrate){
  if(rowID!=''){
    this.taxcode.emit(rowID);
    this.close_Modal();
  }
}

close_Modal=function(){
  this.change.emit('none');
}

}
