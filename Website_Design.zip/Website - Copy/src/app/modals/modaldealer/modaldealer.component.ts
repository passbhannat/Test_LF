import { Component, OnInit,Input, Output ,EventEmitter} from '@angular/core';
import { Common_Service   } from '../../common/common_service'; 
@Component({
  selector: 'app-modaldealer',
  templateUrl: './modaldealer.component.html',
  styleUrls: ['./modaldealer.component.css'],
})
export class ModalDealerComponent implements OnInit {

  @Input() display_Dealer;
  
  @Output() change:EventEmitter<string>=new EventEmitter<string>();
  @Output() id:EventEmitter<string>=new EventEmitter<string>();
  @Output() name:EventEmitter<string>=new EventEmitter<string>();
  
  public isloading=false;
  public pageNumber=0;
  public totalRowsCount:0;
  public totalPageCount:number;
  public array_AllData:Array<any>=[];  
  dealerSearch="";

  constructor(private _common_service: Common_Service) { }

  ngOnInit() {
  }
 
  ngOnChanges(changes: any) {
    if(this.display_Dealer=="block"){
      this.isloading=true;
      this.firstPage();
    }
  }

  showAllRecords(pageNumber){
    this.isloading=true;
    let searchText = "";//((document.getElementById("txtItemSearch") as HTMLInputElement).value);;//this.businessPartnerForm.controls['SearchText'].value;
    let noOfShowEntry=10;
    this._common_service.Dealer_Get_AllData(searchText,pageNumber,noOfShowEntry).subscribe(
      data=>{this.array_AllData=data;
        // if(data.length>0){
        //   this.totalRowsCount=data[0].TotalRowsCount ;
        //   this.totalPageCount=Math.ceil(data[0].TotalRowsCount /noOfShowEntry);
        // }
        // else{
        //     this.totalRowsCount=0;
        //     this.totalPageCount=0;
        // }
        this.isloading=false;
      },
      error=>{ 
        this.isloading=false;
        alert(error);
      }
      );

    }

   
firstPage(){
  this.pageNumber=1;
  this.showAllRecords(this.pageNumber-1);
}
nextPage(){
  if(this.pageNumber==this.totalPageCount)  {
    return;
  }
  this.pageNumber=this.pageNumber+1;
  this.showAllRecords(this.pageNumber-1);
}
previousPage(){ 
  
  if(this.pageNumber==1)  {
    return;
  }
  this.pageNumber=this.pageNumber-1;
  this.showAllRecords(this.pageNumber-1);
}
lastPage(){
  this.pageNumber=Math.ceil(this.totalRowsCount/10);
  this.showAllRecords(this.pageNumber-1);
}
  
click_Row=function(id,name){
  if(id!=''){
    this.id.emit(id);
    this.name.emit(name);
    this.close_Modal();
  }
}

close_Modal=function(){
  this.change.emit('none');
}

}
