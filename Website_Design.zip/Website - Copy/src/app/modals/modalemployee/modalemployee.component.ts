import { Component, OnInit,Input, Output ,EventEmitter} from '@angular/core';
import { Common_Service   } from '../../common/common_service'; 
@Component({
  selector: 'app-modalemployee',
  templateUrl: './modalemployee.component.html',
  styleUrls: ['./modalemployee.component.css'],
})
export class ModalEmployeeComponent implements OnInit {

  @Input() display_Employee;
  
  @Output() change:EventEmitter<string>=new EventEmitter<string>();
  @Output() empid:EventEmitter<string>=new EventEmitter<string>();
  @Output() empname:EventEmitter<string>=new EventEmitter<string>();
  
  public isloading=false;
  public pageNumber=0;
  public totalRowsCount:0;
  public totalPageCount:number;
  public array_AllData:Array<any>=[];  
  constructor(private _common_service: Common_Service) { }

  ngOnInit() {
  }
 
  ngOnChanges(changes: any) {
    if(this.display_Employee=="block"){
      this.isloading=true;
      this.firstPage();
    }
  }

  showAllRecords(pageNumber){
    this.isloading=true;
    let searchText = ((document.getElementById("txtItemSearch") as HTMLInputElement).value);;//this.businessPartnerForm.controls['SearchText'].value;
    let noOfShowEntry=10;
    this._common_service.Employee_Get_AllData(searchText,pageNumber,noOfShowEntry).subscribe(
      data=>{this.array_AllData=data;
        if(data.length>0){
          this.totalRowsCount=data[0].TotalRowsCount ;
          this.totalPageCount=Math.ceil(data[0].TotalRowsCount /noOfShowEntry);
        }
        else{
            this.totalRowsCount=0;
            this.totalPageCount=0;
        }
        this.isloading=false;
      },
      error=>{ 
        this.isloading=false;
        alert(error);
      }
      );

    }

   
firstPage(){
  this.pageNumber=1;
  this.showAllRecords(this.pageNumber-1);
}
nextPage(){
  if(this.pageNumber==this.totalPageCount)  {
    return;
  }
  this.pageNumber=this.pageNumber+1;
  this.showAllRecords(this.pageNumber-1);
}
previousPage(){ 
  
  if(this.pageNumber==1)  {
    return;
  }
  this.pageNumber=this.pageNumber-1;
  this.showAllRecords(this.pageNumber-1);
}
lastPage(){
  this.pageNumber=Math.ceil(this.totalRowsCount/10);
  this.showAllRecords(this.pageNumber-1);
}
  
click_Row=function(event,id,name){
  if(id!=''){
    this.empid.emit(id);
    this.empname.emit(name);
    this.close_Modal();
  }
}

close_Modal=function(){
  this.change.emit('none');
}

}
