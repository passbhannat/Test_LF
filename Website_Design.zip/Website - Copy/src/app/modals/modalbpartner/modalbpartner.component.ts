import { Common_Service   } from '../../common/common_service'; 
import { Component, OnInit,Input, Output ,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-modalbpartner',
  templateUrl: './modalbpartner.component.html',
  styleUrls: ['./modalbpartner.component.css'],
})
export class ModalbpartnerComponent implements OnInit {

  @Input() display_BP;
  
  @Output() change:EventEmitter<string>=new EventEmitter<string>();
  @Output() cardcode:EventEmitter<string>=new EventEmitter<string>();
  
  public isloading=false;
  public pageNumber=0;
  public totalRowsCount:0;
  public totalPageCount:number;
  public array_BP:Array<any>=[];  
  bpSearch="";
  constructor(private _common_Service: Common_Service) { }

  ngOnInit() {
  }
 
  ngOnChanges(changes: any) {
    if(this.display_BP=="block"){
      this.isloading=true;
      this.firstPage();
    }
  }

  showAllRecords(pageNumber){
    this.isloading=true;
    let searchText =""; //((document.getElementById("txtSearch") as HTMLInputElement).value);;//this.businessPartnerForm.controls['SearchText'].value;
    let noOfShowEntry=10;
    //let noOfShowEntry=this.businessPartnerForm.controls['NoOfShowEntry'].value;
    
    this._common_Service.BP_Get_AllData(searchText,pageNumber,noOfShowEntry,'C').subscribe(
      data=>{this.array_BP=data;
        if(data.length>0){
          this.totalRowsCount=data[0].TotalRowsCount ;
          this.totalPageCount=Math.ceil(data[0].TotalRowsCount /noOfShowEntry);
        }
        else{
            this.totalRowsCount=0;
            this.totalPageCount=0;
        }
        this.isloading=false;
      },
      error=>{ 
        this.isloading=false;
        alert(error);
      }
      );

    }
 
firstPage(){
  this.pageNumber=1;
  this.showAllRecords(this.pageNumber-1);
}
nextPage(){
  if(this.pageNumber==this.totalPageCount)  {
    return;
  }
  this.pageNumber=this.pageNumber+1;
  this.showAllRecords(this.pageNumber-1);
}
previousPage(){ 
  
  if(this.pageNumber==1)  {
    return;
  }
  this.pageNumber=this.pageNumber-1;
  this.showAllRecords(this.pageNumber-1);
}
lastPage(){
  this.pageNumber=Math.ceil(this.totalRowsCount/10);
  this.showAllRecords(this.pageNumber-1);
}
  
click_Row=function(event,rowID){
  if(rowID!=''){
    this.cardcode.emit(rowID);
    this.close_Modal();
  }
}

close_Modal=function(){
  this.change.emit('none');
}

}
