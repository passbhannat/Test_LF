import { Component, OnInit,Input,Output ,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-modalmessage',
  templateUrl: './modalmessage.component.html',
  styleUrls: ['./modalmessage.component.css']
})
export class ModalmessageComponent implements OnInit {
    @Input() display_Message;
    @Input() Message;

    @Output() close_Modal:EventEmitter<string>=new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
  }

  close_MessageModal(){
    this.close_Modal.emit('none');
  }
}
