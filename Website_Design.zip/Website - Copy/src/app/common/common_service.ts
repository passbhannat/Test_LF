import { Injectable } from '@angular/core';  
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';  
import { environment } from '../../environments/environment';
@Injectable()  
export class Common_Service  
{  
    private actionUrl: string; 
    private territory: string; 
    private whsCode : string; 
    private userID : string; 
    private dbName:string;

    public user: Array<any> = [];

    constructor(private _http: HttpClient)  
    {  
       this.actionUrl = environment.apiEndpoint;
        let ltuser = localStorage.getItem('currentuser');

        if(ltuser){
            this.user =JSON.parse(ltuser);
            this.territory = this.user[0].Territory;
            this.whsCode = this.user[0].WhsCode;
            this.userID = this.user[0].UserId;
            this.dbName = this.user[0].DBName;
        }
     }  
 
     CreateUDO=(): Observable<any> =>
    { 
        var url=this.actionUrl+'/admin/CreateUDO';
        return this._http.post(url,'');
    }

    PaymentTerms_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/PaymentTerms_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    TransactionCategory_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/TransactionCategory_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    EmployeeBranch_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/EmployeeBranch_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    BP_Get_AllData = (searchText,pageNumber,noOfShowEntry,cardType): Observable<any> =>  
    {  
        
        var url=this.actionUrl+'/master/BP_Get_AllData?searchText='+searchText+ '&pageNumber='+pageNumber+'&noOfShowEntry='+noOfShowEntry+'&cardType='+cardType+'&territory='+this.territory+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    ApprovedSalesOrder_Get_AllData = (searchText,pageNumber,noOfShowEntry,cardcode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ApprovedSalesOrder_Get_AllData?searchText='+searchText+ '&pageNumber='+pageNumber+'&noOfShowEntry='+noOfShowEntry+'&cardcode='+cardcode+'&createdby='+this.userID+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    ApprovedSalesInvoice_Get_AllData = (searchText,pageNumber,noOfShowEntry,cardcode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ApprovedSalesInvoice_Get_AllData?searchText='+searchText+ '&pageNumber='+pageNumber+'&noOfShowEntry='+noOfShowEntry+'&cardcode='+cardcode+'&createdby='+this.userID+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    BP_Get_Record = (cardCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/BP_Get_Record?cardCode='+cardCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    
    DefaultWarehouse_Get_Record = (cardCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/DefaultWarehouse_Get_Record?cardCode='+cardCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    
    ContactPerson_Get_AllData = (cardCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ContactPerson_Get_AllData?cardCode='+cardCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    
    Warehouse_Get_AllData = (whsCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Warehouse_Get_AllData?whsCode='+whsCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    
    
    Dealer_Get_AllData = (searchText,pageNumber,noOfShowEntry): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Dealer_Get_AllData?searchText='+searchText+ '&pageNumber='+pageNumber+'&noOfShowEntry='+noOfShowEntry+'&territory='+this.territory+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    BPAddress_Get_AllData = (cardCode,adresType): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/BPAddress_Get_AllData?cardCode='+cardCode+ '&adresType='+adresType+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Item_Get_AllData = (searchText,pageNumber,noOfShowEntry,whsCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Item_Get_AllData?searchText='+searchText+ '&pageNumber='+pageNumber+'&noOfShowEntry='+noOfShowEntry+'&whsCode='+whsCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Item_GetDetails = (itemCode,whsCode,cardCode,stateCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Item_GetDetails?itemCode=' + itemCode+ '&whsCode='+whsCode+'&cardCode='+cardCode+'&stateCode='+stateCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Item_GetDiscountDetails = (itemCode,stateCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Item_GetDiscountDetails?itemCode=' + itemCode+ '&stateCode='+stateCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Item_GetPrice = (cardCode,itemCode,invuom): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Item_GetPrice?cardCode='+cardCode+ '&itemCode='+itemCode+ '&invuom='+invuom+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }


    Address_Details = (cardCode,adresType,addressID): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Address_Details?cardCode='+cardCode+ '&adresType='+adresType+ '&addressID='+addressID+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }


    BP_Get_CardCode_Details = (cardCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/BP_Get_CardCode_Details?cardCode='+cardCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }
    
    Address_Get__Details = (cardCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/BP_Get_CardCode_Details?cardCode='+cardCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    ContactPerson_DropDownValues = (cardCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ContactPerson_DropDownValues?cardCode='+cardCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    CopyFrom_SalesOrder_Get_Record = (docentry,whscode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/CopyFrom_SalesOrder_Get_Record?docEntry='+docentry+ '&whscode='+whscode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    CopyFrom_SalesInvoice_Get_Record = (docentry): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/CopyFrom_SalesInvoice_Get_Record?docEntry='+docentry+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Dimesion_DropDownValues = (dimType): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Dimesion_DropDownValues?dimType='+dimType+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }


    Series_DropDownValues = (objType,docdate,docsubtype,whscode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Series_DropDownValues?objType='+objType + '&docdate='+docdate+ '&docsubtype='+docsubtype+ '&whscode='+whscode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Series_Default = (objType): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Series_Default?objType='+objType+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Industry_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Industry_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    SubGroup_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/SubGroup_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Deptarment_DropDownValues = (cardcode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Deptarment_DropDownValues?cardcode='+cardcode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    ExpenseRelated_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ExpenseRelated_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    ExpenseRelated_BasedOnBP_DropDownValues = (cardCode,dept): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ExpenseRelated_BasedOnBP_DropDownValues?cardCode='+cardCode+ '&dept='+dept+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    CompanyType_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/CompanyType_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }
    
    Branch_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Branch_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    SalesEmployee_DropDownValues = (territory): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/SalesEmployee_DropDownValues?territory='+ territory+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Employee_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Employee_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    
    Employee_Get_AllData = (searchText,pageNumber,noOfShowEntry): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Employee_Get_AllData?searchText='+searchText+ '&pageNumber='+pageNumber+'&noOfShowEntry='+noOfShowEntry+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    ShippingType_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ShippingType_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }


    SACCode_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/SACCode_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    ExpenseType_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ExpenseType_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    ExpenseSubType_DropDownValues = (expenseCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/ExpenseSubType_DropDownValues?expenseCode=' + expenseCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }
 
    State_DropDownValues = (countryCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/State_DropDownValues?countryCode=' + countryCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    Country_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/Country_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    BankCode_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/BankCode_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    BPGSTRegNo_DropDownValues = (cardCode): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/BPGSTRegNo_DropDownValues?cardCode=' + cardCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    LocationGSTRegNo_DropDownValues = (): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/LocationGSTRegNo_DropDownValues?dbName='+this.dbName;
        return this._http.get(url) ;
    }

    TaxCode_DropDownValues = (docType,freight): Observable<any> =>  
    {  
        var url=this.actionUrl+'/master/TaxCode_DropDownValues?docType=' + docType+ '&freight=' + freight + '&whsCode='+this.whsCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    TaxCode_GetDetails = (taxCode): Observable<any> =>  
    {   
        var url=this.actionUrl+'/master/TaxCode_GetDetails?taxCode=' + taxCode+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    User_Get_Record = (userCode,userType): Observable<any> =>  
    {   
        var url=this.actionUrl+'/master/User_Get_Record?userCode=' + userCode + '&userType=' + userType+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    User_Reset_Password=(formdata): Observable<any> =>
    { 
        let body = JSON.stringify(formdata);
        var url=this.actionUrl+'/master/User_Reset_Password';
        let headers = new HttpHeaders({
            'Content-Type': 'application/json'
         });
        let options = {
            headers: headers
         }
         return this._http.post(url,body,options); 
    }
}