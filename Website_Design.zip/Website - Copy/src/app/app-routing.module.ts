import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import { CommonModule } from '@angular/common';

import { GuestLayoutComponent } from './layout/guest/guest-layout/guest-layout.component';
import { LandingPageComponent } from './pages/landing-page/landing-page.component';
import { AuthorisedLayoutComponent } from './layout/authorised/authorised-layout/authorised-layout.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
//import { LoginComponent } from './login/login.component';
import { LoginComponent } from './pages/login/login.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { ResetPasswordComponent } from './pages/resetpassword/resetpassword.component';
 
import { SalesOrderComponent } from './pages/salesorder/salesorder.component';
import { SalesInvoiceComponent } from './pages/salesinvoice/salesinvoice.component';
import { SalesCreditComponent } from './pages/salescredit/salescredit.component';
import { SalesCreditStandAloneComponent } from './pages/salescreditstandalone/salescreditstandalone.component';
 
import { CollectionReportComponent } from './pages/reports/collectionreport/collectionreport.component';
import { OrderDetailsReportComponent } from './pages/reports/orderdetailsreport/orderdetailsreport.component';
import { LedgerReportComponent } from './pages/reports/ledgerreport/ledgerreport.component';
import { OpportunityReportComponent } from './pages/reports/opportunityreport/opportunityreport.component';
import { OutstandingReportComponent } from './pages/reports/outstandingreport/outstandingreport.component';
import { QuotationDetailsReportComponent } from './pages/reports/quotationdetailsreport/quotationdetailsreport.component';

import { PurchaseReportComponent } from './pages/reports/purchasereport/purchasereport.component';
import { SalesReportComponent } from './pages/reports/salesreport/salesreport.component';
import { StockSummaryReportComponent } from './pages/reports/stocksummaryreport/stocksummaryreport.component';
import { ItemStockReportComponent } from './pages/reports/itemstockreport/itemstockreport.component';
import { DispatchPlanningReportComponent } from './pages/reports/dispatchplanningreport/dispatchplanningreport.component';

const routes: Routes = [
  { path: '', component: LoginComponent},
  { path: 'login', component: LoginComponent},
  { path: 'registration', component: RegistrationComponent},
  { path: 'resetpassword/uid/:userCode/:userType', component: ResetPasswordComponent},
   
  {
    path: '',
    component: AuthorisedLayoutComponent,
    children: [
      { path: 'dashboard', component: DashboardComponent },
      { path: 'salesorder', component: SalesOrderComponent },
      {path:'salesorder/portalid/:portalid/:apprno/:userid/:duplicate',component:SalesOrderComponent},
 
      { path: 'salesinvoice', component: SalesInvoiceComponent },
      { path: 'salescredit', component: SalesCreditComponent },
      { path: 'salescreditstandalone', component: SalesCreditStandAloneComponent },



      { path: 'collectionpaymentreport', component: CollectionReportComponent },
      { path: 'orderdetailsreport', component: OrderDetailsReportComponent },
      { path: 'quotationdetailsreport', component: QuotationDetailsReportComponent },
      { path: 'ledgerreport', component: LedgerReportComponent },
      { path: 'outstandingreport', component: OutstandingReportComponent },
      { path: 'opportunityreport', component: OpportunityReportComponent },

      { path: 'dispatchplanningreport', component: DispatchPlanningReportComponent },
      { path: 'purchasereport', component: PurchaseReportComponent },
      { path: 'salesreport', component: SalesReportComponent },

      { path: 'stocksummaryreport', component: StockSummaryReportComponent },
      { path: 'itemstockreport', component: ItemStockReportComponent },

    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),  	
    FormsModule, 
    ReactiveFormsModule,
    CommonModule
  ],
  
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
