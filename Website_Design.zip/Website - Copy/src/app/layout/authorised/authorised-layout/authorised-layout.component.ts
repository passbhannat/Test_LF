import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authorised-layout',
  templateUrl: './authorised-layout.component.html',
  styleUrls: ['./authorised-layout.component.scss']
})
export class AuthorisedLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
