import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-authorised-top-nav',
  templateUrl: './authorised-top-nav.component.html',
  styleUrls: ['./authorised-top-nav.component.scss']
})
export class AuthorisedTopNavComponent implements OnInit {
  public user:Array<any> = [];
  public userName;
  public position;
  public companyName;
  
  constructor(private router: Router) { }

  ngOnInit() {
    let ltuser=localStorage.getItem('currentuser');
    this.user=JSON.parse(ltuser);
    if(this.user==null)
    {
      this.router.navigate(['/']);
    }
    else{
      this.userName=this.user[0].UserName;  
      this.position=this.user[0].Position;  
      this.companyName=this.user[0].CompanyName; 
    }
  }
  logOut=function(){
    //alert("Log Out");
    localStorage.removeItem("currentuser");
    this.router.navigate(['/']);
  }

}
