import { Component, OnInit,ElementRef, ViewChild } from '@angular/core';
import {FormGroup,FormControl, FormBuilder,FormArray, Validators,NgForm } from '@angular/forms';
import {Common_Service}  from './../../common/common_service';  
import { ActivatedRoute, Router, Params } from "@angular/router";
 
@Component({
  selector: 'app-registration',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetPasswordComponent implements OnInit {
  oForm;
  public  isloading = false;

 
  constructor(private _fb: FormBuilder
    ,private _common_service: Common_Service,private route: ActivatedRoute
    ,private router: Router) {
      this.route.params.subscribe(params => 
      {
        this.oForm=this._fb.group({
          UserCode:'',
          EmailAddress:'',
          UserType:'',
          Password:['',Validators.required],
          ConfirmPassword:['',Validators.required],
      });
        if (params['userCode']) {
          this.setData(params['userCode'],params['userType']);
        }
      });
   }

  ngOnInit() {
   
  }
  
  setData(userCode: string,userType) {
    this.oForm.controls['UserCode'].setValue(userCode);
    this.oForm.controls['UserType'].setValue(userType);
  }
  
  resetPassword=function(event,formdata){
    if (!this.oForm.valid) {
      this.validateAllFormFields(this.oForm);
      return;
    }
    if(this.oForm.controls['Password'].value != this.oForm.controls['ConfirmPassword'].value){
      alert("Password should match with confirm password"); 
      return;
    }

    this.isloading=true;
    this._common_service.User_Reset_Password(formdata).subscribe(
        data=>{
          this.isloading=false;
          if(data[0].ReturnMessage_Code=="0"){
              alert(data[0].ReturnMessage_Description);
              this.router.navigate(['./login']);
          }
          else{
            alert(data[0].ReturnMessage_Description);
          }
        },
        error=>{
          this.isloading=false;
          alert(error)
        },
    );
  }
 
 

  
isFieldValid(field: string) {
  let value=!this.oForm.get(field).valid && this.oForm.get(field).touched;
  return value;
}

displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
  };
} 

validateAllFormFields(formGroup: FormGroup) {         //{1}
  Object.keys(formGroup.controls).forEach(field => {  //{2}
    const control = formGroup.get(field);             //{3}
    if (control instanceof FormControl) {             //{4}
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {        //{5}
      this.validateAllFormFields(control);            //{6}
    }
  });
}

}