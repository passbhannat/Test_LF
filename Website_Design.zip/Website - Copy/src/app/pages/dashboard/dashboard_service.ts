import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,throwError  } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
@Injectable()  

// @Injectable({
//   providedIn: 'root'
// })
export class DashBoard_Service {
  private actionUrl: string;
  public user: Array<any> = [];
  private dbName:string;
  constructor(private _http: HttpClient) {
    this.actionUrl = environment.apiEndpoint;
    let ltuser = localStorage.getItem('currentuser');
    this.user = JSON.parse(ltuser);
    this.dbName = this.user[0].DBName;
  }

  SalesOrder_EmployeeDashBoard_ApprovalDetails = (createdBy,searchText): Observable<any> =>  
  {  
      var url=this.actionUrl+'/SalesOrder/SalesOrder_EmployeeDashBoard_ApprovalDetails?createdBy='+createdBy+'&searchText='+searchText+'&dbName='+this.dbName;
      return this._http.get(url) ;
  }

  SalesOrder_EmployeeDashBoard_OrderToApprove = (approverID): Observable<any> =>  
  {  
      var url=this.actionUrl+'/SalesOrder/SalesOrder_EmployeeDashBoard_OrderToApprove?approverID='+approverID+'&dbName='+this.dbName;
      return this._http.get(url) ;
  }

  SalesInvoice_EmployeeDashBoard_ApprovalDetails = (createdBy,searchText): Observable<any> =>  
  {  
      var url=this.actionUrl+'/SalesInvoice/SalesInvoice_EmployeeDashBoard_ApprovalDetails?createdBy='+createdBy+'&searchText='+searchText;+'&dbName='+this.dbName;
      return this._http.get(url) ;
  }

  SalesInvoice_EmployeeDashBoard_OrderToApprove = (approverID): Observable<any> =>  
  {  
      var url=this.actionUrl+'/SalesInvoice/SalesInvoice_EmployeeDashBoard_OrderToApprove?approverID='+approverID+'&dbName='+this.dbName;
      return this._http.get(url) ;
  }

  SalesCredit_EmployeeDashBoard_ApprovalDetails = (createdBy,searchText): Observable<any> =>  
  {  
      var url=this.actionUrl+'/SalesCredit/SalesCredit_EmployeeDashBoard_ApprovalDetails?createdBy='+createdBy+'&searchText='+searchText+'&dbName='+this.dbName;
      return this._http.get(url) ;
  }

  SalesCredit_EmployeeDashBoard_OrderToApprove = (approverID): Observable<any> =>  
  {  
      var url=this.actionUrl+'/SalesCredit/SalesCredit_EmployeeDashBoard_OrderToApprove?approverID='+approverID+'&dbName='+this.dbName;
      return this._http.get(url) ;
  }

  DashBoard_Get_TotalOutStanding_Amount = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_TotalOutStanding_Amount?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_DueInvoice = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_DueInvoice?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_DueNextWeekInvoice_Amount = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_DueNextWeekInvoice_Amount?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_NotDueInvoice_Amount = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_NotDueInvoice_Amount?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_TotalOrder_Amount = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_TotalOrder_Amount?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_TotalOrder_Count = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_TotalOrder_Count?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_DueOrder_Amount = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_DueOrder_Amount?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_DueOrder_Count = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_DueOrder_Count?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_NotDueOrder_Amount = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_NotDueOrder_Amount?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_NotDueOrder_Count = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_NotDueOrder_Count?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_OpenOpportunity_Amount = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_OpenOpportunity_Amount?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
  }

  DashBoard_Get_OpenOpportunity_Count = (cardcode): Observable<any> => {
    var url = this.actionUrl + '/report/DashBoard_Get_OpenOpportunity_Count?cardcode=' + cardcode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return ""})
    );
    }

    DashBoard_Get_OpenQuotaton_Amount = (cardcode): Observable<any> => {
      var url = this.actionUrl + '/report/DashBoard_Get_OpenQuotaton_Amount?cardcode=' + cardcode+'&dbName='+this.dbName;
      return this._http.get(url).pipe(map(
        (data: any) => data
      ), 
      catchError(error => { return ""})
      );
    }
  
    DashBoard_Get_OpenQuotation_Count = (cardcode): Observable<any> => {
      var url = this.actionUrl + '/report/DashBoard_Get_OpenQuotation_Count?cardcode=' + cardcode+'&dbName='+this.dbName;
      return this._http.get(url).pipe(map(
        (data: any) => data
      ), 
      catchError(error => { return ""})
      );
      }
}