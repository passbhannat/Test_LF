import { Component, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { DashBoard_Service } from './dashboard_service';
import { ActivatedRoute, Router, Params } from "@angular/router";
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss', './dashboard.component.css'],
  providers:[DashBoard_Service]
})
export class DashboardComponent implements OnInit {
  public user: Array<any> = [];
  myOrderSearch="";
  myCreditSearch="";
 
  TotalOutStandingAmount = 0;
  DueInvoiceAmount;
  DueNextWeekAmount = 0;
  NotDueAmount = 0;
  TotalOrderCount = 0;
  TotalOrderAmount = 0;
  DueOrderCount = 0;
  DueOrderAmount = 0;
  NotDueOrderCount = 0;
  NotDueOrderAmount = 0;
  OpenOpportunitiesCount = 0;
  OpenOpportunitiesAmount = 0;

  OpenQuotationCount = 0;
  OpenQuotationAmount = 0;
  userType="";
  userName="";
  userId="";
  position="";

  array_AllData_SO;
  array_AllData_ToApprove_SO;

  array_AllData_SI;
  array_AllData_ToApprove_SC;

  isloading = false;
  showTotalOutStanding = false;
  showDueAmount = false;
  showDueNextWeek = false;
  showNotDue = false;
  showOpenOpportunities = false;
  showTotalOrder = false;
  showDueOrder = false;
  showNotDueOrder = false;
  showOpenQuotation = false;

  showTotalSubmitted = false;
  showAwaitingReimbursement = false;
  refPath;
  constructor(private _form_service: DashBoard_Service,private router: Router) { 
    this.refPath = environment.refPath;
  }

  ngOnInit() {
    this.isloading = false;
    let ltuser = localStorage.getItem('currentuser');
    this.user = JSON.parse(ltuser);
    let cardcode = this.user[0].CardCode;
    let userCode = this.user[0].UserCode;
    this.userId = this.user[0].UserId;

    this.userType = this.user[0].UserType;
    this.userName = this.user[0].UserName;
    this.position = this.user[0].Position;

    if(this.userType =="S"){
      this.showTotalOutStanding = true;
      this.showDueAmount = true;
      this.showTotalOrder = true;
    }
    else if(this.userType =="E"){
      this.showTotalSubmitted = true;
      this.showAwaitingReimbursement = true;
    }
    else if(this.userType =="C"){
      this.showTotalOutStanding = true;
    }

    // this._form_service.DashBoard_Get_TotalOutStanding_Amount(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.TotalOutStandingAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //     //alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_DueInvoice(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.DueInvoiceAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //     //alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_DueNextWeekInvoice_Amount(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.DueNextWeekAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //     //alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_NotDueInvoice_Amount(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.NotDueAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //     //alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_TotalOrder_Amount(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.TotalOrderAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //    // alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_TotalOrder_Count(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.TotalOrderCount = jsonResult[0].Count;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //    // alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_DueOrder_Amount(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.DueOrderAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //    //alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_DueOrder_Count(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.DueOrderCount = jsonResult[0].Count;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //    // alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_NotDueOrder_Amount(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.NotDueOrderAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //   //  alert(error);
    //   }
    // );


    // this._form_service.DashBoard_Get_NotDueOrder_Count(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.NotDueOrderCount = jsonResult[0].Count;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //   //  alert(error);
    //   }
    // );


    // this._form_service.DashBoard_Get_OpenOpportunity_Amount(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.OpenOpportunitiesAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //  //   alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_OpenOpportunity_Count(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.OpenOpportunitiesCount = jsonResult[0].Count;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //  //   alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_OpenQuotaton_Amount(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.OpenQuotationAmount = jsonResult[0].Amount;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //  //   alert(error);
    //   }
    // );

    // this._form_service.DashBoard_Get_OpenQuotation_Count(cardcode).subscribe(
    //   data => {
    //     let jsonObj = JSON.parse(data);
    //     var jsonResult = JSON.parse(jsonObj.result);
    //     if (jsonResult.length > 0) {
    //       this.OpenQuotationCount = jsonResult[0].Count;
    //     }
    //   },
    //   error => {
    //     this.isloading = false;
    //   //  alert(error);
    //   }
    // );

     

    this._form_service.SalesOrder_EmployeeDashBoard_OrderToApprove(this.userId).subscribe(
      data => {
        this.array_AllData_ToApprove_SO = data;
      },
      error => {
        this.isloading = false;
      }
    );

    this._form_service.SalesCredit_EmployeeDashBoard_OrderToApprove(this.userId).subscribe(
      data => {
        this.array_AllData_ToApprove_SC = data;
      },
      error => {
        this.isloading = false;
      }
    );

    this.GetMySOApprovalDetails();
    this.GetMySCApprovalDetails();

  }

  GetMySOApprovalDetails(){
    let searchText = ''
    this._form_service.SalesOrder_EmployeeDashBoard_ApprovalDetails(this.userId,searchText).subscribe(
      data => {
        this.array_AllData_SO = data;
      },
      error => {
        this.isloading = false;
      }
    );
  }

  openOrder(row,duplicate){
    let invType = row.InvType;
    let docEntry = row.PortalID;
    if(duplicate == "Y"){
      this.router.navigate(
        ['/salesorder', {
          portalid: docEntry,
          duplicate:duplicate
        }]);  
    }
    else{
      this.router.navigate(
        ['/salesorder', {
          portalid: docEntry
        }]);
    }
  }

  openOrder_ToApprove(row){
    let invType = row.InvType;
    let docEntry = row.PortalID;
    let approver1 = row.Approval1;
    let approver2 = row.Approval2;
    let approver3 = row.Approval3;

    let approverName1 = row.ApprovalName1;
    let approverName2 = row.ApprovalName2;
    let approverName3 = row.ApprovalName3;

    let approverStatus1 = row.ApprovalStatus1;
    let approverStatus2 = row.ApprovalStatus2;
    let approverStatus3 = row.ApprovalStatus3;

    if(this.userType =="E"){
        if(approverName1 == this.userName && approverStatus1 == "Pending"){
          this.router.navigate(
            ['/salesorder', {
              portalid: docEntry,
              apprno : 1,
              userid : approver1        
            }]);
          // const url = this.router.serializeUrl(
          //   this.router.createUrlTree([this.refPath+`/salesorder/portalid/${docEntry}/${1}/${approver1}`])
          // );
          // window.open(url, '_blank');
        } 
        else if(approverName2 == this.userName  && approverStatus2 == "Pending"){
          this.router.navigate(
            ['/salesorder', {
              portalid: docEntry,
              apprno : 2,
              userid : approver1        
            }]);
          // const url = this.router.serializeUrl(
          //   this.router.createUrlTree([this.refPath+`/salesorder/portalid/${docEntry}/${2}/${approver2}`])
          // );
          // window.open(url, '_blank');
        }
        else if(approverName3 == this.userName  && approverStatus3 == "Pending"){
          this.router.navigate(
            ['/salesorder', {
              portalid: docEntry,
              apprno : 3,
              userid : approver3        
            }]);
          // const url = this.router.serializeUrl(
          //   this.router.createUrlTree([this.refPath+`/salesorder/portalid/${docEntry}/${3}/${approver3}`])
          // );
          // window.open(url, '_blank');
        }
      else{
        alert('Nothing to approve!!!');    
      }
    // else{
    //   if(approverName1 == this.userName && approverStatus1 == "Pending"){
    //     const url = this.router.serializeUrl(
    //       this.router.createUrlTree([`/expenseclaim/docentry/${docEntry}/${1}/${approver1}`])
    //     );
    //     window.open(url, '_blank');
    //   } 
    //   else if(approverName2 == this.userName  && approverStatus2 == "Pending"){
    //     const url = this.router.serializeUrl(
    //       this.router.createUrlTree([`/expenseclaim/docentry/${docEntry}/${2}/${approver2}`])
    //     );
    //     window.open(url, '_blank');
    //   }
    // else{
    //   alert('Nothing to approve!!!');    
    // }
    // }
  }
  // else{
  //   const url = this.router.serializeUrl(
  //     this.router.createUrlTree([`/apinvoice/docentry/${docEntry}/${0}/''`])
  //   );
  //   window.open(url, '_blank');
  // }
  }

  GetMySCApprovalDetails(){
    let searchText = ''
     
    this._form_service.SalesCredit_EmployeeDashBoard_ApprovalDetails(this.userId,searchText).subscribe(
      data => {
        this.array_AllData_SI = data;
      },
      error => {
        this.isloading = false;
      }
    );
  }

  openInvoice(row,duplicate){
    let invType = row.InvType;
    let docEntry = row.PortalID;
    if(duplicate == "Y"){
      this.router.navigate(
        ['/salescredit', {
          portalid: docEntry,
          duplicate:duplicate
        }]);  
    }
    else{
      this.router.navigate(
        ['/salescredit', {
          portalid: docEntry
        }]);
    }
  }

  openInvoice_ToApprove(row){
    let invType = row.InvType;
    let docEntry = row.PortalID;
    let approver1 = row.Approval1;
    let approver2 = row.Approval2;
    let approver3 = row.Approval3;

    let approverName1 = row.ApprovalName1;
    let approverName2 = row.ApprovalName2;
    let approverName3 = row.ApprovalName3;

    let approverStatus1 = row.ApprovalStatus1;
    let approverStatus2 = row.ApprovalStatus2;
    let approverStatus3 = row.ApprovalStatus3;

    if(this.userType =="E"){
        if(approverName1 == this.userName && approverStatus1 == "Pending"){
          this.router.navigate(
            ['/salescredit', {
              portalid: docEntry,
              apprno : 1,
              userid : approver1        
            }]);          
        } 
        else if(approverName2 == this.userName  && approverStatus2 == "Pending"){
          this.router.navigate(
            ['/salescredit', {
              portalid: docEntry,
              apprno : 2,
              userid : approver1        
            }]);        
        }
        else if(approverName3 == this.userName  && approverStatus3 == "Pending"){
          this.router.navigate(
            ['/salescredit', {
              portalid: docEntry,
              apprno : 3,
              userid : approver3        
            }]);         
        }
      else{
        alert('Nothing to approve!!!');    
      }
  }
  } 

}
