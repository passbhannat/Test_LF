import { Component, OnInit ,AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup,FormControl, FormArray, FormBuilder,Validators,NgForm} from '@angular/forms';
import { Report_Service } from '../report_service';  
import { Common_Service } from '../../../common/common_service';

@Component({
  selector: 'app-dispatchplanningreport',
  templateUrl: './dispatchplanningreport.component.html',
  styleUrls: ['./dispatchplanningreport.component.scss', './dispatchplanningreport.component.css'],
  providers:[Report_Service,Common_Service]
})

export class DispatchPlanningReportComponent implements OnInit {
  form: NgForm;
  public oForm: FormGroup;
  public user:Array<any>=[];
  public boolShow_NewForm=false;
  boolAdd = false;  
  public array_AllData: Array<any> = [];
  public pageNumber=1;
  public totalRowsCount=0;
  public totalPageCount=0;
  public noOfShowEntry=10;
  display_BP_Parent = "none";
  isloading= false;
  constructor(private _fb: FormBuilder,private _form_service: Report_Service,private _common_service: Common_Service) { }

  ngOnInit() {
    this.oForm=this._fb.group({
      CardCode: '',
      CardName: '',
      
      ToDate: new Date()
    });
  //  this.showAllRecords();
  }

    
bpcode_Tab=function(){
    this.display_BP_Parent="block";
}

returnBPDisplayStyle(event) {
  if (event == "none") {
    this.display_BP_Parent = "none";
  }
}
returnBPCode(cardcode) {
  this.oForm.controls['CardCode'].setValue(cardcode);
  this._common_service.BP_Get_CardCode_Details(cardcode).subscribe(
    data=>{
        this.oForm.controls['CardName'].setValue(data[0].CardName);
    });
}


showAllRecords(formType,formdata){
  this.isloading=true;

  let date;

  let todate= formdata.ToDate;
  if(!(todate==null || todate==""))
  {
    todate = todate.getFullYear()+'/'+(todate.getMonth()+1)+'/'+todate.getDate(); 
    //formdata.ToDate=date;
  }
 let cardName = formdata.CardName;
  if(formType==""){
  this._form_service.Report_Get_Dispatch_Planning(todate,cardName).subscribe(
   data=>{
    let jsonObj = JSON.parse(data);
    var jsonResult = JSON.parse(jsonObj.result);
     this.array_AllData=jsonResult;
     this.isloading=false;
   },
   error=>{ 
     this.isloading=false;
     alert(error);
   }
   );
}
else{
  this._form_service.ExportToExcel_Report_Get_Dispatch_Planning(todate,cardName);
  this.isloading=false;
}
}

}
