import { Component, OnInit ,AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup,FormControl, FormArray, FormBuilder,Validators,NgForm} from '@angular/forms';
import { Report_Service } from '../report_service';  
import { Common_Service } from '../../../common/common_service';

@Component({
  selector: 'app-itemstockreport',
  templateUrl: './itemstockreport.component.html',
  styleUrls: ['./itemstockreport.component.scss', './itemstockreport.component.css'],
  providers:[Report_Service,Common_Service]
})

export class ItemStockReportComponent implements OnInit {
  form: NgForm;
  public oForm: FormGroup;
  public user:Array<any>=[];
  public boolShow_NewForm=false;
  boolAdd = false;  
  public array_AllData: Array<any> = [];
  public array_Warehouse: Array<any> = [];

  public pageNumber=1;
  public totalRowsCount=0;
  public totalPageCount=0;
  public noOfShowEntry=10;

  isloading= false;
  constructor(private _fb: FormBuilder,private _form_service: Report_Service,private _common_service: Common_Service) { }

  ngOnInit() {
    this.oForm=this._fb.group({
      WhsCode: '',
    });
    let ltuser = localStorage.getItem('currentuser');
   this.user = JSON.parse(ltuser);
   
    this._common_service.Warehouse_Get_AllData(this.user[0].WhsCode).subscribe(
      data => {
      this.array_Warehouse = data
      },
      error => alert(error)
    );
  }
 
showAllRecords(formType,formdata){
  this.isloading=true;
  let whscode= formdata.WhsCode;
   

  let ltuser=localStorage.getItem('currentuser');
  this.user=JSON.parse(ltuser);
  let cardcode = this.user[0].CardCode;
  if(formType==""){
  this._form_service.Report_Get_ItemStock(whscode).subscribe(
   data=>{
    this.isloading=false;
    let jsonObj = JSON.parse(data);
    var jsonResult = JSON.parse(jsonObj.result);
     this.array_AllData=jsonResult;
   },
   error=>{ 
     this.isloading=false;
     alert(error);
   }
   );
}
else{
  this._form_service.ExportToExcel_Report_Get_ItemStock(whscode);
  this.isloading=false;
}
}

}
