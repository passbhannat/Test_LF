import { Component, OnInit ,AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup,FormControl, FormArray, FormBuilder,Validators,NgForm} from '@angular/forms';
import { Report_Service } from '../report_service';  
@Component({
  selector: 'app-opportunityreport',
  templateUrl: './opportunityreport.component.html',
  styleUrls: ['./opportunityreport.component.scss', './opportunityreport.component.css'],
  providers:[Report_Service]
})

export class OpportunityReportComponent implements OnInit {
  form: NgForm;
  public oForm: FormGroup;
  public user:Array<any>=[];
  public boolShow_NewForm=false;
  boolAdd = false;  
  public array_AllData: Array<any> = [];
  public pageNumber=1;
  public totalRowsCount=0;
  public totalPageCount=0;
  public noOfShowEntry=10;

  isloading= false;
  constructor(private _fb: FormBuilder,private _form_service: Report_Service) { }

  ngOnInit() {
    this.oForm=this._fb.group({
      FromDate: '',
      ToDate: new Date()
    });
  }
 
showAllRecords(formType,formdata){
  this.isloading=true;

  let date;
  let fromdate= formdata.FromDate;
  if(!(fromdate==null || fromdate==""))
  {
    fromdate = fromdate.getFullYear()+'/'+(fromdate.getMonth()+1)+'/'+fromdate.getDate(); 
    //formdata.FromDate=date;
  }

  let todate= formdata.ToDate;
  if(!(todate==null || todate==""))
  {
    todate = todate.getFullYear()+'/'+(todate.getMonth()+1)+'/'+todate.getDate(); 
    //formdata.ToDate=date;
  }

  let ltuser=localStorage.getItem('currentuser');
  this.user=JSON.parse(ltuser);
  let cardcode = this.user[0].CardCode;
  if(formType==""){
  this._form_service.Report_Get_Opportunity(cardcode,fromdate,todate).subscribe(
   data=>{
    this.isloading=false;
    let jsonObj = JSON.parse(data);
    var jsonResult = JSON.parse(jsonObj.result);
     this.array_AllData=jsonResult;
     if(jsonResult.length == 0)
     {
      alert("No data found");
     }
   },
   error=>{ 
     this.isloading=false;
     alert(error);
   }
   );
}
else{
  this._form_service.ExportToExcel_Report_Get_Opportunity(cardcode,fromdate,todate);
  this.isloading=false;
}
}

}
