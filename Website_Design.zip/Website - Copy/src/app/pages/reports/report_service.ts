import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,throwError  } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
@Injectable()  
// @Injectable({
//   providedIn: 'root'
// })
export class Report_Service {
  private actionUrl: string;
  public user: Array<any> = [];
  private dbName:string;
  constructor(private _http: HttpClient) {
    this.actionUrl = environment.apiEndpoint;
    let ltuser = localStorage.getItem('currentuser');
    this.user = JSON.parse(ltuser);
    this.dbName = this.user[0].DBName;
  }

  Report_Get_Dispatch_Planning = (date, cardName): Observable<any> => {
    var url = this.actionUrl + '/report/Report_Get_Dispatch_Planning?date=' + date + '&cardName=' + cardName+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return throwError('There is an error')})
    );
  }

  ExportToExcel_Report_Get_Dispatch_Planning(date, cardName) 
  {  
      var url=this.actionUrl+'/report/ExportToExcel_Report_Get_Dispatch_Planning?date=' + date + '&cardName=' + cardName+'&dbName='+this.dbName;
      window.location.href=url;
  }
  
  Report_Get_Purchase = (fromDate, toDate): Observable<any> => {
    var url = this.actionUrl + '/report/Report_Get_Purchase?fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return throwError('There is an error')})
    );
  }

  ExportToExcel_Report_Get_Purchase(fromDate, toDate) 
  {  
      var url=this.actionUrl+'/report/ExportToExcel_Report_Get_Purchase?fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
      window.location.href=url;
  }

  
  Report_Get_Sales = (fromDate, toDate): Observable<any> => {
    var url = this.actionUrl + '/report/Report_Get_Sales?fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return throwError('There is an error')})
    );
  }

  ExportToExcel_Report_Get_Sales(fromDate, toDate) 
  {  
      var url=this.actionUrl+'/report/ExportToExcel_Report_Get_Sales?fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
      window.location.href=url;
  }

  Report_Get_StockSummary = (fromDate, toDate): Observable<any> => {
    var url = this.actionUrl + '/report/Report_Get_StockSummary?fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return throwError('There is an error')})
    );
  }

  ExportToExcel_Report_Get_StockSummary(fromDate, toDate) 
  {  
      var url=this.actionUrl+'/report/ExportToExcel_Report_Get_StockSummary?fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
      window.location.href=url;
  }

  Report_Get_ItemStock = (whscode): Observable<any> => {
    var url = this.actionUrl + '/report/Report_Get_ItemStock?whscode=' + whscode+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return throwError('There is an error')})
    );
  }

  ExportToExcel_Report_Get_ItemStock(whscode) 
  {  
      var url=this.actionUrl+'/report/ExportToExcel_Report_Get_ItemStock?whscode=' + whscode+'&dbName='+this.dbName;
      window.location.href=url;
  }

  Report_Get_Collection_Payment = (cardcode, fromDate, toDate): Observable<any> => {
    var url = this.actionUrl + '/report/Report_Get_Collection_Payment?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
    return this._http.get(url).pipe(map(
      (data: any) => data
    ), 
    catchError(error => { return throwError('There is an error')})
    );
  }

    ExportToExcel_Report_Get_Collection_Payment(cardcode, fromDate, toDate) 
    {  
        var url=this.actionUrl+'/report/ExportToExcel_Report_Get_Collection_Payment?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
        window.location.href=url;
    }

    Report_Get_Order_Details = (cardcode, fromDate, toDate): Observable<any> => {
      var url = this.actionUrl + '/report/Report_Get_Order_Details?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
      return this._http.get(url).pipe(map(
        (data: any) => data
      ), 
      catchError(error => { return throwError('Its a Trap!')})
      );
    }
  
      ExportToExcel_Report_Get_Order_Details(cardcode, fromDate, toDate) 
      {  
          var url=this.actionUrl+'/report/ExportToExcel_Report_Get_Order_Details?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
          window.location.href=url;
      }

      Report_Get_Quotation_Details = (cardcode, fromDate, toDate): Observable<any> => {
        var url = this.actionUrl + '/report/Report_Get_Quotation_Details?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
        return this._http.get(url).pipe(map(
          (data: any) => data
        ), 
        catchError(error => { return throwError('Its a Trap!')})
        );
      }
    
        ExportToExcel_Report_Get_Quotation_Details(cardcode, fromDate, toDate) 
        {  
            var url=this.actionUrl+'/report/ExportToExcel_Report_Get_Quotation_Details?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
            window.location.href=url;
        }

        Report_Get_Ledger = (cardcode, fromDate, toDate): Observable<any> => {
          var url = this.actionUrl + '/report/Report_Get_Ledger?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
          return this._http.get(url).pipe(map(
            (data: any) => data
          ), 
          catchError(error => { return throwError('Its a Trap!')})
          );
        }
      
          ExportToExcel_Report_Get_Ledger(cardcode, fromDate, toDate) 
          {  
              var url=this.actionUrl+'/report/ExportToExcel_Report_Get_Ledger?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
              window.location.href=url;
          }

        Report_Get_OutStanding = (cardcode): Observable<any> => {
          var url = this.actionUrl + '/report/Report_Get_OutStanding?cardcode=' + cardcode+'&dbName='+this.dbName;
          return this._http.get(url).pipe(map(
            (data: any) => data
          ), 
          catchError(error => { return throwError('Its a Trap!')})
          );
        }
      
        ExportToExcel_Report_Get_OutStanding(cardcode) 
        {  
            var url=this.actionUrl+'/report/ExportToExcel_Report_Get_OutStanding?cardcode=' + cardcode+'&dbName='+this.dbName;
            window.location.href=url;
        }

        Report_Get_Opportunity = (cardcode, fromDate, toDate): Observable<any> => {
          var url = this.actionUrl + '/report/Report_Get_Opportunity?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
          return this._http.get(url).pipe(map(
            (data: any) => data
          ), 
          catchError(error => { return throwError('Its a Trap!')})
          );
        }
      
          ExportToExcel_Report_Get_Opportunity(cardcode, fromDate, toDate) 
          {  
              var url=this.actionUrl+'/report/ExportToExcel_Report_Get_Opportunity?cardcode=' + cardcode + '&fromDate=' + fromDate + '&toDate=' + toDate+'&dbName='+this.dbName;
              window.location.href=url;
          }
}