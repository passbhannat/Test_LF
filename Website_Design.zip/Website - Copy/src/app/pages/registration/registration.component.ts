import { Component, OnInit,ElementRef, ViewChild } from '@angular/core';
import {FormGroup,FormControl, FormBuilder,FormArray, Validators,NgForm } from '@angular/forms';
import {Registration_Service}  from './registration_service';  
import {Common_Service}  from './../../common/common_service';  

import { Router } from '@angular/router';
 
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  @ViewChild('firstTabButton') firstTabButton: ElementRef<HTMLElement>;
  oForm;
  public  isloading = false;
  Addresses_Rows: any[] = [];
  array_State: Array<any> = [];
  array_Country: Array<any> = [];
  array_BankCode: Array<any> = [];
  //array_CompanyType: Array<any> = [];
  array_IndustryType: Array<any> = [];
  
  constructor(private _fb: FormBuilder,private _form_service: Registration_Service
    ,private _common_service: Common_Service
    ,private router: Router) {

   
   }
  ngOnInit() {

    this.oForm=this._fb.group({
      UserName:['',Validators.required],  
      UserType:['C',Validators.required],
      EmailAddress:['',Validators.required],
      PhoneNo:'',
      Password:['',Validators.required],
      ConfirmPassword:['',Validators.required],
      PANNo:['',Validators.required],
      PANCircleNo:'',
      VATNo:'',
      CSTNo:'',
      TANNo:'',
      TINNo:'',
      CINNo:'',
      MSMENo:'',
      Industry:'-1',
      CompanyType:'C',
      BankCountr:['IN',Validators.required],
      BankCode:['',Validators.required],
      DflAccount:['',Validators.required],
      DflSWift:['',Validators.required],

      Addresses_Rows: this._fb.array([ this.create_Addresses_Rows() ]),
      Attachment_Rows: this._fb.array([this.create_Attachment_Rows()])
  });

  this._common_service.State_DropDownValues('IN').subscribe(
    data=>{this.array_State=data
    },
    error=> alert(error)
    );

    this._common_service.Country_DropDownValues().subscribe(
      data=>{this.array_Country=data
      },
      error=> alert(error)
      );

      this._common_service.BankCode_DropDownValues().subscribe(
        data=>{this.array_BankCode=data
        },
        error=> alert(error)
        );
      this._common_service.Industry_DropDownValues().subscribe(
        data=>{this.array_IndustryType=data
        },
        error=> alert(error)
        );
      // this._common_service.CompanyType_DropDownValues().subscribe(
      //   data=>{this.array_CompanyType=data
      //   },
      //   error=> alert(error)
      //   ); 
        
        this.triggerFirstTabClick();
  }

  triggerFirstTabClick() {
    setTimeout(() => {
      this.firstTabButton.nativeElement.click();
      }, 200);
  }

  addRow_Addresses() {
    const control = <FormArray>this.oForm.controls['Addresses_Rows'];
    control.push(this.create_Addresses_Rows());
  }
  deleteRow_Addresses(index: number) {
      const control = <FormArray>this.oForm.controls['Addresses_Rows'];
      control.removeAt(index);
  }

  create_Addresses_Rows(): FormGroup {
    return this._fb.group({
      VisOrder: '',
      LineNum: '',
      Address: '',
      Street: '',
      Block: '',
      City: '',
      ZipCode: '',
      State: '',
      Country: 'IN',
      GSTType:'1',
      GSTRegnNo:'',
      AdresType:'B'
    });
  }

  adresType_Change(itemRow){
    let itemRow_FormGroup= itemRow as FormGroup;
    let adresType=itemRow_FormGroup.value.AdresType;
    if(adresType=="B"){
      // itemRow_FormGroup.value.GSTRegnNo='';
    }
  }
  
  register=function(event,formdata){
    let buttonText;
    buttonText=event.currentTarget.value
    if(buttonText=="Ok"){
       this.cancelForm();
       return;
    }
    
    if (!this.oForm.valid) {
      this.validateAllFormFields(this.oForm);
      return;
    }
    if(this.oForm.controls['Password'].value != this.oForm.controls['ConfirmPassword'].value){
      alert("Password should match with confirm password"); 
      return;
    }

    this.isloading=true;
    this._form_service.User_Create_User(formdata).subscribe(
        data=>{
          this.isloading=false;
          if(data[0].ReturnMessage_Code=="0"){
              alert(data[0].ReturnMessage_Description);
              //this.oForm.reset();
              this.router.navigate(['./login']);
          }
          else{
            alert(data[0].ReturnMessage_Description);
          }
        },
        error=>{
          this.isloading=false;
          alert(error)
        },
    );
  }

  create_Attachment_Rows(): FormGroup {
    return this._fb.group({
      LineId: '',
      FilePath: '',
      IsDeleted: false,
    });
  }

  add_Attachment_Rows() {
    const control = <FormArray>this.oForm.controls['Attachment_Rows'];
    control.push(this.create_Attachment_Rows());
    // this.form.control.markAsTouched();
    // this.form.control.markAsDirty();
  }

  remove_Attachment_Rows(itemRow) {
    let itemRow_FormGroup = itemRow as FormGroup;
    itemRow_FormGroup.value.IsDeleted = true;
    // this.form.control.markAsTouched();
    // this.form.control.markAsDirty();
  }

  onFileChange($event, index) {
    let files = $event.target.files;
    if (files.length > 0) {
      let formData: FormData = new FormData();
      for (var j = 0; j < files.length; j++) {
        formData.append("file[]", files[j], files[j].name);
        formData.append("description", this.oForm.controls["UserName"].value);
      }
      this._form_service.UploadAttachment(formData).subscribe(
          success => {
                 (<FormArray>this.oForm.controls['Attachment_Rows']).at(index).patchValue({FilePath :success});
          },
          error => {
            console.log(error);
          }) 
    }
  }

  
isFieldValid(field: string) {
  let value=!this.oForm.get(field).valid && this.oForm.get(field).touched;
  return value;
}

displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
  };
} 

validateAllFormFields(formGroup: FormGroup) {         //{1}
  Object.keys(formGroup.controls).forEach(field => {  //{2}
    const control = formGroup.get(field);             //{3}
    if (control instanceof FormControl) {             //{4}
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {        //{5}
      this.validateAllFormFields(control);            //{6}
    }
  });
}

openTab=function(evt, TabName){
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(TabName).style.display = "block";
  if(evt){
    evt.currentTarget.className += " active";
  }
}

}