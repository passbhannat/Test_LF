import { Injectable } from '@angular/core';  
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { Observable } from 'rxjs';  
import { environment } from '../../../environments/environment';
@Injectable({
    providedIn: 'root'
  })
export class Registration_Service  
{  
    private actionUrl: string;  
    constructor(private _http: HttpClient)  
    {  
       this.actionUrl = environment.apiEndpoint;
    }  
 
    User_Create_User=(formdata): Observable<any> =>
    { 
        let body = JSON.stringify(formdata);
        var url=this.actionUrl+'/master/User_Create_User';
        let headers = new HttpHeaders({
            'Content-Type': 'application/json'
         });
        let options = {
            headers: headers
         }
         return this._http.post(url,body,options); 
    }

    UploadAttachment(files){
        var url=this.actionUrl+'/master/UploadAttachment';
        let headers = new HttpHeaders({
         });
        let options = {
            headers: headers
         }
         return this._http.post(url,files,options);
    }
}