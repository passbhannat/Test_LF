import { Injectable } from '@angular/core';  
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable,throwError } from 'rxjs';  
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { map,tap } from 'rxjs/operators';

@Injectable()  
// @Injectable({
//     providedIn: 'root'
//   })
export class SalesOrder_Service  
{  
    private actionUrl: string; 
    public user: Array<any> = [];
    private territory: string; 
    private userID: string; 
    private userCode: string; 
    private dbName:string;

    constructor(private _http: HttpClient)  
    {  
       this.actionUrl = environment.apiEndpoint;
       let ltuser = localStorage.getItem('currentuser');
        if(ltuser){
            this.user =JSON.parse(ltuser);
            this.territory = this.user[0].Territory;
            this.userID = this.user[0].UserId;
            this.userCode = this.user[0].UserCode;
            this.dbName = this.user[0].DBName;
        }
     }  
  
     SalesOrder_Get_AllData = (searchText,pageNumber,noOfShowEntry): Observable<any> =>  
    {  
        var url=this.actionUrl+'/SalesOrder/SalesOrder_Get_AllData?searchText='+searchText+ '&pageNumber='+pageNumber+'&noOfShowEntry='+noOfShowEntry+'&userID='+this.userID+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    SalesOrder_Get_Record = (docEntry,isDraft): Observable<any> =>  
    {  
        var url=this.actionUrl+'/SalesOrder/SalesOrder_Get_Record?portalID='+docEntry + '&isDraft=' + isDraft+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    SalesOrder_InsertUpdate=(formdata): Observable<any> =>
    { 
        formdata.DBName = this.dbName;
        let body = JSON.stringify(formdata);
        var url=this.actionUrl+'/SalesOrder/SalesOrder_InsertUpdate';
        let headers = new HttpHeaders({
            'Content-Type': 'application/json'
         });
        let options = {
            headers: headers
         }
         return this._http.post(url,body,options); 
    }

    SalesOrder_Canceled = (docEntry,cancelReason): Observable<any> =>  
    {  
        var url=this.actionUrl+'/SalesOrder/SalesOrder_Canceled?docEntry=' + docEntry + '&cancelReason=' + cancelReason+'&dbName='+this.dbName;
        let headers = new HttpHeaders({
            'Content-Type': 'application/json'
         });
        let options = {
            headers: headers
         }
        return this._http.post(url,'',options); 
    }

    PrintCrystal = (docEntry,isDraft): Observable<any> =>  
    {  
        var url=this.actionUrl+'/SalesOrder/PrintCrystal?docEntry=' + docEntry + '&isDraft=' + isDraft + '&dbName='+this.dbName;
        return this._http.get(url, { responseType: 'blob' }).pipe(map(
            (res) => {
                    return new Blob([res], { type: 'application/pdf' })
                }));
    }

    
    // public PrintInvoiceReport(docEntry,customerType){
    //     var url=this.actionUrl+'/AR/PrintInvoiceReport?docEntry=' + docEntry + '&customerType=' + customerType;
    //     return this._http.get(url, { responseType: ResponseContentType.Blob }).map(
    //         (res) => {
    //                 return new Blob([res.blob()], { type: 'application/pdf' })
    //             });
    //   }

}