import { Component, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder, Validators, NgForm } from '@angular/forms';
import { SalesInvoice_Service } from './salesinvoice_service';
import { Common_Service } from './../../common/common_service';
import { ActivatedRoute, Router, Params } from "@angular/router";
import {DatePipe} from '@angular/common';
import { AuthorisedSideNavService } from '../../layout/authorised/services/authorised-side-nav.service';


@Component({
  selector: 'app-saleinvoice',
  templateUrl: './salesinvoice.component.html',
  styleUrls: ['./salesinvoice.component.scss', './salesinvoice.component.css'],
  providers:[SalesInvoice_Service ,Common_Service]
})

export class SalesInvoiceComponent implements OnInit {
  @ViewChild('firstTabButton') firstTabButton: ElementRef<HTMLElement>;
  @ViewChild('searchText') searchText: ElementRef;
  @ViewChild('form')

  form: NgForm;
  public oForm: FormGroup;
  public itemRows: FormGroup;
  public display_Message = "none";
  public ErrorMessage;
  public user: Array<any> = [];
  isDisabled = false;
  public display_BP_Parent = "none";
  public display_Item_Parent = "none";
  public display_Dealer_Parent = "none";
  public display_Freight_Parent ="none";
  public display_taxcode_Parent = "none";
  public display_SO_Parent = "none";

  public isFreightApplicable = "N";

  public boolShow_NewForm = false;
  boolAdd = false;
  public array_AllData: Array<any> = [];
  public array_Branch: Array<any> = [];
  public array_Warehouse: Array<any> = [];
  public array_SubGroup: Array<any> = [];
  public array_Dimenstion_State: Array<any> = [];
  public array_Dimenstion_ProductLine: Array<any> = [];
  public array_Dimenstion_CostElement: Array<any> = [];

  public array_ContactPerson: Array<any> = [];
  public array_Series: Array<any> = [];
  public array_ShipToCode: Array<any> = [];
  public array_BillToCode: Array<any> = [];
  public array_ShippingType: Array<any> = [];
  public array_SalesEmployee: Array<any> = [];
  public array_Employee: Array<any> = [];
  public array_Country: Array<any> = []; 
  public array_PayTerms: Array<any> = [];
  public array_ExpenseCode : Array<any> = [];

  //public array_TransCat: Array<any> = [];
  public array_PlaceofSupply: Array<any> = [];
  public array_State : Array<any> = [];

  //public array_TaxCode: Array<any> = [];
  public pageNumber = 1;
  public totalRowsCount = 0;
  public totalPageCount = 0;
  public noOfShowEntry = 10;
  formOpenByApproval1 = false;
  formOpenByApproval2 = false;
  formOpenByApproval3 = false;

  approvalPerson1 = "";
  approvalPerson2 = "";
  approvalPerson3 = "";
  position="";
  isloading = false;
  constructor(private _fb: FormBuilder, private _form_service: SalesInvoice_Service
    , private _common_service: Common_Service,private route: ActivatedRoute 
    ,private router: Router
    ,private datePipe: DatePipe
    ,public sideNavService: AuthorisedSideNavService
    ) { 
      let ltuser = localStorage.getItem('currentuser');
      this.user = JSON.parse(ltuser);
      this.position = this.user[0].Position;
      
      this._common_service.ExpenseType_DropDownValues().subscribe(
        data => {
          this.array_ExpenseCode = data
        },
        error => alert(error)
      );
      
   
      this.oForm = this._fb.group({
        SAPDocEntry:'',
        DBName:'',
        BPLId:'',
        DocEntry: '',
        PortalID: '',
        IsDraft:'',
        TerritoryID:'',
        DocNum: '',
        ObjType:'13',
        TransactionType:'GA',
        UserSign:'',
        CardCode: '',
        CardName: '',
        CntctCode:'',
        BPChannel:'',
        BPChannelCode:'',
        Series:'0',
        SeriesName:'',
        Branch:'',
        WhsCode:'',
        NumAtCard:'',
        PANNo:'',
        DocStatus:'O',
        AppStatus:'S',
        DealerCode:'',
        DealerName:'',
        BPBalance:'',
        DocDate: new Date(),
        YrofSanction:'',
        GSTRegnNo:'',
        GSTApplicable:'',
        BPOrders:'',
        DocDueDate: new Date(),
        PlaceofSupply:'',
        SubGroupCode:'',
        ChequeNumber:'',
        Deposit:'',
        ForeignName:'',
        SlpCode:'',
        OwnerName:'',
        OwnerID:'',
        Comments:'',
  
        TotalBefDisc:'',
        Header_DiscPer:'',
        Header_DiscAmt:'0',
        TotalExpns:'',
        FreightTaxAmount:'',
        Rounding:'0',
        Header_TaxAmt:'',
        DocTotal:'',
  
        ShipToCode:'',
        ShipToBuild:'',
        ShipToStreet:'',
        ShipToStreetNo:'',
        ShipToBlock:'',
        ShipToCity:'',
        ShipToZipCode:'',
        ShipToDistrict:'',
        ShipToCountry:'IN',
        ShipToState:'',
        ShippingType:'1',
  
        BillToCode:'',
        BillToBuild:'',
        BillToStreet:'',
        BillToStreetNo:'',
        BillToBlock:'',
        BillToCity:'',
        BillToZipCode:'',
        BillToDistrict:'',
        BillToCountry:'IN',
        BillToState:'',
  
        PayTerms: '',
        TransCat:'',
  
        BPGSTNo: '',
        LocGSTNo: '',
        TrnspCode:'',
       
        U_Reimburse:'',
        U_DealReemb:'',
        U_Subsidy:'',
        U_CDAllowed:'',
        U_Crop:'',
        U_VehicleNo:'',
        U_Trans:'',
        U_SystemType:'',
        U_Series:'',
        U_TODORC:'',
        U_Hectors:'',
        U_TOfSale:'',
        U_DivBranch:'',
        U_LRNo:'',
        U_WorkOrdrNo:'',
        U_Sharing:'',
        U_Destination:'',
        U_Deliv:'',
        U_SharDet:'',
        U_FName:'',
        U_BP_STATUS:'',
        U_SurveyNo:'',
        U_CrpSpMtr:'',
        U_LtrlSpnMTR:'',
        U_Other_Terms:'',
        U_Dispatch_From:'',
        U_Dispatch_State:'',
        U_Dispatch_PIN:'',
        U_Doc_Cat:'',
        U_TRAN_ID:'',
        U_VEH_TYP:'',
        U_Gen_EBILL:'',
        U_Sale_Type:'',
        U_Eway_Bill:'',

        EComerGSTN:'',
        ImpExpNo:'',
        Revision:'N',
        RevRefNo:'',
        RevRefDate:'',
        RevCreRefN:'',
        RevCreRefD:'',

        formOpenByApproval1:false,
        formOpenByApproval2:false,
        formOpenByApproval3:false,

        Approval1:'',
        Approval2:'',
        Approval3:'',
        IsAppr1:'',
        IsAppr2:'',
        IsAppr3:'',

        DocumentLines: this._fb.array([this.create_Item_Rows()]),
        ExpenseLines: this._fb.array([this.create_Freight_Rows()])
      });

      this.route.params.subscribe(params => 
        {
          if (params['portalid']) {
            this.setData(params['portalid'],params['apprno'],params['userid'],params['duplicate']);
          }
        });

    }

    setData(invoiceDocEntry,apprno,userid,duplicate) {
      if(apprno ==1){
        this.formOpenByApproval1 = true;
        this.approvalPerson1 = userid;
      }
      else if(apprno ==2){
        this.formOpenByApproval2= true;
        this.approvalPerson2 = userid;
      }
      else if(apprno ==3){
        this.formOpenByApproval3= true;
        this.approvalPerson3 = userid;
      }
      this.edit(invoiceDocEntry,'Y',duplicate);
    }

  ngOnInit() {
    this._common_service.SubGroup_DropDownValues().subscribe(
      data => {
      this.array_SubGroup = data
      },
      error => alert(error)
    );
   
    this._common_service.Dimesion_DropDownValues('State').subscribe(
      data => {
      this.array_Dimenstion_State = data
      },
      error => alert(error)
    );

    this._common_service.Dimesion_DropDownValues('ProductLine').subscribe(
      data => {
      this.array_Dimenstion_ProductLine = data
      },
      error => alert(error)
    );

    this._common_service.Dimesion_DropDownValues('CostElement').subscribe(
      data => {
      this.array_Dimenstion_CostElement = data
      },
      error => alert(error)
    );

   this._common_service.Country_DropDownValues().subscribe(
      data => {
      this.array_Country = data
      },
      error => alert(error)
    );

    this._common_service.State_DropDownValues('IN').subscribe(
      data => {
      this.array_PlaceofSupply = data;
      this.array_State = data;
      this.array_PlaceofSupply = data;

      },
      error => alert(error)
    );

     this._common_service.PaymentTerms_DropDownValues().subscribe(
      data => {
      this.array_PayTerms = data
      },
      error => alert(error)
    );
 
    this._common_service.ShippingType_DropDownValues().subscribe(
      data => {
      this.array_ShippingType = data
      },
      error => alert(error)
    );
 
    
    this.firstPage();
  }

  ngAfterViewInit() {
    
  };

  triggerFirstTabClick() {
    setTimeout(() => {
      this.firstTabButton.nativeElement.click();
      }, 200);
  }

  new() {
    this.sideNavService.hideSideNav = true;
    this.isDisabled = false;
    let ltuser = localStorage.getItem('currentuser');
    this.user = JSON.parse(ltuser);
    let userId =   this.user[0].UserId; 
    let territoryID = this.user[0].Territory;
    this.boolShow_NewForm = true;
    this.boolAdd = true;
    this.oForm.patchValue({
      SAPDocEntry:'',
      DocEntry: '',
      DocNum: '',
      PortalID: '',
      IsDraft:'',
      TerritoryID:territoryID,
      ObjType:'13',
      UserSign: userId,
      CardCode: '',
      CardName: '',
      CntctCode:'',
      BPChannel:'',
      BPChannelCode:'',
      TransactionType:'GA',
      Series:'0',
      Branch:this.user[0].BranchName,
      WhsCode:this.user[0].WhsCode,
      NumAtCard:'',
      PANNo:'',
      DocStatus:'O',
      AppStatus:'S',
      DealerCode:'',
      DealerName:'',
      BPBalance:'',
      DocDate: new Date(),
      YrofSanction:'',
      GSTRegnNo:'',
      GSTApplicable:'',
      BPOrders:'',
      DocDueDate: new Date(),
      PlaceofSupply:'',
      SubGroupCode:'',
      ChequeNumber:'',
      Deposit:'',
      ForeignName:'',
      SlpCode:'',
      OwnerName:'',
      OwnerID:'',
      Comments:'',

      TotalBefDisc:'',
      Header_DiscPer:'',
      Header_DiscAmt:'0',
      TotalExpns:'',
      FreightTaxAmount:'',

      Rounding:'0',
      Header_TaxAmt:'',
      DocTotal:'',

      ShipToCode:'',
      ShipToBuild:'',
      ShipToStreet:'',
      ShipToStreetNo:'',
      ShipToBlock:'',
      ShipToCity:'',
      ShipToZipCode:'',
      ShipToDistrict:'',
      ShipToCountry:'IN',
      ShipToState:'',
      ShippingType:'1',

      BillToCode:'',
      BillToBuild:'',
      BillToStreet:'',
      BillToStreetNo:'',
      BillToBlock:'',
      BillToCity:'',
      BillToZipCode:'',
      BillToDistrict:'',
      BillToCountry:'IN',
      BillToState:'',

      PayTerms: '',
      TransCat:'',

      BPGSTNo: '',
      LocGSTNo: '',
      TrnspCode:'',
     
      U_Reimburse:'',
      U_DealReemb:'',
      U_Subsidy:'',
      U_CDAllowed:'',
      U_Crop:'',
      U_VehicleNo:'',
      U_Trans:'',
      U_SystemType:'',
      U_Series:'',
      U_TODORC:'',
      U_Hectors:'',
      U_TOfSale:'',
      U_DivBranch:'',
      U_LRNo:'',
      U_WorkOrdrNo:'',
      U_Sharing:'',
      U_Destination:'',
      U_Deliv:'',
      U_SharDet:'',
      U_FName:'',
      U_BP_STATUS:'',
      U_SurveyNo:'',
      U_CrpSpMtr:'',
      U_LtrlSpnMTR:'',
      U_Other_Terms:'',
      U_Dispatch_From:'',
      U_Dispatch_State:'',
      U_Dispatch_PIN:'',
      U_Doc_Cat:'',
      U_TRAN_ID:'',
      U_VEH_TYP:'',
      U_Gen_EBILL:'',
      U_Sale_Type:'',
      U_Eway_Bill:'',

      Approval1:'',
      Approval2:'',
      Approval3:'',
      IsAppr1:'',
      IsAppr2:'',
      IsAppr3:''
    });

    const control_General = <FormArray>this.oForm.controls['DocumentLines'];
    control_General.controls = [];
    for(let i =0;i< 1;i++)
    {
      control_General.push(this.create_Item_Rows());
    }
    this._common_service.SalesEmployee_DropDownValues(territoryID).subscribe(
      data => {
      this.array_SalesEmployee = data
      },
      error => alert(error)
    );

    
    this._common_service.Warehouse_Get_AllData(this.user[0].WhsCode).subscribe(
      data => {
      this.array_Warehouse = data;
      this.oForm.controls["WhsCode"].setValue(this.user[0].WhsCode);
      },
      error => alert(error)
    );

    this._common_service.Series_Default('13').subscribe(
      data => {
        this.oForm.patchValue({
          Series: data
        });
      },
      error => alert(error)
    );

    const control_Freight = <FormArray>this.oForm.controls['ExpenseLines'];
    control_Freight.controls = [];
     for (let i = 0; i < this.array_ExpenseCode.length; i++) {
          control_Freight.push(this.create_Freight_Rows());
      }
      for (let i = 0; i < this.array_ExpenseCode.length; i++) {
        this.array_ExpenseCode[i].Amount = 0;
        this.array_ExpenseCode[i].TaxCode = '';
        this.array_ExpenseCode[i].TaxAmount = 0;
        this.array_ExpenseCode[i].TaxRate =0;
      }  
      
    this.oForm.patchValue({
      ExpenseLines: this.array_ExpenseCode
    });

    this.getSeries();
    this.triggerFirstTabClick();
  }

  create_Item_Rows(): FormGroup {
    let delDate = new Date();
    if(this.oForm)   {
      delDate =  this.oForm.controls['DocDueDate'].value;
    }
    return this._fb.group({
      LineId: '',
      ItemCode: '',
      ItemName: '',
      Remarks:'',
      InStock:'0',      
      Quantity: 0,
      SaleUOM:'',
      UnitPrice:'',
      DiscPer:'',
      DiscAmt:'',
      TaxCode: '',
      TaxRate:'0',
      TaxAmount: '0',

      Total: '0',
      WhsCode: '',
      DelDate:delDate,
      InvUOM:'N',
      ItemsPerUnit:'',
      InventoryUOM:'',
      OpenQty:'',
      DelQty:'',
      PrjCode:'',
      CommPer:'',
      ReplacementItem:'NO',
      LineStatus:'O',

      BaseEntry:'',
      BaseRef:'',
      BaseLine:'',
      BaseObj:'',

      RowState:'',
      ProductLine:'',
      CostElement:'',
      CustomerGeography:'',

      GenDisc:'',
      GDWithSubsidy:'',
      AddlDisc:'',
      TradeDisc:'',
      SpecialDisc:'',
      CashDisc:'',
      
      GenDisc_Temp:'',
      GDWOSubsidy_Temp:'',
      GDWithSubsidy_Temp:'',
      CashDisc_Temp:'',
      AddlDisc_Temp:'',
      TradeDisc_Temp:'',
      SpecialDisc_Temp:'',

      IsDeleted: false,
    });
  }

  create_Freight_Rows(): FormGroup {
    return this._fb.group({
      LineId: '',
      ExpnsCode: '',
      ExpnsName: '',
      Amount: '',
      TaxCode: '',
      TaxRate: '',
      TaxAmount: '',
       Remarks:'',
    });
  }
  
  getSeries()
  {
    let docdate = this.oForm.controls["DocDate"].value;
    let docsubtype = this.oForm.controls["TransactionType"].value;
    let whscode = this.oForm.controls["WhsCode"].value;

    let docDate_Transform = this.datePipe.transform(docdate,"yyyy-MM-dd");
    this._common_service.Series_DropDownValues('13',docDate_Transform,docsubtype,whscode).subscribe(
      data => {
      this.array_Series = data
      if(data.length == 1){
        setTimeout(() => {
          this.oForm.controls["Series"].setValue(data[0].Series);
          }, 200);
      }
      },
      error => alert(error)
    );
  }

  edit(DocEntry,IsDraft,duplicate) {
    this.boolShow_NewForm = true;
    if(duplicate == "Y"){
      this.boolAdd = true;
    }
    else {
      this.boolAdd = false;
    }
    this._form_service.SalesInvoice_Get_Record(DocEntry,IsDraft).subscribe(
      data => {
        let docsubtype = data[0].TransactionType;
        let docdate = data[0].DocDate;
        let docDate_Transform = this.datePipe.transform(docdate,"yyyy-MM-dd");
        let headerwhscode =  data[0].Header_WhsCode;

        this._common_service.Series_DropDownValues('13',docDate_Transform,docsubtype,headerwhscode).subscribe(
          data => {
          this.array_Series = data
          },
          error => alert(error)
        );
        this._common_service.Warehouse_Get_AllData(data[0].Header_WhsCode).subscribe(
          data => {
          this.array_Warehouse = data
          },
          error => alert(error)
        );

        this._common_service.SalesEmployee_DropDownValues(data[0].TerritoryID).subscribe(
          data => {
          this.array_SalesEmployee = data
          },
          error => alert(error)
        );
    
        const control_Item_Rows = <FormArray>this.oForm.controls['DocumentLines'];
        control_Item_Rows.controls = [];
        if (!(data[0].DocumentLines == "undefined" || data[0].DocumentLines == null)) {
          for (let i = 0; i < data[0].DocumentLines.length; i++) {
            data[0].DocumentLines[i].DelDate = new Date(data[0].DocumentLines[i].DelDate);
            control_Item_Rows.push(this.create_Item_Rows());
          }
        }
        
        // const control_Expense_Rows = <FormArray>this.oForm.controls['ExpenseLines'];
        // control_Expense_Rows.controls = [];
        // if (!(data[0].ExpenseLines == "undefined" || data[0].ExpenseLines == null)) {
        //   for (let i = 0; i < data[0].ExpenseLines.length; i++) {
        //     control_Expense_Rows.push(this.create_Freight_Rows());
        //   }
        // }
         
        const control_Freight = <FormArray>this.oForm.controls['ExpenseLines'];
        control_Freight.controls = [];
        for (let i = 0; i < this.array_ExpenseCode.length; i++) {
              control_Freight.push(this.create_Freight_Rows());
        }

        let editExpenseCode = this.array_ExpenseCode;
        for (let i = 0; i < data[0].ExpenseLines.length; i++) {
          editExpenseCode[i].Amount = data[0].ExpenseLines[i].Amount;
          editExpenseCode[i].TaxCode = data[0].ExpenseLines[i].TaxCode;
          editExpenseCode[i].TaxAmount = data[0].ExpenseLines[i].TaxAmount;
          editExpenseCode[i].TaxRate = data[0].ExpenseLines[i].TaxRate;
        }
        this.oForm.patchValue({
          ExpenseLines: editExpenseCode
        });
        
        this.oForm.patchValue({
          HeaderTableName: "ORDR",
          IsDraft: data[0].IsDraft,
          PortalID: data[0].PortalID,
          TerritoryID: data[0].TerritoryID,
          Branch: data[0].BranchName,
          DocEntry: data[0].DocEntry,
          DocNum: data[0].DocNum,
          SeriesName: data[0].SeriesName,
          ObjType: "13",
          SAPDocEntry: data[0].SAPDocEntry,
          DocStatus: data[0].DocStatus,
          DocDate: new Date(data[0].DocDate),
          DocDueDate: new Date(data[0].DocDueDate),
          CardCode: data[0].CardCode,
          CardName: data[0].CardName,
          NumAtCard: data[0].NumAtCard,
          LocGSTNo: data[0].LocGSTNo,
          BPGSTNo: data[0].BPGSTNo,
          PayTerms: data[0].PayTerms,
          Comments: data[0].Comments,
          CntctCode:data[0].CntctCode,
          BPChannel:data[0].BPChannel,
          BPChannelCode:data[0].BPChannelCode,
          TransactionType:data[0].TransactionType,
          Series:data[0].Series,
          WhsCode:data[0].WhsCode,
          PANNo:data[0].PANNo,
          DealerCode:data[0].DealerCode,
          DealerName:data[0].DealerName,
          BPBalance:data[0].BPBalance,
          YrofSanction:data[0].YrofSanction,
          GSTRegnNo:data[0].GSTRegnNo,
          GSTApplicable:data[0].GSTApplicable,
          BPOrders:data[0].BPOrders,
          PlaceofSupply:data[0].PlaceofSupply,
          SubGroupCode:data[0].SubGroupCode,
          ChequeNumber:data[0].ChequeNumber,
          Deposit:data[0].Deposit,
          ForeignName:data[0].ForeignName,
          SlpCode:data[0].SlpCode,
    
          TotalBefDisc:data[0].TotalBefDisc,
          Header_DiscPer:data[0].Header_DiscPer,
          Header_DiscAmt:data[0].Header_DiscAmt,
          TotalExpns:data[0].TotalExpns,
          Rounding:data[0].Rounding,
          Header_TaxAmt:data[0].Header_TaxAmt,
          DocTotal: data[0].DocTotal,
          FreightTaxAmount:data[0].FreightTaxAmount,
    
          ShipToCode:data[0].ShipToCode,
          ShipToBuild:data[0].ShipToBuild,
          ShipToStreet:data[0].ShipToStreet,
          ShipToStreetNo:data[0].ShipToStreetNo,
          ShipToBlock:data[0].ShipToBlock,
          ShipToCity:data[0].ShipToCity,
          ShipToZipCode:data[0].ShipToZipCode,
          ShipToDistrict:data[0].ShipToDistrict,
          ShipToCountry:data[0].ShipToCountry,
          ShipToState:data[0].ShipToState,
          ShippingType:data[0].ShippingType,
    
          BillToCode:data[0].BillToCode,
          BillToBuild:data[0].BillToBuild,
          BillToStreet:data[0].BillToStreet,
          BillToStreetNo:data[0].BillToStreetNo,
          BillToBlock:data[0].BillToBlock,
          BillToCity:data[0].BillToCity,
          BillToZipCode:data[0].BillToZipCode,
          BillToDistrict:data[0].BillToDistrict,
          BillToCountry:data[0].BillToCountry,
          BillToState:data[0].BillToState,
          TrnspCode:data[0].TrnspCode,
          U_Reimburse:data[0].U_Reimburse,
          U_DealReemb:data[0].U_DealReemb,
          U_Subsidy:data[0].U_Subsidy,
          U_CDAllowed:data[0].U_CDAllowed,
          U_Crop:data[0].U_Crop,
          U_VehicleNo:data[0].U_VehicleNo,
          U_Trans:data[0].U_Trans,
          U_SystemType:data[0].U_SystemType,
          U_Series:data[0].U_Series,
          U_TODORC:data[0].U_TODORC,
          U_Hectors:data[0].U_Hectors,
          U_TOfSale:data[0].U_TOfSale,
          U_DivBranch:data[0].U_DivBranch,
          U_LRNo:data[0].U_LRNo,
          U_WorkOrdrNo:data[0].U_WorkOrdrNo,
          U_Sharing:data[0].U_Sharing,
          U_Destination:data[0].U_Destination,
          U_Deliv:data[0].U_Deliv,
          U_SharDet:data[0].U_SharDet,
          U_FName:data[0].U_FName,
          U_BP_STATUS:data[0].U_BP_STATUS,
          U_SurveyNo:data[0].U_SurveyNo,
          U_CrpSpMtr:data[0].U_CrpSpMtr,
          U_LtrlSpnMTR:data[0].U_LtrlSpnMTR,
          U_Other_Terms:data[0].U_Other_Terms,
          U_Dispatch_From:data[0].U_Dispatch_From,
          U_Dispatch_State:data[0].U_Dispatch_State,
          U_Dispatch_PIN:data[0].U_Dispatch_PIN,
          U_Doc_Cat:data[0].U_Doc_Cat,
          U_TRAN_ID:data[0].U_TRAN_ID,
          U_VEH_TYP:data[0].U_VEH_TYP,
          U_Gen_EBILL:data[0].U_Gen_EBILL,
          U_Sale_Type:data[0].U_Sale_Type,
          U_Eway_Bill:data[0].U_Eway_Bill,

          IsAppr1: data[0].IsAppr1,
          IsAppr2: data[0].IsAppr2,
          IsAppr3: data[0].IsAppr3,
     
          DocumentLines: data[0].DocumentLines,
          // ExpenseLines: data[0].ExpenseLines
        });
        this.oForm.controls["formOpenByApproval1"].setValue(this.formOpenByApproval1);
        this.oForm.controls["formOpenByApproval2"].setValue(this.formOpenByApproval2);
        this.oForm.controls["formOpenByApproval3"].setValue(this.formOpenByApproval3);

        if( this.formOpenByApproval1 == true ||  this.formOpenByApproval2 == true ||  this.formOpenByApproval3 == true || data[0].SAPDocEntry !=""){
          this.isDisabled= true;
        }
        if(this.boolAdd == true){
          this.oForm.controls["PortalID"].setValue('');
          this.oForm.controls["DocEntry"].setValue(0);
          this.oForm.controls["IsDraft"].setValue('Y');
        }
        this.returnBPCode(data[0].CardCode);
        setTimeout(() => {
          this.oForm.controls["Series"].setValue(data[0].Series);
          this.oForm.controls["SlpCode"].setValue(data[0].SlpCode);
          this.oForm.controls["WhsCode"].setValue(data[0].Header_WhsCode);
          }, 200);
        this.triggerFirstTabClick();
      },
      error => alert(error),
    );
  }

  CopyFromSO(DocEntry) {
    this.boolShow_NewForm = true;
    this.boolAdd = true;
    let  whscode = this.oForm.controls['WhsCode'].value;
    this._common_service.CopyFrom_SalesOrder_Get_Record(DocEntry,whscode).subscribe(
      data => {
        // this._common_service.Warehouse_Get_AllData(data[0].Header_WhsCode).subscribe(
        //   data => {
        //   this.array_Warehouse = data
        //   },
        //   error => alert(error)
        // );

        // this._common_service.SalesEmployee_DropDownValues(data[0].TerritoryID).subscribe(
        //   data => {
        //   this.array_SalesEmployee = data
        //   },
        //   error => alert(error)
        // );
    
        const control_Item_Rows = <FormArray>this.oForm.controls['DocumentLines'];
        control_Item_Rows.controls = [];
        if (!(data[0].DocumentLines == "undefined" || data[0].DocumentLines == null)) {
          for (let i = 0; i < data[0].DocumentLines.length; i++) {
            data[0].DocumentLines[i].DelDate = new Date(data[0].DocumentLines[i].DelDate);
            control_Item_Rows.push(this.create_Item_Rows());
          }
        }
         
        const control_Freight = <FormArray>this.oForm.controls['ExpenseLines'];
        control_Freight.controls = [];
        for (let i = 0; i < this.array_ExpenseCode.length; i++) {
              control_Freight.push(this.create_Freight_Rows());
        }

        let editExpenseCode = this.array_ExpenseCode;
        for (let i = 0; i < data[0].ExpenseLines.length; i++) {
          editExpenseCode[i].Amount = data[0].ExpenseLines[i].Amount;
          editExpenseCode[i].TaxCode = data[0].ExpenseLines[i].TaxCode;
          editExpenseCode[i].TaxAmount = data[0].ExpenseLines[i].TaxAmount;
          editExpenseCode[i].TaxRate = data[0].ExpenseLines[i].TaxRate;
        }
        this.oForm.patchValue({
          ExpenseLines: editExpenseCode
        });
        
        this.oForm.patchValue({
          HeaderTableName: "OINV",
          PayTerms: data[0].PayTerms,
          Comments: data[0].Comments,
          
          TotalBefDisc:data[0].TotalBefDisc,
          Header_DiscPer:data[0].Header_DiscPer,
          Header_DiscAmt:data[0].Header_DiscAmt,
          TotalExpns:data[0].TotalExpns,
          Rounding:data[0].Rounding,
          Header_TaxAmt:data[0].Header_TaxAmt,
          DocTotal: data[0].DocTotal,
          FreightTaxAmount:data[0].FreightTaxAmount,
          SlpCode:data[0].SlpCode,
           
          TrnspCode:data[0].TrnspCode,
          U_Reimburse:data[0].U_Reimburse,
          U_DealReemb:data[0].U_DealReemb,
          U_Subsidy:data[0].U_Subsidy,
          U_CDAllowed:data[0].U_CDAllowed,
          U_Crop:data[0].U_Crop,
          U_VehicleNo:data[0].U_VehicleNo,
          U_Trans:data[0].U_Trans,
          U_SystemType:data[0].U_SystemType,
          U_Series:data[0].U_Series,
          U_TODORC:data[0].U_TODORC,
          U_Hectors:data[0].U_Hectors,
          U_TOfSale:data[0].U_TOfSale,
          U_DivBranch:data[0].U_DivBranch,
          U_LRNo:data[0].U_LRNo,
          U_WorkOrdrNo:data[0].U_WorkOrdrNo,
          U_Sharing:data[0].U_Sharing,
          U_Destination:data[0].U_Destination,
          U_Deliv:data[0].U_Deliv,
          U_SharDet:data[0].U_SharDet,
          U_FName:data[0].U_FName,
          U_BP_STATUS:data[0].U_BP_STATUS,
          U_SurveyNo:data[0].U_SurveyNo,
          U_CrpSpMtr:data[0].U_CrpSpMtr,
          U_LtrlSpnMTR:data[0].U_LtrlSpnMTR,
          U_Other_Terms:data[0].U_Other_Terms,
          U_Dispatch_From:data[0].U_Dispatch_From,
          U_Dispatch_State:data[0].U_Dispatch_State,
          U_Dispatch_PIN:data[0].U_Dispatch_PIN,
          U_Doc_Cat:data[0].U_Doc_Cat,
          U_TRAN_ID:data[0].U_TRAN_ID,
          U_VEH_TYP:data[0].U_VEH_TYP,
          U_Gen_EBILL:data[0].U_Gen_EBILL,
          U_Sale_Type:data[0].U_Sale_Type,
          U_Eway_Bill:data[0].U_Eway_Bill,
 
          DocumentLines: data[0].DocumentLines,
          // ExpenseLines: data[0].ExpenseLines
        });
       
      },
      error => alert(error),
    );
  }


  cancelForm() {
    this.oForm.reset();
    this.isloading = true;
    this.boolShow_NewForm = false;
    this.isloading = false;
    this.router.navigate(['/salesinvoice']);
  }

  printForm() {
    let docEntry = this.oForm.controls["DocEntry"].value;
    this._form_service.PrintCrystal(docEntry).subscribe(data => 
      {
        const blobUrl = URL.createObjectURL(data);
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = blobUrl;
        document.body.appendChild(iframe);
        iframe.contentWindow.print();
      });
  }
  add_Item_Rows() {
    const control = <FormArray>this.oForm.controls['DocumentLines'];
    control.push(this.create_Item_Rows());
    this.form.control.markAsTouched();
    this.form.control.markAsDirty();
  }

  remove_Item_Rows(itemRow,index) {
    let itemRow_FormGroup = itemRow as FormGroup;
    const control = <FormArray>this.oForm.controls['DocumentLines'];
    control.removeAt(index);
    //itemRow_FormGroup.value.IsDeleted = true;
    this.form.control.markAsTouched();
    this.form.control.markAsDirty();
  }

  showAllRecords(pageNumber) {
    this.isloading = true;

    let searchText = ''
    if (this.searchText) {
      searchText = this.searchText.nativeElement.value;
    }
     
    this._form_service.SalesInvoice_Get_AllData(searchText, pageNumber, this.noOfShowEntry).subscribe(
      data => {
      this.array_AllData = data;
        if (data.length > 0) {
          this.totalRowsCount = data[0].TotalRowsCount;
          this.totalPageCount = Math.ceil(data[0].TotalRowsCount / this.noOfShowEntry);
        }
        else {
          this.totalRowsCount = 0;
          this.totalPageCount = 0;
        }
        this.isloading = false;
      },
      error => {
        this.isloading = false;
        alert(error);
      }
    );
  }

  
bpcode_Tab=function(CardcodeField,showForm){
  let value=this.oForm.controls[CardcodeField].value;
  if(value == "" || showForm =="Y"){
    this.bool_CardCodeField=CardcodeField;
    this.display_BP_Parent="block";
  }
}

returnBPDisplayStyle(event) {
  if (event == "none") {
    this.display_BP_Parent = "none";
  }
}


copyFromSO(){
  let cardCode = this.oForm.controls["CardCode"].value;
 if(!cardCode){
   alert("Please select customer");
   return;
 }   
 this.display_SO_Parent="block";      
}

returnSODisplayStyle(event) {
  if (event == "none") {
    this.display_SO_Parent = "none";
  }
}

returnSODocEntry(sodocentry) {
  this.CopyFromSO(sodocentry);
}


dealer_Tab=function(){
  this.display_Dealer_Parent="block";
}

returnDealerDisplayStyle(event) {
if (event == "none") {
  this.display_Dealer_Parent = "none";
}
}

itemcode_Tab = function (itemrow) {
  this.itemRows = itemrow;
  this.display_Item_Parent = "block";
}

returnItemDisplayStyle(event) {
  if (event == "none") {
    this.display_Item_Parent = "none";
  }
}

  taxcode_Tab = function (itemrow,freight) {
    this.itemRows = itemrow;
    this.isFreightApplicable  = freight;
    this.display_taxcode_Parent = "block";
  }


  returnDisplayStyle(event) {
    if (event == "none") {
      this.display_taxcode_Parent = "none";
    }
  }

  returnBPCode(cardcode) {
    //#region Set CardName
    this._common_service.BP_Get_CardCode_Details(cardcode).subscribe(
    data=>{
        this.oForm.controls['CardCode'].setValue(cardcode);
        this.oForm.controls['CardName'].setValue(data[0].CardName);
        this.oForm.controls['BPChannel'].setValue(data[0].BPChannel);
        this.oForm.controls['BPChannelCode'].setValue(data[0].BPChannelCode);

        this.oForm.controls['DealerName'].setValue(data[0].BPChannel);
        this.oForm.controls['DealerCode'].setValue(data[0].BPChannelCode);

        this.oForm.controls['ForeignName'].setValue(data[0].ForeignName);
        this.oForm.controls['PANNo'].setValue(data[0].PANNo);
        this.oForm.controls['YrofSanction'].setValue(data[0].YrofSanction);
        this.oForm.controls['ChequeNumber'].setValue(data[0].ChequeNumber);
        this.oForm.controls['GSTApplicable'].setValue(data[0].GSTApplicable);
        this.oForm.controls['BPOrders'].setValue(data[0].OrdersBal);
        this.oForm.controls['BPBalance'].setValue(data[0].Balance);
        this.oForm.controls['PlaceofSupply'].setValue(data[0].PlaceofSupply);
        this.oForm.controls['GSTRegnNo'].setValue(data[0].GSTRegnNo);

        this.oForm.controls['SubGroupCode'].setValue(data[0].SubGroup);
        this.oForm.controls['Deposit'].setValue(data[0].Deposit);
        this.oForm.controls['SlpCode'].setValue(data[0].SlpCode);
        this.oForm.controls['PayTerms'].setValue(data[0].PayTerms);
        
        let contactPerson = data[0].DefaultContactPersonID;
        this._common_service.ContactPerson_DropDownValues(cardcode).subscribe(
          dataCP => {
          this.array_ContactPerson = dataCP;
          this.oForm.controls['CntctCode'].setValue(contactPerson);
        },         
          error => alert(error)
        );

         this._common_service.BPAddress_Get_AllData(cardcode,'S').subscribe(
          dataBPAddr_ShipTo => {
          this.array_ShipToCode = dataBPAddr_ShipTo;
          setTimeout(() => {
            this.oForm.controls['ShipToCode'].setValue(data[0].ShipToDef);
            this.SetShipToDetails();
            }, 200);
          },
          error => alert(error)
        );

      this._common_service.BPAddress_Get_AllData(cardcode,'B').subscribe(
        dataBPAddr_BillTo => {
          this.array_BillToCode = dataBPAddr_BillTo;
          setTimeout(() => {
            this.oForm.controls['BillToCode'].setValue(data[0].BillToDef);
            this.SetBillToDetails();
            }, 200);
        },
        error => alert(error)
      );

      
    },
    error=> alert(error)
    );
    //#endregion
  }

  SetShipToDetails(){
    let cardcode =  this.oForm.controls['CardCode'].value;
    let addressID = this.oForm.controls['ShipToCode'].value;
    this._common_service.Address_Details(cardcode,'S',addressID).subscribe(
      data => {
        this.oForm.controls['ShipToBuild'].setValue(data[0].Building);
        this.oForm.controls['ShipToStreet'].setValue(data[0].Street);
        this.oForm.controls['ShipToStreetNo'].setValue(data[0].StreetNo);
        this.oForm.controls['ShipToBlock'].setValue(data[0].Block);
        this.oForm.controls['ShipToCity'].setValue(data[0].City);
        this.oForm.controls['ShipToZipCode'].setValue(data[0].ZipCode);
        this.oForm.controls['ShipToDistrict'].setValue(data[0].County);
        this.oForm.controls['ShipToCountry'].setValue(data[0].Country);
        this.oForm.controls['ShipToState'].setValue(data[0].State);
      },
      error => {
        alert(error);
      }
    );  
  }

  SetBillToDetails(){
    let cardcode =  this.oForm.controls['CardCode'].value;
    let addressID = this.oForm.controls['BillToCode'].value;
    this._common_service.Address_Details(cardcode,'B',addressID).subscribe(
      data => {
        this.oForm.controls['BillToBuild'].setValue(data[0].Building);
        this.oForm.controls['BillToStreet'].setValue(data[0].Street);
        this.oForm.controls['BillToStreetNo'].setValue(data[0].StreetNo);
        this.oForm.controls['BillToBlock'].setValue(data[0].Block);
        this.oForm.controls['BillToCity'].setValue(data[0].City);
        this.oForm.controls['BillToZipCode'].setValue(data[0].ZipCode);
        this.oForm.controls['BillToDistrict'].setValue(data[0].County);
        this.oForm.controls['BillToCountry'].setValue(data[0].Country);
        this.oForm.controls['BillToState'].setValue(data[0].State);
      },
      error => {
        alert(error);
      }
    );  
  }
  
  returnItemCode(itemcode) {
    let itemRow = this.itemRows;
    let cardcode = this.oForm.controls["CardCode"].value;
    let whscode = this.oForm.controls["WhsCode"].value;
    let placeofSupply = this.oForm.controls["PlaceofSupply"].value;
    this._common_service.Item_GetDetails(itemcode,whscode,cardcode,placeofSupply).subscribe(
      data => {
        let itemRow_FormGroup = itemRow as FormGroup;
        itemRow_FormGroup.patchValue(
        {
          ItemCode: itemcode,
          ItemName: data[0].ItemName,
          ItemsPerUnit: data[0].NumInSale,
          InStock: data[0].InStock,
          SaleUOM: data[0].SalUnitMsr,
          UnitPrice: data[0].UnitPrice,
          DiscPer:0, //data[0].DiscPer,
          WhsCode: whscode,
          InvUOM: "N",
          InventoryUOM: data[0].InvntryUom,

          AddlDisc: 0,
          SpecialDisc: 0,
          TradeDisc: 0,
          CashDisc:0,
          GenDisc: 0,
          GDWithSubsidy: 0,

          
          AddlDisc_Temp: data[0].AddlDisc,
          SpecialDisc_Temp: data[0].SpecialDisc,
          TradeDisc_Temp: data[0].TradeDisc,
          CashDisc_Temp: data[0].CashDisc,
          GDWOSubsidy_Temp: data[0].GDWOSubsidy,
          GDWithSubsidy_Temp: data[0].GDWithSubsidy,

        });
      },
      error => {
        alert(error);
      }
    );    
  }

  returnTaxCode(taxcode) {
    let itemRow = this.itemRows;
    
      this._common_service.TaxCode_GetDetails(taxcode).subscribe(
        data => {
          let itemRow_FormGroup = itemRow as FormGroup;
          
          let taxrate =data[0].Rate;
          if(this.isFreightApplicable == 'N'){
            let amount = itemRow_FormGroup.value.Total;
            let taxAmount = taxrate * amount/100 ;
            itemRow_FormGroup.patchValue(
              {
                TaxCode: taxcode,
                TaxRate: taxrate,
                TaxAmount: taxAmount,
              });
              this.row_change_quantity(itemRow);
          }
          else{
            let amount = itemRow_FormGroup.value.Amount;
            let taxAmount = taxrate * amount/100 ;
            itemRow_FormGroup.patchValue(
              {
                TaxCode: taxcode,
                TaxRate: taxrate,
                TaxAmount: taxAmount,
              });
          }     
          //this.calculate_doctotal();
        },
        error => {
          alert(error);
        }
      ); 
    
  }

  returnEmployeeID(id) {
    this.oForm.controls['OwnerID'].setValue(id);
  }
  returnEmployeeName(name) {
    this.oForm.controls['OwnerName'].setValue(name);
  }

  returnDealerCode(id) {
    this.oForm.controls['DealerCode'].setValue(id);
  }
  returnDealerName(name) {
    this.oForm.controls['DealerName'].setValue(name);
  }
  

Calculation(){
  const control_Rows = <FormArray>this.oForm.controls['DocumentLines'];
  let lineTotal = 0;
  let taxAmount = 0;
  let grossTotal = 0;

 for (let c of control_Rows.controls) {
  let isdeleted = c.value.IsDeleted;
  if(isdeleted == false){
   let amount = +c.value.GrAmount;
   //let taxPer = +c.value.TaxRate;
   //taxAmount = taxAmount + (amount*taxPer)/100;
   grossTotal = amount+grossTotal;
  }
 }
 this.oForm.controls['DocTotal'].setValue(grossTotal);
}

row_change_invuom(itemRow){
  let cardcode = this.oForm.controls["CardCode"].value;
  let itemRow_FormGroup= itemRow as FormGroup;
  let itemCode = itemRow_FormGroup.value.ItemCode;
  let invuom = itemRow_FormGroup.value.InvUOM;
  this._common_service.Item_GetPrice(cardcode,itemCode,invuom).subscribe(
    data => {
      itemRow_FormGroup.patchValue(
        {
          UnitPrice : data
        });
        this.row_change_quantity(itemRow);
    },
    error => {
      alert(error);
    }
  ); 
  
}

row_freight_change(itemRow){
  let itemRow_FormGroup= itemRow as FormGroup;
  let taxrate = itemRow_FormGroup.value.TaxRate;
  let amount = itemRow_FormGroup.value.Amount;
  let taxAmount = taxrate * amount/100 ;
  itemRow_FormGroup.patchValue(
    {
      TaxAmount: taxAmount,
    });
}


print(){
  let docEntry = this.oForm.controls['DocEntry'].value;
  let customerTypeID = this.oForm.controls['CustomerTypeID'].value;

  // this._common_Service.PrintInvoiceReport(docEntry).subscribe(res => 
  //   {
  //     var fileURL = URL.createObjectURL(res);
  //     window.open(fileURL);
  //   }
  // );

}

  showEntries(event) {
    this.noOfShowEntry = event.currentTarget.value;
    this.showAllRecords(this.pageNumber - 1);
  }
  firstPage() {
    this.pageNumber = 1;
    this.showAllRecords(this.pageNumber - 1);
  }
  nextPage() {
    if (this.pageNumber == this.totalPageCount) {
      return;
    }
    this.pageNumber = this.pageNumber + 1;
    this.pageNumber = this.pageNumber;
    this.showAllRecords(this.pageNumber - 1);
  }
  previousPage() {
    if (this.pageNumber == 1) {
      return;
    }
    this.pageNumber = this.pageNumber - 1;
    this.showAllRecords(this.pageNumber - 1);
  }
  lastPage() {
    this.pageNumber = Math.ceil(this.totalRowsCount / this.noOfShowEntry);
    this.showAllRecords(this.pageNumber - 1);
  }


  openTab = function (evt, TabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(TabName).style.display = "block";
    if (evt) {
      evt.currentTarget.className += " active";
    }
  }


  output_close_Modal(event) {
    this.display_Message = event;
  }

  
open_FreightModal=function(){
    this.display_Freight_Parent="block";
   
}
  close_FreightModal() {
    this.display_Freight_Parent = "none";
  }

  copy_frieght_to_document(){
    this.display_Freight_Parent = "none";
    const control_Frieght_Rows = <FormArray>this.oForm.controls['ExpenseLines'];
    let total = 0;
    let totalTaxAmt = 0;

    for (let c of control_Frieght_Rows.controls) {
      let expAmt = +c.value.Amount
      let taxAmt = +c.value.TaxAmount
      total = total + expAmt;
      totalTaxAmt = totalTaxAmt + taxAmt;
    }
    this.oForm.controls['TotalExpns'].setValue(total);
    this.oForm.controls['FreightTaxAmount'].setValue(totalTaxAmt);

    this.calculate_doctotal();
  }

  row_change_quantity(itemRow){
  let itemRow_FormGroup= itemRow as FormGroup;
  let quantity = +itemRow_FormGroup.value.Quantity;
  let unitprice = +itemRow_FormGroup.value.UnitPrice;
  let taxRate = +itemRow_FormGroup.value.TaxRate;
  let headerDiscPer = +this.oForm.controls['Header_DiscPer'].value;;
  let discPer = +itemRow_FormGroup.value.DiscPer;
  let discAmt = (quantity * unitprice) * discPer/100;
  let rowTotal1 = quantity * unitprice ;
  let rowTotal2 =  quantity * unitprice * discPer / 100 ;
  let rowTotal = rowTotal1 - rowTotal2;
  let taxamount = (rowTotal * taxRate/100) - (rowTotal * taxRate/100)* headerDiscPer/100;
  //let rowTotal =  (quantity * unitprice) - discAmt;
  itemRow_FormGroup.patchValue(
  {
      Total : rowTotal,
      DiscAmt : discAmt,
      TaxAmount: taxamount
      //TaxAmount : quantity * unitprice * taxRate/100 ,
    });

    const control_DocumentLines = <FormArray>this.oForm.controls['DocumentLines'];
    let totalBefDisc = 0;
    let totalTax = 0;

    for (let c of control_DocumentLines.controls) {
      if(c.value.IsDeleted == false){
      let amount = +c.value.Total;
      let taxamt = +c.value.TaxAmount;

      totalBefDisc = totalBefDisc + amount;
      totalTax = totalTax + taxamt;
      }
    }
    this.oForm.controls['TotalBefDisc'].setValue(totalBefDisc.toFixed(2));
    this.oForm.controls['Header_TaxAmt'].setValue(totalTax);
    this.calculate_doctotal();
  }

  calculate_rowTax(){
    const control_DocumentLines = <FormArray>this.oForm.controls['DocumentLines'];
    let totalBefDisc = 0;
    let totalTax = 0;
    let headerDiscPer = +this.oForm.controls['Header_DiscPer'].value;;

    for (let c of control_DocumentLines.controls) {
      if(c.value.IsDeleted == false){
      let rowTotal = +c.value.Total;
      let rowTaxRate = +c.value.TaxRate;
      let rowTaxamount = (rowTotal * rowTaxRate/100) - (rowTotal * rowTaxRate/100)* headerDiscPer/100;
      c.get('TaxAmount').setValue(rowTaxamount);
      totalTax = totalTax + rowTaxamount;
      }
    }
    this.oForm.controls['Header_TaxAmt'].setValue(totalTax);
    this.calculate_doctotal();
  }

  row_total_Change(itemRow){
  let itemRow_FormGroup= itemRow as FormGroup;
  let total = +itemRow_FormGroup.value.Total;
  let taxAmount = +itemRow_FormGroup.value.TaxAmount;
  itemRow_FormGroup.patchValue(
    {
      GrAmount : total + taxAmount,
    });

    const control_DocumentLines = <FormArray>this.oForm.controls['DocumentLines'];
    let totalGrAmount = 0;
    for (let c of control_DocumentLines.controls) {
      if(c.value.IsDeleted == false){
      let amount = +c.value.GrAmount;
      totalGrAmount =totalGrAmount + amount;
      }
    }
    this.oForm.controls['DocTotal'].setValue(totalGrAmount);
  }


  header_change_subsidy_cashdisc(){
    let u_Subsidy =  this.oForm.controls['U_Subsidy'].value;
    let u_CDAllowed = this.oForm.controls['U_CDAllowed'].value;
    const control_DocumentLines = <FormArray>this.oForm.controls['DocumentLines'];
    let baseDiscPer = 100;
   //For Cash Discount
    for (let c of control_DocumentLines.controls) {
      if(u_CDAllowed == "N")
      {
        c.get('CashDisc').setValue(0);
      }
      else
      {
        c.get('CashDisc').setValue(c.value.CashDisc_Temp);
      }
    }
  
    //For General Discount
    for (let c of control_DocumentLines.controls) {
      if(u_Subsidy == "NO")
      {
        c.get('GenDisc').setValue(c.value.GDWOSubsidy_Temp);
      }
      else
      {
        c.get('GenDisc').setValue(c.value.GDWithSubsidy_Temp);
      }
    }
    let headerDiscPer = +this.oForm.controls['Header_DiscPer'].value;

    if(u_Subsidy == "NO" && u_CDAllowed == "Y"){
      for (let c of control_DocumentLines.controls) {
        if(c.value.IsDeleted == false){
        let woSubsidy = +c.value.GDWOSubsidy_Temp;
        let addlDisc = +c.value.AddlDisc_Temp;
        let tradeDisc = +c.value.TradeDisc_Temp;
        let cashDisc = +c.value.CashDisc_Temp;
        let specialDisc = +c.value.SpecialDisc;

        let woSubsidyCalc = baseDiscPer - (baseDiscPer * woSubsidy/100);
        let addlDiscCalc = woSubsidyCalc - (woSubsidyCalc * addlDisc/100);
        let tradeDiscCalc = addlDiscCalc - (addlDiscCalc * tradeDisc/100);
        let cashDiscCalc = tradeDiscCalc - (tradeDiscCalc * cashDisc/100);
        let specialDiscCalc = cashDiscCalc - (cashDiscCalc * specialDisc/100);

        let discPer = baseDiscPer - specialDiscCalc;
   
        let quantity = +c.value.Quantity;
        let unitprice = +c.value.UnitPrice;
        let taxRate = +c.value.TaxRate;
        let discAmt = (quantity * unitprice) * discPer/100;
        let rowTotal1 = quantity * unitprice ;
        let rowTotal2 =  quantity * unitprice * discPer / 100 ;
        let rowTotal = rowTotal1 - rowTotal2;
        let taxamount = (rowTotal * taxRate/100) - (rowTotal * taxRate/100)* headerDiscPer/100;

        c.get('DiscPer').setValue(discPer.toFixed(2));
        c.get('DiscAmt').setValue(discAmt.toFixed(2));
        c.get('Total').setValue(rowTotal.toFixed(2));
        c.get('TaxAmount').setValue(taxamount.toFixed(2));
        
        
        c.get('SpecialDisc').setValue(specialDisc);
        c.get('GenDisc').setValue(woSubsidy);
        c.get('AddlDisc').setValue(addlDisc);
        c.get('TradeDisc').setValue(tradeDisc);
        c.get('CashDisc').setValue(cashDisc);
         
        this.calculate_totalbefDisc();
        this.calculate_doctotal();
        }
      }
    }
    else if(u_Subsidy == "YES" && u_CDAllowed == "N"){
      for (let c of control_DocumentLines.controls) {
        if(c.value.IsDeleted == false){
        let withSubsidy = +c.value.GDWithSubsidy_Temp;
        let specialDisc = +c.value.SpecialDisc;
        
        let withSubsidyCalc = baseDiscPer - (baseDiscPer * withSubsidy/100);;
        let specialDiscCalc =  withSubsidyCalc - (withSubsidyCalc * specialDisc/100);;

        let discPer = baseDiscPer - specialDiscCalc;
        let quantity = +c.value.Quantity;
        let unitprice = +c.value.UnitPrice;
        let taxRate = +c.value.TaxRate;
        let discAmt = (quantity * unitprice) * discPer/100;
        let rowTotal1 = quantity * unitprice ;
        let rowTotal2 =  quantity * unitprice * discPer / 100 ;
        let rowTotal = rowTotal1 - rowTotal2;
        let taxamount = (rowTotal * taxRate/100) - (rowTotal * taxRate/100)* headerDiscPer/100;
        c.get('DiscPer').setValue(discPer.toFixed(2));
        c.get('DiscAmt').setValue(discAmt.toFixed(2));
        c.get('Total').setValue(rowTotal.toFixed(2));
        c.get('TaxAmount').setValue(taxamount.toFixed(2));

        c.get('SpecialDisc').setValue(specialDisc);
        c.get('GenDisc').setValue(withSubsidy);
        c.get('AddlDisc').setValue(0);
        c.get('TradeDisc').setValue(0);
        c.get('CashDisc').setValue(0);

        this.calculate_totalbefDisc();
        this.calculate_doctotal();
        }
      }
    }    
    else if(u_Subsidy == "NO" && u_CDAllowed == "N"){
      for (let c of control_DocumentLines.controls) {
        if(c.value.IsDeleted == false){
        let woSubsidy = +c.value.GDWOSubsidy_Temp;
        let addlDisc = +c.value.AddlDisc_Temp;
        let tradeDisc = +c.value.TradeDisc_Temp;
        let specialDisc = +c.value.SpecialDisc;

        let woSubsidyCalc = baseDiscPer - (baseDiscPer * woSubsidy/100);
        let addlDiscCalc = woSubsidyCalc - (woSubsidyCalc * addlDisc/100);
        let tradeDiscCalc = addlDiscCalc - (addlDiscCalc * tradeDisc/100);
        let specialDiscCalc = tradeDiscCalc - (tradeDiscCalc * specialDisc/100);

        let discPer = baseDiscPer - specialDiscCalc;
   
        let quantity = +c.value.Quantity;
        let unitprice = +c.value.UnitPrice;
        let taxRate = +c.value.TaxRate;
        let discAmt = (quantity * unitprice) * discPer/100;
        let rowTotal1 = quantity * unitprice ;
        let rowTotal2 =  quantity * unitprice * discPer / 100 ;
        let rowTotal = rowTotal1 - rowTotal2;
        let taxamount = (rowTotal * taxRate/100) - (rowTotal * taxRate/100)* headerDiscPer/100;

        c.get('DiscPer').setValue(discPer.toFixed(2));
        c.get('DiscAmt').setValue(discAmt.toFixed(2));
        c.get('Total').setValue(rowTotal.toFixed(2));
        c.get('TaxAmount').setValue(taxamount.toFixed(2));
        

        c.get('SpecialDisc').setValue(specialDisc);
        c.get('GenDisc').setValue(woSubsidy);
        c.get('AddlDisc').setValue(addlDisc);
        c.get('TradeDisc').setValue(tradeDisc);
        c.get('CashDisc').setValue(0);

        this.calculate_totalbefDisc();
        this.calculate_doctotal();
        }
      }
    }
  }

  header_change_subsidy_cashdisc_Old(){
    let u_Subsidy =  this.oForm.controls['U_Subsidy'].value;
    let u_CDAllowed = this.oForm.controls['U_CDAllowed'].value;
    const control_DocumentLines = <FormArray>this.oForm.controls['DocumentLines'];

    
   //For Cash Discount
    for (let c of control_DocumentLines.controls) {
      if(u_CDAllowed == "N")
      {
        c.get('CashDisc').setValue(0);
      }
      else
      {
        c.get('CashDisc').setValue(c.value.CashDisc_Temp);
      }
    }
  
    //For General Discount
    for (let c of control_DocumentLines.controls) {
      if(u_Subsidy == "NO")
      {
        c.get('GenDisc').setValue(c.value.GDWOSubsidy_Temp);
      }
      else
      {
        c.get('GenDisc').setValue(c.value.GDWithSubsidy_Temp);
      }
    }
    let headerDiscPer = +this.oForm.controls['Header_DiscPer'].value;

    if(u_Subsidy == "YES" && u_CDAllowed == "Y"){
      for (let c of control_DocumentLines.controls) {
        if(c.value.IsDeleted == false){
        let specialDisc = +c.value.SpecialDisc;
        let withSubsidy = +c.value.GDWithSubsidy_Temp;
        let discPer = specialDisc + withSubsidy;
        c.get('DiscPer').setValue(discPer);
        let quantity = +c.value.Quantity;
        let unitprice = +c.value.UnitPrice;
        let taxRate = +c.value.TaxRate;
        let discAmt = (quantity * unitprice) * discPer/100;
        let rowTotal1 = quantity * unitprice ;
        let rowTotal2 =  quantity * unitprice * discPer / 100 ;
        let rowTotal = rowTotal1 - rowTotal2;
        let taxamount = (rowTotal * taxRate/100) - (rowTotal * taxRate/100)* headerDiscPer/100;
        c.get('DiscAmt').setValue(discAmt);
        c.get('Total').setValue(rowTotal);
        c.get('TaxAmount').setValue(taxamount);
       
        c.get('SpecialDisc').setValue(specialDisc);
        c.get('GenDisc').setValue(withSubsidy);
        c.get('AddlDisc').setValue(0);
        c.get('TradeDisc').setValue(0);
        c.get('CashDisc').setValue(0);
         
        this.calculate_totalbefDisc();
        this.calculate_doctotal();
        }
      }
    }
    else if(u_Subsidy == "NO" && u_CDAllowed == "Y"){
      for (let c of control_DocumentLines.controls) {
        if(c.value.IsDeleted == false){
        let woSubsidy = +c.value.GDWOSubsidy_Temp;
        let addlDisc = +c.value.AddlDisc_Temp;
        let tradeDisc = +c.value.TradeDisc_Temp;
        let specialDisc = +c.value.SpecialDisc;
        let cashdisc = +c.value.CashDisc_Temp;

        let discPer = woSubsidy + addlDisc+ tradeDisc+ specialDisc+cashdisc;
   
        let quantity = +c.value.Quantity;
        let unitprice = +c.value.UnitPrice;
        let taxRate = +c.value.TaxRate;
        let discAmt = (quantity * unitprice) * discPer/100;
        let rowTotal1 = quantity * unitprice ;
        let rowTotal2 =  quantity * unitprice * discPer / 100 ;
        let rowTotal = rowTotal1 - rowTotal2;
        let taxamount = (rowTotal * taxRate/100) - (rowTotal * taxRate/100)* headerDiscPer/100;

        c.get('DiscPer').setValue(discPer);
        c.get('DiscAmt').setValue(discAmt);
        c.get('Total').setValue(rowTotal);
        c.get('TaxAmount').setValue(taxamount);

        c.get('SpecialDisc').setValue(specialDisc);
        c.get('GenDisc').setValue(woSubsidy);
        c.get('AddlDisc').setValue(addlDisc);
        c.get('TradeDisc').setValue(tradeDisc);
        c.get('CashDisc').setValue(cashdisc);
        
        this.calculate_totalbefDisc();
        this.calculate_doctotal();
        }
      }
    }
    else if(u_Subsidy == "NO" && u_CDAllowed == "N"){
      for (let c of control_DocumentLines.controls) {
        if(c.value.IsDeleted == false){
        let woSubsidy = +c.value.GDWOSubsidy_Temp;
        let addlDisc = +c.value.AddlDisc_Temp;
        let tradeDisc = +c.value.TradeDisc_Temp;
        let specialDisc = +c.value.SpecialDisc;

        let discPer = woSubsidy + addlDisc+ tradeDisc+ specialDisc;
   
        let quantity = +c.value.Quantity;
        let unitprice = +c.value.UnitPrice;
        let taxRate = +c.value.TaxRate;
        let discAmt = (quantity * unitprice) * discPer/100;
        let rowTotal1 = quantity * unitprice ;
        let rowTotal2 =  quantity * unitprice * discPer / 100 ;
        let rowTotal = rowTotal1 - rowTotal2;
        let taxamount = (rowTotal * taxRate/100) - (rowTotal * taxRate/100)* headerDiscPer/100;

        c.get('DiscPer').setValue(discPer);
        c.get('DiscAmt').setValue(discAmt);
        c.get('Total').setValue(rowTotal);
        c.get('TaxAmount').setValue(taxamount);
        
        c.get('SpecialDisc').setValue(specialDisc);
        c.get('GenDisc').setValue(woSubsidy);
        c.get('AddlDisc').setValue(addlDisc);
        c.get('TradeDisc').setValue(tradeDisc);
        c.get('CashDisc').setValue(0);
        
        this.calculate_totalbefDisc();
        this.calculate_doctotal();
        }
      }
    }
  }


  header_change_disc_per(){
   let totalBefDisc =  +this.oForm.controls['TotalBefDisc'].value;
   let discPer =  +this.oForm.controls['Header_DiscPer'].value;
   let discAmt = totalBefDisc*discPer/100;
   this.oForm.controls['Header_DiscAmt'].setValue(discAmt);
   
   this.calculate_rowTax();
  }

  header_change_disc_amt(){
    let totalBefDisc =  +this.oForm.controls['TotalBefDisc'].value;
    let discAmt =  +this.oForm.controls['Header_DiscAmt'].value;
    let discPer = discAmt* 100 /totalBefDisc;
    this.oForm.controls['Header_DiscPer'].setValue(discPer);
    
    this.calculate_rowTax();
   }
  
   calculate_totalbefDisc(){
    let totalBefDisc = 0;
    let totalTax = 0;
    const control_DocumentLines = <FormArray>this.oForm.controls['DocumentLines'];

    for (let c of control_DocumentLines.controls) {
      if(c.value.IsDeleted == false){
      let amount = +c.value.Total;
      let taxamt = +c.value.TaxAmount;

      totalBefDisc = totalBefDisc + amount;
      totalTax = totalTax + taxamt;
      }
    }
    this.oForm.controls['TotalBefDisc'].setValue(totalBefDisc);
   }

   calculate_doctotal(){
    let totalBefDisc =  +this.oForm.controls['TotalBefDisc'].value;
    let discAmt =  +this.oForm.controls['Header_DiscAmt'].value;
    let freight =  +this.oForm.controls['TotalExpns'].value;
    let freightTaxAmount =  +this.oForm.controls['FreightTaxAmount'].value;
    let totalAfterDisc = totalBefDisc - discAmt;
    //let tax = totalAfterDisc;
    let tax =  +this.oForm.controls['Header_TaxAmt'].value;
    let totalTaxAmount = tax + freightTaxAmount;
    this.oForm.controls['Header_TaxAmt'].setValue(totalTaxAmount.toFixed(2));

    let doctotal = totalBefDisc -discAmt +freight + totalTaxAmount ;
    let fractionAmount = +(doctotal % 1).toFixed(2);
    if(fractionAmount>=0.50){
      fractionAmount =  +(1 - fractionAmount).toFixed(2);
    }
    else{
      fractionAmount =  - fractionAmount;
    }
    this.oForm.controls['Rounding'].setValue(fractionAmount);
    doctotal = doctotal + fractionAmount;
    this.oForm.controls['DocTotal'].setValue(doctotal.toFixed(2));
   }

  insertupdate = function (event, formdata) {
    let buttonText;
    buttonText = event.currentTarget.value
    if (buttonText == "Ok") {
      this.cancelForm();
      return;
    }

    if (!this.oForm.valid) {
      this.validateAllFormFields(this.oForm);
      return;
    }

    this.isloading = true;
    let ltuser = localStorage.getItem('currentuser');
    this.user = JSON.parse(ltuser);
    let id = formdata.DocEntry;
    let docNum = formdata.DocNum;
    
    let formData_Temp = formdata;
    let docDate = formdata.DocDate;
    let docDate_Transform = this.datePipe.transform(docDate,"yyyy-MM-dd");
    formdata.DocDate = docDate_Transform;
    let dateDocDueDate = formdata.DocDueDate;
    let dateDocDueDate_Transform = this.datePipe.transform(dateDocDueDate,"yyyy-MM-dd");
    formdata.DocDueDate = dateDocDueDate_Transform;
    // for(let i = 0;i<formdata.DocumentLines.length;i++){
    //   if(formdata.DocumentLines[i].DelDate){
    //     formdata.DocumentLines[i].DelDate = this.datePipe.transform(formdata.DocumentLines[i].DelDate,"yyyy-MM-dd");
    //   }      
    // }

    formdata.UserSign = this.user[0].UserId;
    this._form_service.SalesInvoice_InsertUpdate(formdata).subscribe(
      data => {
        this.isloading = false;
        if(this.boolAdd == true){
        if (data[0].ReturnType == true) {
          this.cancelForm();
          this.showAllRecords(this.pageNumber - 1);
        }
      }
      alert(data[0].ReturnMessage_Description);
      if (data[0].ReturnType == true) {
        //this.form.reset(this.form.value);
        
        this.oForm.controls["DocDate"].setValue(this.datePipe.transform(docDate,"dd-MM-yyyy"));
        this.oForm.controls["DocDueDate"].setValue(this.datePipe.transform(dateDocDueDate,"dd-MM-yyyy"));
        // for(let i = 0;i<formData_Temp.DocumentLines.length;i++){
        //   if(formData_Temp.DocumentLines[i].DelDate){
        //     formData_Temp.DocumentLines[i].DelDate = this.datePipe.transform(formData_Temp.DocumentLines[i].DelDate,"dd-MM-yyyy");
        //   }      
        // }
        // const control_DocumentLines = <FormArray>this.oForm.controls['DocumentLines'];
        // for (let c of control_DocumentLines.controls) {
        //     c.get('DelDate').setValue( this.datePipe.transform(c.value.DelDate,"dd-MM-yyyy"));
        // }      
      }

      if( this.formOpenByApproval1 == true ||  this.formOpenByApproval2 == true ||  this.formOpenByApproval3 == true){
        if (data[0].ReturnType == true && data[0].ReturnMessage_Code) {
          this.cancelForm();
        }
      }
      },
      error => {
        this.isloading = false;
        alert('Error: ' + error)
      },
    );

  }
  
  isFieldValid(field: string) {
    let value = !this.oForm.get(field).valid && this.oForm.get(field).touched;
    return value;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  validateAllFormFields(formGroup: FormGroup) {         //{1}
  Object.keys(formGroup.controls).forEach(field => {  //{2}
    const control = formGroup.get(field);             //{3}
    if (control instanceof FormControl) {             //{4}
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {        //{5}
      this.validateAllFormFields(control);            //{6}
    }
  });
}


}
