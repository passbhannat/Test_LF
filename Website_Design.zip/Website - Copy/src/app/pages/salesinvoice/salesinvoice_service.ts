import { Injectable } from '@angular/core';  
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';  
import { environment } from '../../../environments/environment';
import { map,tap } from 'rxjs/operators';

@Injectable()  
// @Injectable({
//     providedIn: 'root'
//   })
export class SalesInvoice_Service  
{  
    private actionUrl: string; 
    public user: Array<any> = [];
    private territory: string; 
    private userID: string; 
    private userCode: string; 
    private dbName:string;

    constructor(private _http: HttpClient)  
    {  
       this.actionUrl = environment.apiEndpoint;
       let ltuser = localStorage.getItem('currentuser');
        if(ltuser){
            this.user =JSON.parse(ltuser);
            this.territory = this.user[0].Territory;
            this.userID = this.user[0].UserId;
            this.userCode = this.user[0].UserCode;
            this.dbName = this.user[0].DBName;
        }
     }  
  
     SalesInvoice_Get_AllData = (searchText,pageNumber,noOfShowEntry): Observable<any> =>  
    {  
        var url=this.actionUrl+'/SalesInvoice/SalesInvoice_Get_AllData?searchText='+searchText+ '&pageNumber='+pageNumber+'&noOfShowEntry='+noOfShowEntry+'&userID='+this.userID+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    SalesInvoice_Get_Record = (docEntry,isDraft): Observable<any> =>  
    {  
        var url=this.actionUrl+'/SalesInvoice/SalesInvoice_Get_Record?docEntry='+docEntry+'&dbName='+this.dbName;
        return this._http.get(url) ;
    }

    SalesInvoice_InsertUpdate=(formdata): Observable<any> =>
    { 
        formdata.DBName = this.dbName;
        let body = JSON.stringify(formdata);
        var url=this.actionUrl+'/SalesInvoice/SalesInvoice_InsertUpdate';
        let headers = new HttpHeaders({
            'Content-Type': 'application/json'
         });
        let options = {
            headers: headers
         }
         return this._http.post(url,body,options); 
    }

    PrintCrystal = (docEntry): Observable<any> =>  
    {  
        var url=this.actionUrl+'/SalesInvoice/PrintCrystal?docEntry=' + docEntry + '&dbName='+this.dbName;
        return this._http.get(url, { responseType: 'blob' }).pipe(map(
            (res) => {
                    return new Blob([res], { type: 'application/pdf' })
                }));
    }

    
    // public PrintInvoiceReport(docEntry,customerType){
    //     var url=this.actionUrl+'/AR/PrintInvoiceReport?docEntry=' + docEntry + '&customerType=' + customerType;
    //     return this._http.get(url, { responseType: ResponseContentType.Blob }).map(
    //         (res) => {
    //                 return new Blob([res.blob()], { type: 'application/pdf' })
    //             });
    //   }

}