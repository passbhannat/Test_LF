import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';  
import { environment } from '../../../environments/environment';
@Injectable({
    providedIn: 'root'
  })

export class Login_Service  
{  
    private actionUrl: string;  
    constructor(private _http: HttpClient)  
    {  
       this.actionUrl = environment.apiEndpoint;
     }  
 
    Chk_Login=(UserCode,Password,UserType,DBName): Observable<any> =>
    { 
        var url=this.actionUrl+'/account/Login?userCode='+UserCode+'&password='+Password+'&userType='+UserType+'&dbName='+DBName+'';
        return this._http.post(url,'');
    }

    User_Forgot_Password=(UserCode,UserType): Observable<any> =>
    { 
        var url=this.actionUrl+'/account/User_Forgot_Password?userEmailAddress='+UserCode+'&userType='+UserType+'';
        return this._http.post(url,'');
        //.map(this.extractData)
    }

    private extractData(res: Response) {
        let body = res.json();
        return body || {};
    }

    private handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? '${error.status} - ${error.statusText}' : 'Server error';
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}