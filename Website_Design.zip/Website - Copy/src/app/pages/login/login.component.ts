import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {Login_Service}  from './login_service';  
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {           
  oForm;
  public isloading;
  public boolShow_ResetPassword=false;
  public display_Message="none";
  public ErrorMessage;
  public array_SAPDatabase: Array<any> = [];
  constructor(private _fb: FormBuilder,private _form_Service: Login_Service
    ,private router: Router) {
    this.oForm=this._fb.group({
        UserCode:['',Validators.required],  
        Password:['',Validators.required],
        DBName:['KAPL_PRODUCTION',Validators.required],
        UserType:['E',Validators.required],
    });
  
   }
  ngOnInit() {
  //   let ltuser=localStorage.getItem('currentuser');
  //   if(ltuser!=null){
  //     this.loginForm=JSON.parse(ltuser);
  //     if(this.loginForm.UserCode!=''){
  //       this.router.navigate(['./home']);
  //     }
  //  }
 
  }

  toggleForgotPassword(){
    this.boolShow_ResetPassword=!this.boolShow_ResetPassword;   
  }

  forgotPassword(){
    let userCode=this.oForm.controls['UserCode'].value;
    let userType=this.oForm.controls['UserType'].value;
    if(userCode==''){
      alert("Please enter email address");
      return;
    }
    this.isloading=true;
    this._form_Service.User_Forgot_Password(userCode,userType).subscribe(
      data=>{
        this.isloading=false;
        this.boolShow_ResetPassword=false;
        alert(data[0].ReturnMessage_Description);
      },
      error=> {
        this.isloading=false;
        alert(error);
      },
    );  
  }

  output_close_Modal(event){
    this.display_Message=event;
  }

  chk_login=function(event,formdata){
    //this.router.navigate(['./dashboard']);
    this.isloading=true;
    // var key = CryptoJS.enc.Utf8.parse('7061737323313233');
    // var iv = CryptoJS.enc.Utf8.parse('7061737323313233');
    // var encryptedPassword = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(formdata.Password), key,
    //     {
    //         keySize: 128 / 8,
    //         iv: iv,
    //         mode: CryptoJS.mode.CBC,
    //         padding: CryptoJS.pad.Pkcs7
    //     });

    this._form_Service.Chk_Login(formdata.UserCode,formdata.Password,formdata.UserType,formdata.DBName).subscribe(
        data=>{
          this.isloading=false;
          if(data[0].returnMessage=="0"){
             localStorage.setItem("currentuser",JSON.stringify(data));
             this.router.navigate(['./dashboard']);
          }
          else{
            this.ErrorMessage=data[0].returnMessage;
            this.display_Message="block";
          }
        },
        error=> {
          this.isloading=false;
          alert(error);
        },
    );
    }  
}
