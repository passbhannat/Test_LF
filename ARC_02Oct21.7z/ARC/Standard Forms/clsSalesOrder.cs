using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using ARCAddon.Classes;
using System.Linq;
using ARCAddon.Custom_Form;

namespace ARCAddon.Standard_Forms
{
    class clsSalesOrder : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string headerTable = "ORDR";
        const string rowTable = "RDR1";
        SAPbouiCOM.Item baseItem;
        SAPbouiCOM.Item newItem;
        SAPbouiCOM.StaticText oStaticText;


        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD && pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.SalesOrder))
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            newItem = oForm.Items.Add("btCopyARC", BoFormItemTypes.it_BUTTON);
                            baseItem = oForm.Items.Item("2");
                            newItem.Top = baseItem.Top;
                            newItem.Left = baseItem.Left + baseItem.Width + 10;
                            newItem.Height = oForm.Items.Item("2").Height;
                            newItem.Width = oForm.Items.Item("2").Width + 20;
                            SAPbouiCOM.Button oButton = newItem.Specific;
                            oButton.Caption = "Copy From ARC";
                        }
                        #endregion

                        else if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btCopyARC")
                            {
                                string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("CardCode", 0).Trim();
                                if (cardcode == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select customer", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                clsVariables.BaseForm = oForm;
                                clsCopyFromARC _clsCopyFromARC = new clsCopyFromARC();
                                _clsCopyFromARC.LoadForm(clsCopyFromARC.formMenuUID, cardcode);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        private void GenerateEC(string manSerialNum, string serialNum, string itemcode, string customerCode)
        {
            SAPbobsCOM.ICustomerEquipmentCards customerEquipmentCard;
            customerEquipmentCard = (SAPbobsCOM.ICustomerEquipmentCards)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oCustomerEquipmentCards);
            customerEquipmentCard.ManufacturerSerialNum = manSerialNum;
            customerEquipmentCard.InternalSerialNum = serialNum;
            customerEquipmentCard.ItemCode = itemcode;
            customerEquipmentCard.CustomerCode = customerCode;
            int iAdd = customerEquipmentCard.Add();
            if (iAdd != 0)
            {
                string errMessage = oCompany.GetLastErrorDescription();
                oApplication.SetStatusBarMessage(errMessage, BoMessageTime.bmt_Short, false);
            }
            else
            {
                oApplication.StatusBar.SetText("Equipment card created successfully", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }

        }

        #endregion
    }
}
