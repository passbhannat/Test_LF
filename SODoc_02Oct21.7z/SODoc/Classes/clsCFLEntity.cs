﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SODocAddon.Classes
{
    public class clsCFLEntity
    {
        public SAPbouiCOM.BoConditionRelationship RelationShip { get; set; }

        public string Alias { get; set; }

        public string CondVal { get; set; }

        public SAPbouiCOM.BoConditionOperation Operation { get; set; }
         
    }
}
