using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using SODocAddon.Classes;
using System.Linq;

namespace SODocAddon.Standard_Forms
{
    class clsReceiptFromProduction : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string headerTable = "OIGN";
        const string rowTable = "IGN1";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT T1.\"Type\",T1.\"DocEntry\" FROM IGN1 T0 INNER JOIN OWOR T1 ON T0.\"BaseEntry\" = T1.\"DocEntry\" ");
                        sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "' ");
                        oRs = objclsCommon.returnRecord(sbQuery.ToString());

                        string poType = oRs.Fields.Item("Type").Value.ToString();
                        if (poType == "D")
                        {
                            string poDocEntry = oRs.Fields.Item("DocEntry").Value.ToString();

                            string query = "UPDATE T0 SET \"U_Status\" = 'I' FROM \"@TCARD\" T0 WHERE \"U_POEn\" = '"+ poDocEntry + "' ";
                            objclsCommon.SelectRecord(query);
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        private void GenerateEC()
        {
            SAPbobsCOM.ICustomerEquipmentCards customerEquipmentCard;
            customerEquipmentCard = (SAPbobsCOM.ICustomerEquipmentCards)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oCustomerEquipmentCards);
            customerEquipmentCard.ManufacturerSerialNum = "MSerNum";
            customerEquipmentCard.InternalSerialNum = "ISerNum";
            customerEquipmentCard.ItemCode = "10000";
            customerEquipmentCard.CustomerCode = "C00001";
            int iAdd = customerEquipmentCard.Add();
            if (iAdd != 0)
            {
                string errMessage = oCompany.GetLastErrorDescription();
                oApplication.SetStatusBarMessage(errMessage, BoMessageTime.bmt_Short, false);
            }
            else
            {
                oApplication.StatusBar.SetText("Equipment card created successfully", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }

        }

        #endregion
    }
}
