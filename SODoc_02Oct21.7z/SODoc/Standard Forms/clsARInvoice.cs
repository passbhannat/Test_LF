using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using SODocAddon.Classes;
using System.Linq;

namespace SODocAddon.Standard_Forms
{
    class clsARInvoice : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string headerTable = "OINV";
        const string rowTable = "INV1";
        SAPbouiCOM.Item baseItem;
        SAPbouiCOM.Item newItem;
        SAPbouiCOM.StaticText oStaticText;


        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
               
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        private void GenerateEC(string manSerialNum, string serialNum, string itemcode, string customerCode)
        {
            SAPbobsCOM.ICustomerEquipmentCards customerEquipmentCard;
            customerEquipmentCard = (SAPbobsCOM.ICustomerEquipmentCards)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oCustomerEquipmentCards);
            customerEquipmentCard.ManufacturerSerialNum = manSerialNum;
            customerEquipmentCard.InternalSerialNum = serialNum;
            customerEquipmentCard.ItemCode = itemcode;
            customerEquipmentCard.CustomerCode = customerCode;
            int iAdd = customerEquipmentCard.Add();
            if (iAdd != 0)
            {
                string errMessage = oCompany.GetLastErrorDescription();
                oApplication.SetStatusBarMessage(errMessage, BoMessageTime.bmt_Short, false);
            }
            else
            {
                oApplication.StatusBar.SetText("Equipment card created successfully", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }

        }

        #endregion
    }
}
