﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesAgreement.Classes
{
    public class clsFreightEntity
    {
        public string ExpCode   { get; set; }
        public string TaxCode { get; set; }
        public double TaxRate { get; set; }
        public double TaxSum { get; set; }
        public double NetAmt { get; set; }
        public double GrAmt { get; set; }
    }
}
