﻿namespace SalesAgreement.Classes
{ 
    public static class CommonFields
    {
        public const string DocNum = "DocNum";
        public const string DocEntry = "DocEntry";
        public const string DocDate= "DocDate";
        public const string Code = "Code";
        public const string Name = "Name";
        public const string LineId = "LineId";
        public const string LineNum = "LineNum";
        public const string DistNumber = "DistNumber";
        public const string BarCode = "BarCode";
        public const string Location = "Location";

        public const string ObjType = "ObjType";
        public const string DocType = "DocType";

        /* BusinessPartnerCards */
        public const string CardCode = "CardCode";
        public const string CardName = "CardName";
            
        /* Item Master */
        public const string ItemCode = "ItemCode";
        public const string ItemName = "ItemName";
        public const string ItmsGrpCod = "ItmsGrpCod";
        public const string InvntryUom = "InvntryUom";
        public const string BWeight1 = "BWeight1";
        public const string ManBtchNum = "ManBtchNum";
        public const string Quantity = "Quantity";

        /* Warehouse Master */
        public const string WhsCode = "WhsCode";
        public const string WhsName = "WhsName";

        /* Resource Master */
        public const string ResCode = "ResCode";
        public const string ResName = "ResName";
        public const string ResGrpCod = "ResGrpCod";

        public const string OcrCode = "OcrCode";
        public const string PrjCode = "PrjCode";
        public const string empID = "empID";
        public const string firstName = "firstName";
        public const string lastName = "lastName";

    }
}
 