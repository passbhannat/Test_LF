using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using SalesAgreement.Classes;
using System.Linq;
using SalesAgreement.Custom_Form;
using SalesAgreement.Extensions;

namespace SalesAgreement.Standard_Forms
{
    class clsSalesOrder : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string headerTable = "ORDR";
        const string rowTable = "RDR1";
        SAPbouiCOM.Item baseItem;
        SAPbouiCOM.Item newItem;
        SAPbouiCOM.StaticText oStaticText;
        public const string matrixUID = "38";


        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                            {
                                oMatrix = oForm.Items.Item("38").Specific;
                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    try
                                    {
                                        string baseType = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseType", i)).String;
                                        if (baseType == clsSalesAggrement.objType)
                                        {
                                            string qty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i)).String;
                                            string baseQty = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BaseQty", i)).String;
                                            double dblQty = qty == string.Empty ? 0 : double.Parse(qty);
                                            double dblBaseQty = baseQty == string.Empty ? 0 : double.Parse(baseQty);
                                            if (dblQty > dblBaseQty)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Quantity should be less than or equal to Base quantity");
                                                return;
                                            }
                                        }
                                    }
                                    catch { }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (pVal.EventType == BoEventTypes.et_FORM_LOAD)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.Item oItem;
                        SAPbouiCOM.Item xItem;
                        SAPbouiCOM.Button oButton;
                        xItem = oForm.Items.Item("2");
                        oItem = oForm.Items.Add("btCFSA", SAPbouiCOM.BoFormItemTypes.it_BUTTON);

                        oItem.Left = xItem.Left + xItem.Width + 2;
                        oItem.Top = xItem.Top;

                        oItem.Width = oItem.Width + oItem.Width;
                        oItem.Height = xItem.Height;

                        oButton = (SAPbouiCOM.Button)(oItem.Specific);
                        oButton.Caption = "Copy From Agreement";
                        oForm.Items.Item("btCFSA").EnableinAddMode();
                    }
                    else if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "btCFSA")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (oForm.Mode != BoFormMode.fm_ADD_MODE)
                            {
                                oApplication.StatusBar.SetText("Form should be in Add Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("CardCode", 0).Trim();
                            if (cardcode == string.Empty)
                            {
                                oApplication.StatusBar.SetText("Customer is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            clsVariables.BaseForm = oForm;

                            clsCopyFromSalesAgreement doc = new clsCopyFromSalesAgreement();
                            doc.LoadForm(clsCopyFromSalesAgreement.formMenuUID, cardcode);
                            oForm = oApplication.Forms.ActiveForm;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();

                        sbQuery = new StringBuilder();
                        sbQuery.Append(" UPDATE T0");
                        sbQuery.Append(" SET T0.U_OpenQty = T0.U_OpenQty - T1.Quantity ");
                        sbQuery.Append(" FROM \"" + clsSalesAggrement.rowTable + "\" T0");
                        sbQuery.Append(" INNER JOIN RDR1 T1 ON T0.LineId = T1.U_BaseLine AND T0.DocEntry = T1.U_BaseEn AND T0.Object = T1.U_BaseType  ");
                        sbQuery.Append(" WHERE T1.DocEntry = '" + docEntry + "'  ");
                        objclsCommon.SelectRecord(sbQuery.ToString());

                        oRs = objclsCommon.returnRecord("SELECT U_BaseEn FROM RDR1 T0 WHERE DocEntry = '" + docEntry + "' AND T0.U_BaseType = '" + clsSalesAggrement.objType + "' GROUP BY U_BaseEn ");
                        while (!oRs.EoF)
                        {
                            string baseEntry = oRs.Fields.Item("U_BaseEn").Value.ToString();

                            // Update Row status of close
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" UPDATE T1");
                            sbQuery.Append(" SET T1.U_RowStat = 'C' ");
                            sbQuery.Append(" FROM \"" + clsSalesAggrement.rowTable + "\" T1 ");
                            sbQuery.Append(" WHERE T1.DocEntry = '" + baseEntry + "' AND T1.U_OpenQty = 0 ");
                            objclsCommon.SelectRecord(sbQuery.ToString());

                            // Update Row status of Inprogress
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" UPDATE T1");
                            sbQuery.Append(" SET T1.U_RowStat = 'I' ");
                            sbQuery.Append(" FROM \"" + clsSalesAggrement.rowTable + "\" T1 ");
                            sbQuery.Append(" WHERE T1.DocEntry = '" + baseEntry + "' AND T1.U_Qty != T1.U_OpenQty AND T1.U_OpenQty > 0 ");
                            objclsCommon.SelectRecord(sbQuery.ToString());

                            // Closed Sales Agreement
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" IF NOT EXISTS(SELECT 1 FROM \"" + clsSalesAggrement.headerTable + "\" T1 ");
                            sbQuery.Append(" INNER JOIN \"" + clsSalesAggrement.rowTable + "\" T2 ON T1.DocEntry =T2.DocEntry ");
                            sbQuery.Append(" WHERE T1.DocEntry = '" + baseEntry + "' AND T2.U_OpenQty !=0) ");
                            sbQuery.Append(" BEGIN ");
                            sbQuery.Append("    UPDATE  \"" + clsSalesAggrement.headerTable + "\" SET Status = 'C' WHERE DocEntry = '" + baseEntry + "' ");
                            sbQuery.Append(" END ");
                            objclsCommon.SelectRecord(sbQuery.ToString());

                            oRs.MoveNext();
                        }

                    }
                    //else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    //{
                    //    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    //}

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method


        #endregion
    }
}
