﻿using Fabric.Classes;
using Fabric.Custom_Form;
using Fabric.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fabric
{
    class clsGRPO : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();


        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "OPDN";
        public const string rowTable = "PDN1";
        public const string objType = "20";
        public const string matrixUID = "38";
        const string buttonGenerateUID = "btGen";
        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == true)
            {
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                {
                    if (pVal.ItemUID == "btGen")
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                        {
                            return;
                        }
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                        string joberCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_JobCode", 0).Trim();

                        bool boolCreateDocument = false;
                        string isPurchaseChallanCreated = objclsCommon.SelectRecord("SELECT 1 FROM \"@PURCHAL\" WHERE \"U_GRNEn\" = '" + docEntry + "'");
                        if (isPurchaseChallanCreated == string.Empty)
                        {
                            boolCreateDocument = true;
                        }
                        string isJobWorkCreated = "";
                        if (joberCode != string.Empty)
                        {
                            isJobWorkCreated = objclsCommon.SelectRecord("SELECT 1 FROM \"@JOBWORK\" WHERE \"U_GRNEn\" = '" + docEntry + "'");
                            if (isJobWorkCreated == string.Empty)
                            {
                                boolCreateDocument = true;
                            }
                        }
                        if (boolCreateDocument == true)
                        {
                            int i = oApplication.MessageBox("Do you want to generate document?", 1, "Yes", "No", "");
                            if (i == 1)
                            {
                                oApplication.StatusBar.SetText("Please wait..", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                                if (isPurchaseChallanCreated == string.Empty)
                                {
                                    GeneratePurchaseChallan(docEntry);
                                }
                                if (isJobWorkCreated == string.Empty)
                                {
                                    if (joberCode != string.Empty)
                                    {
                                        GenerateJobWork(docEntry);
                                    }
                                }
                                oApplication.StatusBar.SetText("Operation completed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            }
                        }
                    }
                }
            }
            else
            {
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                {
                    oForm = oApplication.Forms.Item(pVal.FormUID);

                    #region Jober Code controls
                    SAPbouiCOM.Item oNewItem = oForm.Items.Add("stJobCode", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                    SAPbouiCOM.Item oItem = oForm.Items.Item("30");
                    oNewItem.Left = oItem.Left;
                    oNewItem.Top = oForm.Items.Item("30").Top + oItem.Height + 5;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width;
                    SAPbouiCOM.StaticText oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                    oStaticText.Caption = "Jober Code";

                    oNewItem = oForm.Items.Add("U_JobCode", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                    oItem = oForm.Items.Item("29");
                    oNewItem.Left = oItem.Left;
                    oNewItem.Top = oForm.Items.Item("stJobCode").Top;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width;
                    oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                    oEdit.DataBind.SetBound(true, headerTable, "U_JobCode");

                    objclsCommon.AddChooseFromList(oForm, "CFL_JB", "2");
                    oEdit.ChooseFromListUID = "CFL_JB";
                    oEdit.ChooseFromListAlias = "CardCode";
                    #endregion

                    #region Create Generate Challan Button

                    oNewItem = oForm.Items.Add(buttonGenerateUID, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                    oItem = oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel));
                    oNewItem.Left = oItem.Left + oItem.Width + 10;
                    oNewItem.Top = oItem.Top;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width * 2;
                    SAPbouiCOM.Button oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                    oButton.Caption = "Generate Challan";

                    #endregion

                    oNewItem.EnableinUpdateMode();
                }

                #region F_et_CHOOSE_FROM_LIST

                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                {
                    SAPbouiCOM.DataTable oDataTable = null;
                    oForm = oApplication.Forms.Item(pVal.FormUID);
                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                    oDataTable = oCFLEvento.SelectedObjects;
                    string sCFL_ID = oCFLEvento.ChooseFromListUID;
                    string Value = string.Empty;
                    if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                    {
                        return;
                    }
                    if (oCFLEvento.ChooseFromListUID == "CFL_JB")
                    {
                        oEdit = oForm.Items.Item("U_JobCode").Specific;
                        try
                        {
                            oEdit.String = oDataTable.GetValue(CommonFields.CardCode, 0).ToString();
                        }
                        catch { }
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                        }
                    }
                }


                #endregion

            }
        }


        private void GeneratePurchaseChallan(string grpoDocEntry)
        {
            string currenDate = DateTime.Now.ToString("yyyyMMdd");
            SAPbobsCOM.GeneralService oGeneralService;
            SAPbobsCOM.GeneralData oGeneralData;

            SAPbobsCOM.GeneralData oChild;
            SAPbobsCOM.GeneralDataCollection oChildren;
            SAPbobsCOM.GeneralDataParams oGeneralParams;

            SAPbobsCOM.CompanyService oCompService;
            oCompService = oCompany.GetCompanyService();
            oGeneralService = oCompService.GetGeneralService("PURCHAL");
            oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);
            oGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
            oRs = objclsCommon.returnRecord("SELECT * FROM OPDN WHERE \"DocEntry\" = '" + grpoDocEntry + "'");
            oGeneralData.SetProperty("U_VenCode", oRs.Fields.Item("CardCode").Value);
            oGeneralData.SetProperty("U_VenName", oRs.Fields.Item("CardName").Value);
            oGeneralData.SetProperty("U_GRNEn", oRs.Fields.Item("DocEntry").Value.ToString());
            oGeneralData.SetProperty("U_GRNNo", oRs.Fields.Item("DocNum").Value.ToString());
            oGeneralData.SetProperty("U_JobCode", oRs.Fields.Item("U_JobCode").Value.ToString());

            try
            {
                oGeneralData.SetProperty("U_GRNDate", currenDate);
            }
            catch { }

            // Adding data to Detail Line
            oRs = objclsCommon.returnRecord("SELECT * FROM PDN1 WHERE \"DocEntry\" = '" + grpoDocEntry + "'");

            oChildren = oGeneralData.Child("PURCHAL1");
            string itemcode = "";
            string randomNo = objclsCommon.GetRandomNo();
            while (!oRs.EoF)
            {
                oChild = oChildren.Add();
                itemcode = oRs.Fields.Item("ItemCode").Value;
                string itemname = oRs.Fields.Item("Dscription").Value;
                string takaType = oRs.Fields.Item("U_TakaType").Value;
                string uom = oRs.Fields.Item("unitMsr").Value;
                string design = oRs.Fields.Item("U_Design").Value;
                string color = oRs.Fields.Item("U_Color").Value;
                oChild.SetProperty("U_ItemCode", itemcode);
                oChild.SetProperty("U_ItemName", oRs.Fields.Item("Dscription").Value);
                oChild.SetProperty("U_UOM", oRs.Fields.Item("unitMsr").Value);
                oChild.SetProperty("U_Design", oRs.Fields.Item("U_Design").Value);
                oChild.SetProperty("U_Colour", oRs.Fields.Item("U_Color").Value);
                oChild.SetProperty("U_Qty", "1");


                oChild.SetProperty("U_QtyMtr", objclsCommon.GetFabricBaseQty(itemcode));
                string takaNo = objclsCommon.GetTakaNo(itemcode, DateTime.Now.ToString("yyyyMMdd"));
                oChild.SetProperty("U_TakaNo", takaNo);
                objclsCommon.InsertTaka(takaNo, takaType, itemcode, itemname, uom, design, color, grpoDocEntry, randomNo, currenDate);
                oRs.MoveNext();
            }
            oGeneralParams = oGeneralService.Add(oGeneralData);
            string NewDocEntry = oGeneralParams.GetProperty("DocEntry").ToString();
        }

        private void GenerateJobWork(string docEntry)
        {
            SAPbobsCOM.GeneralService oGeneralService;
            SAPbobsCOM.GeneralData oGeneralData;

            SAPbobsCOM.GeneralData oChild;
            SAPbobsCOM.GeneralDataCollection oChildren;
            SAPbobsCOM.GeneralDataParams oGeneralParams;

            SAPbobsCOM.CompanyService oCompService;
            oCompService = oCompany.GetCompanyService();
            oGeneralService = oCompService.GetGeneralService("JOBWORK");
            oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);
            oGeneralData = (SAPbobsCOM.GeneralData)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralData);
            oRs = objclsCommon.returnRecord("SELECT * FROM OPDN WHERE \"DocEntry\" = '" + docEntry + "'");
            string joberCode = oRs.Fields.Item("U_JobCode").Value;
            string cardName = objclsCommon.SelectRecord("SELECT \"CardName\" FROM OCRD WHERE \"CardCode\" = '" + joberCode + "'");

            oGeneralData.SetProperty("U_JobCode", oRs.Fields.Item("U_JobCode").Value);
            oGeneralData.SetProperty("U_JobName", cardName);
            oGeneralData.SetProperty("U_GRNEn", oRs.Fields.Item("DocEntry").Value.ToString());

            try
            {
                oGeneralData.SetProperty("U_ChDate", DateTime.Parse(oRs.Fields.Item("U_DispDate").Value.ToString()));
            }
            catch { }

            // Adding data to Detail Line
            oRs = objclsCommon.returnRecord("SELECT * FROM PDN1 WHERE \"DocEntry\" = '" + docEntry + "'");

            oChildren = oGeneralData.Child("JOBWORK1");
            while (!oRs.EoF)
            {
                oChild = oChildren.Add();
                oChild.SetProperty("U_ItemCode", oRs.Fields.Item("ItemCode").Value);
                oChild.SetProperty("U_ItemName", oRs.Fields.Item("Dscription").Value);
                oRs.MoveNext();
            }

            oGeneralParams = oGeneralService.Add(oGeneralData);
            string NewDocEntry = oGeneralParams.GetProperty("DocEntry").ToString();

        }
    }
}
