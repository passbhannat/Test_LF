﻿using Fabric.Classes;
using Fabric.Extensions;
using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace Fabric.Custom_Form
{
    class clsFabricMaster : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Folder oFolder;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@FABMASTER";
        public const string rowTable1 = "@FABMASTER1";
        public const string rowTable2 = "@FABMASTER2";
        public const string rowTable3 = "@FABMASTER3";
        public const string rowTable4 = "@FABMASTER4";
        public const string rowTable5 = "@FABMASTER5";
        public const string rowTable6 = "@FABMASTER6";

        public const string objType = "FABMASTER";
        public const string formMenuUID = "FABMASTER";
        const string formTitle = "Fabric Master";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_DesCode";

        const string matrixUID2 = "mtx2";
        const string matrixPrimaryUDF2 = "U_DesCode";

        const string matrixUID3 = "mtx3";
        const string matrixPrimaryUDF3 = "U_DesCode";

        const string matrixUID4 = "mtx4";
        const string matrixPrimaryUDF4 = "U_DesCode";

        const string matrixUID5 = "mtx5";
        const string matrixPrimaryUDF5 = "U_DesCode";

        const string matrixUID6 = "mtx6";
        const string matrixPrimaryUDF6 = "U_DesCode";

        bool refreshForm = false;

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                                {
                                    string code = AutoCode();
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("Code", 0, code);
                                    string itemcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemCode", 0).Trim();
                                    if (itemcode == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Item Code is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    string itemname = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemName", 0).Trim();
                                    if (itemname == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Item Name is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    string itemgroup = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemGrp", 0).Trim();
                                    if (itemgroup == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Item Group is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    string itemcategory = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemCt", 0).Trim();
                                    if (itemcategory == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Item Category is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    string srinkage = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Srink", 0).Trim();
                                    double dblSrinkage = srinkage == string.Empty ? 0 : double.Parse(srinkage);
                                    if (dblSrinkage == 0)
                                    {
                                        oApplication.StatusBar.SetText("Srinkage is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    string uom = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_UOM", 0).Trim();
                                    if (uom == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("UOM is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        //oApplication.StatusBar.SetText("Row level data is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        //BubbleEvent = false;
                                        //return;
                                    }
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        //if (i == 0)
                                        //{
                                        //    string code = oDbDataSource.GetValue("U_ItemCode", i);
                                        //    if (code == string.Empty)
                                        //    {
                                        //        oApplication.StatusBar.SetText("Item Code is mandatory for Row No: " + (i + 1).ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        //        BubbleEvent = false;
                                        //        return;
                                        //    }
                                        //}
                                    }
                                }
                            }
                        }

                        else if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == matrixUID3)
                            {
                                if (pVal.ColUID == "U_GSCode")
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID2).Specific;
                                    oMatrix.FlushToDataSource();
                                    List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();

                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        clsCFLEntity entity = new clsCFLEntity();
                                        entity.Alias = "ItemCode";
                                        entity.Operation = BoConditionOperation.co_EQUAL;
                                        entity.CondVal = oDbDataSource.GetValue("U_SAPCode",i);
                                        entity.RelationShip = BoConditionRelationship.cr_OR;
                                        clsCFLEntityList.Add(entity);
                                    }
                                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_ITEM3", clsCFLEntityList);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "1")
                            {
                                if (pVal.FormTypeEx == formMenuUID )
                                {
                                    if (pVal.FormMode == 3)
                                    {
                                        oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                        string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Code", 0).ToString();
                                        if (docNum.Trim() == string.Empty)
                                        {
                                            LoadForm("1282");
                                            return;
                                        }
                                    }
                                    else if (pVal.FormMode == 1)
                                    {
                                        if (refreshForm == true)
                                        {
                                            objclsCommon.RefreshRecord();
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == "CFL_AITEM")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_AltItemN", 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oDbDataSource.SetValue("U_AltItemC", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            }

                            #region Colour Folder1
                            if (oCFLEvento.ChooseFromListUID == "CFL_DESIGN")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_DesCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue("U_CDName", pVal.Row - 1, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_COL")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_ColCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue("U_CDName", pVal.Row - 1, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_MT")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_MatType", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_YN")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_Active", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            #endregion

                            #region Fabric Grey Folder2
                            else if (oCFLEvento.ChooseFromListUID == "CFL_DES2")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID2).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_DesCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_COL2")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID2).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_ColCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_YN2")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID2).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_Active", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            #endregion

                            #region Grey Details Folder3
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITEM3")
                            {
                                string selectedCode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID2).Specific;
                                oMatrix.FlushToDataSource();
                                string design = "";
                                string color = "";
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    if (selectedCode == oDbDataSource.GetValue("U_SAPCode", i))
                                    {
                                        design = oDbDataSource.GetValue("U_DesCode", i);
                                        color = oDbDataSource.GetValue("U_ColCode", i);
                                        break;
                                    }
                                }
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable3);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID3).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_GSCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                               
                                oDbDataSource.SetValue("U_AJDesign", pVal.Row - 1, design);
                                oDbDataSource.SetValue("U_AJColour", pVal.Row - 1, color);

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }

                            else if (oCFLEvento.ChooseFromListUID == "CFL_BP3")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable3);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID3).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_VName", pVal.Row - 1, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                                oDbDataSource.SetValue("U_VCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_YN3")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable3);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID3).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_Active", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            #endregion

                            #region Job Work Details Folder4
                            else if (oCFLEvento.ChooseFromListUID == "CFL_BP4")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable4);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID4).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_JobName", pVal.Row - 1, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                                oDbDataSource.SetValue("U_JobCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                                oDbDataSource.SetValue("U_CDetail", pVal.Row - 1, "0");
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_YN3")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable3);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID3).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_Active", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            #endregion

                            #region Group Details Folder5
                            else if (oCFLEvento.ChooseFromListUID == "CFL_SUBG5")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable5);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID5).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_SubGrp", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_KEY5")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable5);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID5).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_Keyword", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_DHP5")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable5);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID5).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_DHP", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_YN5")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable5);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID5).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_Active", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            #endregion

                            #region Group Details Folder6
                            else if (oCFLEvento.ChooseFromListUID == "CFL_DES6")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable6);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID6).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_DesCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_MT6")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable6);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID6).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_MatType", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            #endregion

                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == BoEventTypes.et_COMBO_SELECT)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "U_Series")
                            {
                                string series = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Series", 0).Trim();
                                string itemname = "";
                                sbQuery = new StringBuilder();
                                sbQuery.Append(" SELECT \"BeginStr\",\"NumSize\",\"NextNumber\" ");
                                sbQuery.Append(" FROM NNM1 ");
                                sbQuery.Append(" WHERE \"Series\" = '" + series + "' ");
                                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                                string beginStr = oRs.Fields.Item("BeginStr").Value;
                                int numSize = oRs.Fields.Item("NumSize").Value;
                                Int32 nextNumber = oRs.Fields.Item("NextNumber").Value;
                                itemname = beginStr + nextNumber.ToString().PadLeft(numSize, '0');
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_ItemCode", 0, itemname);
                            }
                        }
                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (clsVariables.boolCFLSelected)
                            {
                                clsVariables.boolCFLSelected = false;
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string matUID = GetSelectedMatrix(oForm, out string primaryUID, out string tableName);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matUID).Specific;
                                oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                clsVariables.RowNo = 0;
                                clsVariables.ColNo = 0;
                            }
                        }
                        #endregion

                        #region F_ItemChanged
                        if (pVal.ItemChanged == true)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                        || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Code", 0).Trim();
                        CreateHeaderItemMaster(code);
                        CreateRowItemMaster(code);
                        CreateRowFabricGreyItemMaster(code);

                        if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                        {
                            refreshForm = true;
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        string primaryUID = "";
                        string tableName = "";
                        string matID = GetSelectedMatrix(oForm, out primaryUID, out tableName);
                        AddRow(matrixUID, rowTable1, matrixPrimaryUDF);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        string primaryUID = "";
                        string tableName = "";
                        string matID = GetSelectedMatrix(oForm, out primaryUID, out tableName);
                        DeleteRow(matID, tableName, primaryUID);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    //string FormID;
                    //if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    //{
                    //    oForm = oApplication.Forms.Item(FormID);
                    //    oForm.Select();
                    //    return;
                    //}
                    objclsCommon.LoadXML(menuID, "Code", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.LayoutManager), true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                    oCombo = oForm.Items.Item("U_Series").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"Series\", T0.\"SeriesName\" FROM NNM1 T0 WHERE \"ObjectCode\" = '4' AND \"Locked\" = 'N'");

                    oCombo = oForm.Items.Item("U_ItemGrp").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"ItmsGrpCod\", T0.\"ItmsGrpNam\" FROM OITB T0 ");

                    oCombo = oForm.Items.Item("U_UOM").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"UgpCode\", T0.\"UgpName\" FROM OUGP T0 ");

                    oCombo = oForm.Items.Item("U_HSNCode").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"AbsEntry\", T0.\"ChapterID\" FROM OCHP T0 ");

                    oCombo = oForm.Items.Item("U_ItemGrp").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"ItmsGrpCod\", T0.\"ItmsGrpNam\" FROM OITB T0 ");


                    List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                    clsCFLEntityList.Add(new clsCFLEntity { Alias = "CardType", CondVal = "S", Operation = BoConditionOperation.co_EQUAL });
                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_BP", clsCFLEntityList);
                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_BP3", clsCFLEntityList);
                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_BP4", clsCFLEntityList);

                    oMatrix = oForm.Items.Item(matrixUID).Specific;
                    oMatrix.CommonSetting.EnableArrowKey = true;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    //oCombo = oMatrix.GetCellSpecific("U_SlpCode", 1);
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"SlpCode\", T0.\"SlpName\" FROM OSLP T0 ORDER BY T0.\"SlpCode\" ");

                    //oCombo = oMatrix.GetCellSpecific("U_Location", 1);
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"Code\", T0.\"Location\" FROM OLCT T0 ORDER BY T0.\"Code\" ");

                }

                oMatrix = oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix = oForm.Items.Item(matrixUID2).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix = oForm.Items.Item(matrixUID3).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix = oForm.Items.Item(matrixUID4).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix = oForm.Items.Item(matrixUID5).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix = oForm.Items.Item(matrixUID6).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oForm.Items.Item("Code").EnableinFindMode();
                oForm.Items.Item("U_Series").EnableinAddMode();
                oForm.Items.Item("U_ItemCode").EnableinAddMode();
                //oForm.Items.Item("DocEntry").EnableinFindMode();
                //oForm.Items.Item("Status").EnableinFindMode();
                //oForm.Items.Item("CANCELED").EnableinFindMode();
                //oForm.Items.Item("DocEntry").EnableinFindMode();
                //string autoCode = objclsCommon.SelectRecord("SELECT MAX(Cast(Code as numeric(19,6))) FROM \"" + headerTable + "\"");
                //int iAutoCode = autoCode == string.Empty ? 1 : int.Parse(autoCode);
                //iAutoCode = iAutoCode + 1;
                oFolder = oForm.Items.Item("fld1").Specific;
                oFolder.Select();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsCommon.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private string AutoCode()
        {
            string query = "SELECT MAX(CAST(\"Code\" as INT)) FROM \"" + headerTable + "\"";
            string code = objclsCommon.SelectRecord(query);
            Int32 iCode = code == string.Empty ? 0 : Int32.Parse(code);
            iCode = iCode + 1;
            return iCode.ToString();
        }

        private string GetSelectedMatrix(SAPbouiCOM.Form oForm, out string primaryUID, out string tablename)
        {
            primaryUID = "";
            tablename = "";
            oFolder = oForm.Items.Item("fld1").Specific;
            if (oFolder.Selected == true)
            {
                primaryUID = matrixPrimaryUDF;
                tablename = rowTable1;
                return matrixUID;
            }
            oFolder = oForm.Items.Item("fld2").Specific;
            if (oFolder.Selected == true)
            {
                primaryUID = matrixPrimaryUDF2;
                tablename = rowTable2;
                return matrixUID2;
            }
            oFolder = oForm.Items.Item("fld3").Specific;
            if (oFolder.Selected == true)
            {
                primaryUID = matrixPrimaryUDF3;
                tablename = rowTable3;
                return matrixUID3;
            }
            oFolder = oForm.Items.Item("fld4").Specific;
            if (oFolder.Selected == true)
            {
                primaryUID = matrixPrimaryUDF4;
                tablename = rowTable4;
                return matrixUID4;
            }
            oFolder = oForm.Items.Item("fld5").Specific;
            if (oFolder.Selected == true)
            {
                primaryUID = matrixPrimaryUDF5;
                tablename = rowTable5;
                return matrixUID5;
            }
            oFolder = oForm.Items.Item("fld6").Specific;
            if (oFolder.Selected == true)
            {
                primaryUID = matrixPrimaryUDF6;
                tablename = rowTable6;
                return matrixUID6;
            }
            return "";
        }

        private void CreateHeaderItemMaster(string code)
        {
            oRs = objclsCommon.returnRecord("SELECT * FROM \"" + headerTable + "\" WHERE \"Code\" = '" + code + "' ");
            string series = oRs.Fields.Item("U_Series").Value;
            string itemcode = oRs.Fields.Item("U_ItemCode").Value;
            string itemName = oRs.Fields.Item("U_ItemName").Value;
            string itemgroup = oRs.Fields.Item("U_ItemGrp").Value;
            string itemCategory = oRs.Fields.Item("U_ItemCt").Value;
            double srinkage = oRs.Fields.Item("U_Srink").Value;
            string uom = oRs.Fields.Item("U_UOM").Value;

            string isItemAlreadyCreated = objclsCommon.SelectRecord("SELECT '1' FROM OITM WHERE \"ItemCode\" = '" + itemcode + "' ");
            if (isItemAlreadyCreated == "1")
            {
                return;
            }
            SAPbobsCOM.Items oItems = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems);
            oItems.Series = int.Parse(series);
            oItems.ItemCode = itemcode;
            oItems.ItemName = itemName;
            oItems.ItemsGroupCode = int.Parse(itemgroup);

            oItems.UserFields.Fields.Item("U_ItemCt").Value = itemCategory;
            oItems.UserFields.Fields.Item("U_Srink").Value = srinkage.ToString();

            long lAddRecord = oItems.Add();
            if (lAddRecord != 0)
            {
                oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        private void CreateRowItemMaster(string code)
        {
            oRs = objclsCommon.returnRecord("SELECT * FROM \"" + headerTable + "\" WHERE \"Code\" = '" + code + "' ");
            string series = oRs.Fields.Item("U_Series").Value;
            string itemcode = oRs.Fields.Item("U_ItemCode").Value;
            string itemName = oRs.Fields.Item("U_ItemName").Value;
            string itemgroup = oRs.Fields.Item("U_ItemGrp").Value;
            string itemCategory = oRs.Fields.Item("U_ItemCt").Value;
            double srinkage = oRs.Fields.Item("U_Srink").Value;
            string uom = oRs.Fields.Item("U_UOM").Value;

            sbQuery = new StringBuilder();

            sbQuery.Append(" SELECT * ");
            sbQuery.Append(" FROM \"" + rowTable1 + "\" T0 ");
            //rd(" INNER JOIN \"@DESIGN\" T1 ON T0.\"U_DesCode\" = T1.\"Code\"  ");
            //rd(" INNER JOIN \"@COLOUR\" T2 ON T0.\"U_ColCode\" = T2.\"Code\"  ");
            sbQuery.Append(" WHERE T0.\"Code\" = '" + code + "' ");
            sbQuery.Append(" AND T0.\"U_CDName\" IS NOT NULL AND T0.\"U_SAPCode\" IS NULL  ");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());

            while (!oRs.EoF)
            {
                string lineId = oRs.Fields.Item("LineId").Value.ToString();
                string designCode = oRs.Fields.Item("U_DesCode").Value;
                string colorCode = oRs.Fields.Item("U_ColCode").Value;

                SAPbobsCOM.Items oItems = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems);
                oItems.Series = int.Parse(series);
                string newItemName = itemName + " " + colorCode;
                oItems.ItemName = itemName;
                oItems.ItemsGroupCode = int.Parse(itemgroup);

                oItems.UserFields.Fields.Item("U_ItemCt").Value = itemCategory;
                oItems.UserFields.Fields.Item("U_Srink").Value = srinkage.ToString();
                oItems.UserFields.Fields.Item("U_FabCode").Value = itemcode;
                oItems.UserFields.Fields.Item("U_Type").Value = "FG Fabric";

                long lAddRecord = oItems.Add();
                if (lAddRecord != 0)
                {
                    oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
                else
                {
                    string newCode = oCompany.GetNewObjectKey();
                    objclsCommon.SelectRecord("UPDATE T0 SET \"U_SAPCode\" ='" + newCode + "' FROM \"" + rowTable1 + "\" T0 WHERE T0.\"Code\"='" + code + "' AND  T0.\"LineId\"='" + lineId + "' ");
                }
                oRs.MoveNext();
            }
        }

        private void CreateRowFabricGreyItemMaster(string code)
        {
            oRs = objclsCommon.returnRecord("SELECT * FROM \"" + headerTable + "\" WHERE \"Code\" = '" + code + "' ");
            string series = oRs.Fields.Item("U_Series").Value;
            string itemcode = oRs.Fields.Item("U_ItemCode").Value;
            string itemName = oRs.Fields.Item("U_ItemName").Value;
            string itemgroup = oRs.Fields.Item("U_ItemGrp").Value;
            string itemCategory = oRs.Fields.Item("U_ItemCt").Value;
            double srinkage = oRs.Fields.Item("U_Srink").Value;
            string uom = oRs.Fields.Item("U_UOM").Value;

            sbQuery = new StringBuilder();

            sbQuery.Append(" SELECT * ");
            sbQuery.Append(" FROM \"" + rowTable2 + "\" T0 ");
            //rd(" INNER JOIN \"@DESIGN\" T1 ON T0.\"U_DesCode\" = T1.\"Code\"  ");
            //rd(" INNER JOIN \"@COLOUR\" T2 ON T0.\"U_ColCode\" = T2.\"Code\"  ");
            sbQuery.Append(" WHERE T0.\"Code\" = '" + code + "' ");
            sbQuery.Append(" AND (T0.\"U_DesCode\" IS NOT NULL OR T0.\"U_ColCode\" IS NOT NULL) AND T0.\"U_SAPCode\" IS NULL  ");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());

            while (!oRs.EoF)
            {
                string lineId = oRs.Fields.Item("LineId").Value.ToString();
                string designCode = oRs.Fields.Item("U_DesCode").Value;
                string colorCode = oRs.Fields.Item("U_ColCode").Value;

                SAPbobsCOM.Items oItems = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems);
                oItems.Series = int.Parse(series);
                string newItemName = itemName + " " + colorCode;
                oItems.ItemName = itemName;
                oItems.ItemsGroupCode = int.Parse(itemgroup);

                oItems.UserFields.Fields.Item("U_ItemCt").Value = itemCategory;
                oItems.UserFields.Fields.Item("U_Srink").Value = srinkage.ToString();
                oItems.UserFields.Fields.Item("U_FabCode").Value = itemcode;
                oItems.UserFields.Fields.Item("U_Type").Value = "Grey Fabric";

                long lAddRecord = oItems.Add();
                if (lAddRecord != 0)
                {
                    oApplication.StatusBar.SetText(oCompany.GetLastErrorDescription(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
                else
                {
                    string newCode = oCompany.GetNewObjectKey();
                    objclsCommon.SelectRecord("UPDATE T0 SET \"U_SAPCode\" ='" + newCode + "' FROM \"" + rowTable2 + "\" T0 WHERE T0.\"Code\"='" + code + "' AND  T0.\"LineId\"='" + lineId + "' ");
                }
                oRs.MoveNext();
            }
        }
    }
}
