﻿using Fabric.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fabric.Custom_Forms
{
    class clsJobWorkUpdate : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();
         
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;

        public const string formMenuUID = "JOBUPDATE";
        const string formTitle = "Job Work Update";
        const string gridDocumentsUID = "grd1";
        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == true)
            {
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                {
                    if (pVal.ItemUID == "btLoad")
                    {
                        FillGrid("N");
                    }
                    else if (pVal.ItemUID == "btUpdate")
                    { 
                    
                    }
                }
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == false)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == "JOBUPDATE")
                {
                    LoadForm(pVal.MenuUID);
                }

            }


        }

        public void LoadForm(string formMenuid)
        {
            objclsCommon.LoadXML(formMenuid, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
        }

        private void FillGrid(string selection)
        {
            oForm = oApplication.Forms.ActiveForm;
            sbQuery.Length = 0;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("call Proc_Fabric_JobWorkChallanUpdate_Data");
            }
            else
            {
                sbQuery.Append("EXEC Proc_Fabric_JobWorkChallanUpdate_Data ");
                //sbQuery.Append("SELECT '" + selection + "' AS Selection,DocEntry,DocNum,DocDate,CardCode,CardName,NumAtCard FROM OQUT WHERE DocStatus = 'O' AND CardCode='" + cardcode + "' ");
            }
            objclsCommon.FillGrid(oForm.UniqueID, gridDocumentsUID, gridDocumentsUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridDocumentsUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item(0).Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
        }

    }
}
