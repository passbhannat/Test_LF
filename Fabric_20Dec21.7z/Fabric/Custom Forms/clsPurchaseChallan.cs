﻿using Fabric.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fabric.Custom_Forms
{
    class clsPurchaseChallan : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Folder oFolder;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@PURCHAL";
        public const string rowTable = "@PURCHAL1";
        public const string objType = "PURCHAL";
        public const string formMenuUID = "PURCHAL";
        const string formTitle = "Purchase Challan";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";
        bool multiItemSelected = false;
        string cflSelected = "";
        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch
                {

                }

                if(pVal.MenuUID == "PURCHALLAN")
                {
                    LoadForm(pVal.MenuUID);
                }
            }
        }


        public void LoadForm(string formMenuid)
        {
            objclsCommon.LoadXML(formMenuid, "DocNum", string.Empty, SAPbouiCOM.BoFormMode.fm_FIND_MODE);
        }
    }
}
