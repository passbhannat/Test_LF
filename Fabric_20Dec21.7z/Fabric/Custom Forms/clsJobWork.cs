﻿using Fabric.Classes;
using Fabric.Extensions;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fabric.Custom_Forms
{
    class clsJobWork : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Folder oFolder;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@JOBWORK";
        public const string rowTable = "@JOBWORK1";

        public const string objType = "JOBWORK";
        public const string formMenuUID = "JOBWORK";
        const string formTitle = "Job Work";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";
        bool multiItemSelected = false;
        string cflSelected = "";
        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            #region Before_Action == true

            if (pVal.Before_Action == true)
            {
                try
                {
                    if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "btGetDet")
                        { 
                        
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
            #endregion
            #region Before_Action == false

            else
            {
                try
                {
                    #region F_et_CHOOSE_FROM_LIST
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.DataTable oDataTable = null;
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                        oDataTable = oCFLEvento.SelectedObjects;
                        string sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string Value = string.Empty;
                        if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                        {
                            return;
                        }

                        if (oCFLEvento.ChooseFromListUID == "CFL_JOBN")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_JobName", 0, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                            oDbDataSource.SetValue("U_JobCode", 0, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                        }
                      else  if (oCFLEvento.ChooseFromListUID == "CFL_FGCODE")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_FGCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                }
            }
            #endregion

        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == false)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == formMenuUID)
                {
                    LoadForm(pVal.MenuUID);
                }
            }
        }

        public void LoadForm(string menuID)
        {
            if (menuID == formMenuUID)
            {
                oForm = objclsCommon.LoadXML(formMenuUID, "DocNum", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                clsCFLEntityList.Add(new clsCFLEntity { Alias = "CardType", CondVal = "S", Operation = BoConditionOperation.co_EQUAL });
                objclsCommon.AddChooseFromList_WithList(oForm, "CFL_JOBN", clsCFLEntityList);
            }
            else
            {
                oForm = oApplication.Forms.ActiveForm;
            }
            oForm.Items.Item("DocNum").EnableinFindMode();
            oForm.Items.Item("Series").EnableinAddMode();

            #region Series And DocNum

            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_ChDate").Specific;
                oEdit.String = "t";

                objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_ChDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string docnum = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, docnum);

                #endregion

            }
            catch { }
            #endregion

        }
    }
}
