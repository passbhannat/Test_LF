﻿using Fabric.Classes;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fabric.Custom_Forms
{
    class clsPackingList : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Folder oFolder;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;

        public const string headerTable = "@PACKINGLIST";
        public const string rowTable = "@PACKINGLIST1";

        public const string objType = "PACKINGLIST";
        public const string formMenuUID = "PACKINGLIST";
        const string formTitle = "Packing List";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";
        bool multiItemSelected = false;
        string cflSelected = "";
        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == false)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }


                if (pVal.MenuUID == "PACKINGLIST")
                {
                    LoadForm(pVal.MenuUID);
                }

            }


        }

        public void LoadForm(string menuID)
        {
            if (menuID == formMenuUID)
            {
                oForm = objclsCommon.LoadXML(formMenuUID, "DocNum", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                //List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                //clsCFLEntityList.Add(new clsCFLEntity { Alias = "CardType", CondVal = "S", Operation = BoConditionOperation.co_EQUAL });
                //objclsCommon.AddChooseFromList_WithList(oForm, "CFL_JOBN", clsCFLEntityList);

            }
            else
            {
                oForm = oApplication.Forms.ActiveForm;
            }
            #region Series And DocNum
            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_ChallDt").Specific;
                oEdit.String = "t";

                objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_ChallDt", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string docnum = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, docnum);

                #endregion

            }
            catch { }
            #endregion

        }


    }
}
