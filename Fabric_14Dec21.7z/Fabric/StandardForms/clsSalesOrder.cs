﻿using Fabric.Classes;
using Fabric.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fabric
{
    class clsSalesOrder : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();


        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "ORDR";
        public const string rowTable = "RDR1";
        public const string objType = "17";
        public const string matrixUID = "38";
        const string buttonCalculateUID = "btCalc";
        #endregion

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == true)
            {
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                {
                    if (pVal.ItemUID == "btCalc") 
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        oMatrix = oForm.Items.Item("38").Specific;

                        double dblTotalQuantity = 0;
                        for (int i = 1; i < oMatrix.VisualRowCount; i++)
                        {
                            oEdit = oMatrix.GetCellSpecific("U_QtyPcs", i);
                            string quantity = oEdit.String;
                            double dblQuantity = double.Parse(quantity);
                            dblTotalQuantity = dblTotalQuantity + dblQuantity;
                        }

                        oEdit = oForm.Items.Item("U_TotTaka").Specific;
                        oEdit.String = dblTotalQuantity.ToString();
                    }

                }
            }
            else
            {
                if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                {
                    oForm = oApplication.Forms.Item(pVal.FormUID);

                    #region Jober Code controls
                    SAPbouiCOM.Item oNewItem = oForm.Items.Add("sTotTaka", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                    SAPbouiCOM.Item oItem = oForm.Items.Item("30");
                    oNewItem.Left = oItem.Left;
                    oNewItem.Top = oForm.Items.Item("30").Top + oItem.Height + 5;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width;
                    SAPbouiCOM.StaticText oStaticText = (SAPbouiCOM.StaticText)oNewItem.Specific;
                    oStaticText.Caption = "Total Taka";

                    oNewItem = oForm.Items.Add("U_TotTaka", SAPbouiCOM.BoFormItemTypes.it_EDIT);
                    oItem = oForm.Items.Item("29");
                    oNewItem.Left = oItem.Left;
                    oNewItem.Top = oForm.Items.Item("sTotTaka").Top;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width;
                    oEdit = (SAPbouiCOM.EditText)oNewItem.Specific;
                    oEdit.DataBind.SetBound(true, headerTable, "U_TotTaka");
                    oEdit.Item.Disable();
                     
                    #endregion


                    #region Create Calculate Button

                    oNewItem = oForm.Items.Add(buttonCalculateUID, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                    oItem = oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel));
                    oNewItem.Left = oItem.Left + oItem.Width + 10;
                    oNewItem.Top = oItem.Top;
                    oNewItem.Height = oItem.Height;
                    oNewItem.Width = oItem.Width;
                    SAPbouiCOM.Button oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                    oButton.Caption = "Calculate";

                    #endregion
                }
            }
        }
    }
}
