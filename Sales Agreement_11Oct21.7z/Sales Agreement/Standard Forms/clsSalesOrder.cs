using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using SalesAgreement.Classes;
using System.Linq;
using SalesAgreement.Custom_Form;

namespace SalesAgreement.Standard_Forms
{
    class clsSalesOrder : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string headerTable = "ORDR";
        const string rowTable = "RDR1";
        SAPbouiCOM.Item baseItem;
        SAPbouiCOM.Item newItem;
        SAPbouiCOM.StaticText oStaticText;


        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == false)
                {
                    if (pVal.EventType == BoEventTypes.et_FORM_LOAD)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.Item oItem;
                        SAPbouiCOM.Item xItem;
                        SAPbouiCOM.Button oButton;
                        xItem = oForm.Items.Item("2");
                        oItem = oForm.Items.Add("btCFSA", SAPbouiCOM.BoFormItemTypes.it_BUTTON);

                        oItem.Left = xItem.Left + xItem.Width + 2;
                        oItem.Top = xItem.Top;

                        oItem.Width = oItem.Width + oItem.Width;
                        oItem.Height = xItem.Height;

                        oButton = (SAPbouiCOM.Button)(oItem.Specific);
                        oButton.Caption = "Copy From Agreement";
                    }
                    else if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "btCFSA")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                            {
                                oApplication.StatusBar.SetText("Form should be in Add Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("CardCode", 0).Trim();
                            clsCopyFromSalesQuotation doc = new clsCopyFromSalesQuotation();
                            doc.LoadForm(clsSalesAggrement.formMenuUID, cardcode);
                            oForm = oApplication.Forms.ActiveForm;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method


        #endregion
    }
}
