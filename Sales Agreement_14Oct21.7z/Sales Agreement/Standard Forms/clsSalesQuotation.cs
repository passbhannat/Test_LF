using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;
using SalesAgreement.Classes;
using System.Linq;
using SalesAgreement.Custom_Form;

namespace SalesAgreement.Standard_Forms
{
    class clsSalesQuotation : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        public SAPbouiCOM.ComboBox oCombo;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        const string headerTable = "OQUT";
        const string rowTable = "QUT1";
        SAPbouiCOM.Item baseItem;
        SAPbouiCOM.Item newItem;
        SAPbouiCOM.StaticText oStaticText;


        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == false)
                {
                    if (pVal.EventType == BoEventTypes.et_FORM_LOAD)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.Item oItem;
                        SAPbouiCOM.Item xItem;
                        SAPbouiCOM.Button oButton;
                        xItem = oForm.Items.Item("2");
                        oItem = oForm.Items.Add("btCTSA", SAPbouiCOM.BoFormItemTypes.it_BUTTON);

                        oItem.Left = xItem.Left + xItem.Width + 2;
                        oItem.Top = xItem.Top;

                        oItem.Width = oItem.Width + oItem.Width;
                        oItem.Height = xItem.Height;

                        oButton = (SAPbouiCOM.Button)(oItem.Specific);
                        oButton.Caption = "Copy To Agreement";
                    }
                    else if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                    {
                        if (pVal.ItemUID == "btCTSA")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (oForm.Mode != BoFormMode.fm_OK_MODE)
                            {
                                oApplication.StatusBar.SetText("Form should be in Ok Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                            clsSalesAggrement doc = new clsSalesAggrement();
                            doc.LoadForm(clsSalesAggrement.formMenuUID);
                            oForm = oApplication.Forms.ActiveForm;
                            DateTime date;
                            string datevalue = "";

                            #region Header
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" SELECT *  ");
                            sbQuery.Append(" ,(SELECT SUM(LineTotal) FROM QUT1 A WHERE A.DocEntry = T0.DocEntry) [TotalBeforeDiscount] ");
                            sbQuery.Append(" ,T1.lastName+ ', '+ T1.firstName  [OwnerName] ");
                            sbQuery.Append(" FROM OQUT T0 ");
                            sbQuery.Append(" LEFT JOIN OHEM T1 ON T0.OwnerCode = T1.empID ");
                            sbQuery.Append(" WHERE T0.DocEntry = '" + docEntry + "'");

                            SAPbobsCOM.Recordset oRs = objclsCommon.returnRecord(sbQuery.ToString());
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(clsSalesAggrement.headerTable);
                            string docNum = oRs.Fields.Item("DocNum").Value.ToString();
                            string cardcode = oRs.Fields.Item("CardCode").Value;
                            oCombo = oForm.Items.Item("U_CntCode").Specific;
                            objclsCommon.FillCombo(oCombo, objclsCommon.FillContactPersonQuery(cardcode));

                            oDbDataSource.SetValue("U_CardCode", 0, oRs.Fields.Item("CardCode").Value);
                            oDbDataSource.SetValue("U_CardName", 0, oRs.Fields.Item("CardName").Value);
                            oDbDataSource.SetValue("U_CntCode", 0, oRs.Fields.Item("CntctCode").Value);
                            oDbDataSource.SetValue("U_NumAtCa", 0, oRs.Fields.Item("NumAtCard").Value);
                            oDbDataSource.SetValue("U_DocCur", 0, oRs.Fields.Item("DocCur").Value);
                            oDbDataSource.SetValue("U_DocRate", 0, oRs.Fields.Item("DocRate").Value);
                            oDbDataSource.SetValue("U_SlpCode", 0, oRs.Fields.Item("SlpCode").Value);
                            oDbDataSource.SetValue("U_Owner", 0, oRs.Fields.Item("OwnerCode").Value);
                            oDbDataSource.SetValue("U_OwnerN", 0, oRs.Fields.Item("OwnerName").Value);
                            oDbDataSource.SetValue("U_Remark", 0, oRs.Fields.Item("Comments").Value);


                            oDbDataSource.SetValue("U_TotalBef", 0, oRs.Fields.Item("TotalBeforeDiscount").Value);
                            oDbDataSource.SetValue("U_DiscPer", 0, oRs.Fields.Item("DiscPrcnt").Value);
                            oDbDataSource.SetValue("U_DiscSum", 0, oRs.Fields.Item("DiscSum").Value);
                            oDbDataSource.SetValue("U_TaxSum", 0, oRs.Fields.Item("VatSum").Value);
                            oDbDataSource.SetValue("U_DocTotal", 0, oRs.Fields.Item("DocTotal").Value);
                            oDbDataSource.SetValue("U_Freight", 0, oRs.Fields.Item("TotalExpns").Value);
                            oDbDataSource.SetValue("U_FreightT", 0, oRs.Fields.Item("TaxOnExp").Value);


                            #region Logistics

                            oCombo = oForm.Items.Item("U_ShipTo").Specific;
                            objclsCommon.FillCombo(oCombo, objclsCommon.FillAddressQuery(cardcode, "S"));
                            oDbDataSource.SetValue("U_ShipTo", 0, oRs.Fields.Item("ShipToCode").Value);
                            oDbDataSource.SetValue("U_Address2", 0, oRs.Fields.Item("Address2").Value);
                            oCombo = oForm.Items.Item("U_BillTo").Specific;
                            objclsCommon.FillCombo(oCombo, objclsCommon.FillAddressQuery(cardcode, "B"));
                            oDbDataSource.SetValue("U_BillTo", 0, oRs.Fields.Item("PayToCode").Value);
                            oDbDataSource.SetValue("U_Address", 0, oRs.Fields.Item("Address").Value);
                            oDbDataSource.SetValue("U_Trnsp", 0, oRs.Fields.Item("TrnspCode").Value);
                            oDbDataSource.SetValue("U_LangCode", 0, oRs.Fields.Item("LangCode").Value);
                            oDbDataSource.SetValue("U_UseBill", 0, oRs.Fields.Item("UseBilAddr").Value);
                            oDbDataSource.SetValue("U_ProPres", 0, oRs.Fields.Item("PoPrss").Value);
                            oDbDataSource.SetValue("U_ProDrop", 0, oRs.Fields.Item("PoDropPrss").Value);
                            oDbDataSource.SetValue("U_BPCh", 0, oRs.Fields.Item("BPChCode").Value);
                            oCombo = oForm.Items.Item("U_BPChCnt").Specific;
                            objclsCommon.FillCombo(oCombo, objclsCommon.FillContactPersonQuery(oRs.Fields.Item("BPChCode").Value));

                            oDbDataSource.SetValue("U_BPChCnt", 0, oRs.Fields.Item("BPChCntc").Value);

                            #endregion

                            #region Accounting

                            oDbDataSource.SetValue("U_GroupNum", 0, oRs.Fields.Item("GroupNum").Value);
                            oDbDataSource.SetValue("U_PayMeth", 0, oRs.Fields.Item("PeyMethod").Value);
                            oDbDataSource.SetValue("U_Project", 0, oRs.Fields.Item("Project").Value);

                            #endregion

                            #region UDF
                            oDbDataSource.SetValue("U_EMD", 0, oRs.Fields.Item("U_EMD").Value);
                            try
                            {
                                try
                                {
                                    date = oRs.Fields.Item("U_EMDDate").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_EMDDate", 0, datevalue);
                                }
                                catch { }
                                oDbDataSource.SetValue("U_EMDValid", 0, oRs.Fields.Item("U_EMDValid").Value);
                                try
                                {
                                    date = oRs.Fields.Item("U_EMDRDate").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_EMDRDate", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_LCSDate").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_LCSDate", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_LCEDate").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_LCEDate", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_REVDATE").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_REVDATE", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_ShipBillDate").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_ShipBillDate", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_eway_bill_date").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_eway_bill_date", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_TransporterBillDate").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_TransporterBillDate", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_SDATE").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_SDATE", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_EDATE").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_EDATE", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_BGDt").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_BGDt", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_AmdDt").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_AmdDt", 0, datevalue);
                                }
                                catch { }
                                try
                                {
                                    date = oRs.Fields.Item("U_FDRDATE").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_FDRDATE", 0, datevalue);
                                }
                                catch { }

                                oDbDataSource.SetValue("U_BGExp", 0, oRs.Fields.Item("U_BGExp").Value);
                            }
                            catch (Exception EX)
                            {

                            }
                            oDbDataSource.SetValue("U_EMDAmt", 0, oRs.Fields.Item("U_EMDAmt").Value);
                            oDbDataSource.SetValue("U_EMDDetails", 0, oRs.Fields.Item("U_EMDDetails").Value);
                            oDbDataSource.SetValue("U_LCNo", 0, oRs.Fields.Item("U_LCNo").Value);
                            oDbDataSource.SetValue("U_LCAMT", 0, oRs.Fields.Item("U_LCAMT").Value);
                            oDbDataSource.SetValue("U_Consignee", 0, oRs.Fields.Item("U_Consignee").Value);
                            oDbDataSource.SetValue("U_Purchase", 0, oRs.Fields.Item("U_Purchase").Value);
                            oDbDataSource.SetValue("U_Overhead", 0, oRs.Fields.Item("U_Overhead").Value);
                            oDbDataSource.SetValue("U_DeliveryTerm", 0, oRs.Fields.Item("U_DeliveryTerm").Value);
                            oDbDataSource.SetValue("U_OffeNo", 0, oRs.Fields.Item("U_OffeNo").Value);
                            oDbDataSource.SetValue("U_PaymentTerm", 0, oRs.Fields.Item("U_PaymentTerm").Value);
                            oDbDataSource.SetValue("U_Insurance", 0, oRs.Fields.Item("U_Insurance").Value);
                            oDbDataSource.SetValue("U_ConPF", 0, oRs.Fields.Item("U_ConPF").Value);
                            oDbDataSource.SetValue("U_Transporter", 0, oRs.Fields.Item("U_Transporter").Value);
                            oDbDataSource.SetValue("U_VehicleNo", 0, oRs.Fields.Item("U_VehicleNo").Value);
                            oDbDataSource.SetValue("U_NoofPack", 0, oRs.Fields.Item("U_NoofPack").Value);
                            oDbDataSource.SetValue("U_LRNo", 0, oRs.Fields.Item("U_LRNo").Value);
                            oDbDataSource.SetValue("U_Location", 0, oRs.Fields.Item("U_Location").Value);
                            oDbDataSource.SetValue("U_REVNO", 0, oRs.Fields.Item("U_REVNO").Value);

                            oDbDataSource.SetValue("U_PriceBasis", 0, oRs.Fields.Item("U_PriceBasis").Value);
                            oDbDataSource.SetValue("U_PackDetails", 0, oRs.Fields.Item("U_PackDetails").Value);
                            oDbDataSource.SetValue("U_Returnable", 0, oRs.Fields.Item("U_Returnable").Value);
                            oDbDataSource.SetValue("U_RMName", 0, oRs.Fields.Item("U_RMName").Value);
                            oDbDataSource.SetValue("U_Owner_IT", 0, oRs.Fields.Item("U_Owner_IT").Value);
                            oDbDataSource.SetValue("U_Note", 0, oRs.Fields.Item("U_Note").Value);
                            oDbDataSource.SetValue("U_Shippedper", 0, oRs.Fields.Item("U_Shippedper").Value);
                            oDbDataSource.SetValue("U_BOLNo", 0, oRs.Fields.Item("U_BOLNo").Value);
                            oDbDataSource.SetValue("U_SBNo", 0, oRs.Fields.Item("U_SBNo").Value);
                            oDbDataSource.SetValue("U_PortS", 0, oRs.Fields.Item("U_PortS").Value);
                            oDbDataSource.SetValue("U_PordD", 0, oRs.Fields.Item("U_PordD").Value);

                            oDbDataSource.SetValue("U_FinalD", 0, oRs.Fields.Item("U_FinalD").Value);
                            oDbDataSource.SetValue("U_ShipingMasrks", 0, oRs.Fields.Item("U_ShipingMasrks").Value);
                            oDbDataSource.SetValue("U_CaseNo", 0, oRs.Fields.Item("U_CaseNo").Value);
                            oDbDataSource.SetValue("U_NETWT", 0, oRs.Fields.Item("U_NETWT").Value);
                            oDbDataSource.SetValue("U_ORIGIN", 0, oRs.Fields.Item("U_ORIGIN").Value);
                            oDbDataSource.SetValue("U_Type", 0, oRs.Fields.Item("U_Type").Value);
                            oDbDataSource.SetValue("U_Packing", 0, oRs.Fields.Item("U_Packing").Value);
                            oDbDataSource.SetValue("U_ContainerNo", 0, oRs.Fields.Item("U_ContainerNo").Value);
                            oDbDataSource.SetValue("U_SealNo", 0, oRs.Fields.Item("U_SealNo").Value);
                            oDbDataSource.SetValue("U_GRWT", 0, oRs.Fields.Item("U_GRWT").Value);

                            oDbDataSource.SetValue("U_CARBOYS", 0, oRs.Fields.Item("U_CARBOYS").Value);
                            oDbDataSource.SetValue("U_ShipBillNo", 0, oRs.Fields.Item("U_ShipBillNo").Value);

                            oDbDataSource.SetValue("U_DrwbkAmt", 0, oRs.Fields.Item("U_DrwbkAmt").Value);
                            oDbDataSource.SetValue("U_CompositeContract", 0, oRs.Fields.Item("U_CompositeContract").Value);
                            oDbDataSource.SetValue("U_Composite", 0, oRs.Fields.Item("U_Composite").Value);
                            try
                            {
                                oDbDataSource.SetValue("U_Documents", 0, oRs.Fields.Item("U_Documents").Value);
                                oDbDataSource.SetValue("U_po_loi_basic_rate", 0, oRs.Fields.Item("U_po_loi_basic_rate").Value);
                                oDbDataSource.SetValue("U_eway_bill_no", 0, oRs.Fields.Item("U_eway_bill_no").Value);


                                oDbDataSource.SetValue("U_To", 0, oRs.Fields.Item("U_To").Value);
                                oDbDataSource.SetValue("U_CC", 0, oRs.Fields.Item("U_CC").Value);
                                oDbDataSource.SetValue("U_BCC", 0, oRs.Fields.Item("U_BCC").Value);
                                oDbDataSource.SetValue("U_contact_person_at_factory", 0, oRs.Fields.Item("U_contact_person_at_factory").Value);
                                oDbDataSource.SetValue("U_ShopOrderNo", 0, oRs.Fields.Item("U_ShopOrderNo").Value);
                                oDbDataSource.SetValue("U_Plant", 0, oRs.Fields.Item("U_Plant").Value);
                            }
                            catch { }
                            oDbDataSource.SetValue("U_AmendmentNo", 0, oRs.Fields.Item("U_AmendmentNo").Value);
                            try
                            {
                                date = oRs.Fields.Item("U_ChallanDate2").Value;
                                datevalue = date.ToString("yyyyMMdd");
                                oDbDataSource.SetValue("U_ChallanDate2", 0, datevalue);
                            }
                            catch { }
                            try
                            {
                                date = oRs.Fields.Item("U_AmendmentDate").Value;
                                datevalue = date.ToString("yyyyMMdd");
                                oDbDataSource.SetValue("U_AmendmentDate", 0, datevalue);
                            }
                            catch { }
                            try
                            {
                                oDbDataSource.SetValue("U_LRDate", 0, oRs.Fields.Item("U_LRDate").Value);
                            }
                            catch { }
                            oDbDataSource.SetValue("U_TransporterBillNo", 0, oRs.Fields.Item("U_TransporterBillNo").Value);

                            oDbDataSource.SetValue("U_TransporterBillAmt", 0, oRs.Fields.Item("U_TransporterBillAmt").Value);
                            oDbDataSource.SetValue("U_IGST", 0, oRs.Fields.Item("U_IGST").Value);
                            oDbDataSource.SetValue("U_SupplyType", 0, oRs.Fields.Item("U_SupplyType").Value);
                            oDbDataSource.SetValue("U_SignAdd", 0, oRs.Fields.Item("U_SignAdd").Value);
                            oDbDataSource.SetValue("U_LogoRequire", 0, oRs.Fields.Item("U_LogoRequire").Value);
                            oDbDataSource.SetValue("U_PaymentTerm_1", 0, oRs.Fields.Item("U_PaymentTerm_1").Value);
                            oDbDataSource.SetValue("U_PaymentTerm_2", 0, oRs.Fields.Item("U_PaymentTerm_2").Value);
                            oDbDataSource.SetValue("U_PaymnetTerm_3", 0, oRs.Fields.Item("U_PaymnetTerm_3").Value);

                            oDbDataSource.SetValue("U_EPC_ReceivedAmt", 0, oRs.Fields.Item("U_EPC_ReceivedAmt").Value);
                            oDbDataSource.SetValue("U_EPC_ClaimAmt", 0, oRs.Fields.Item("U_EPC_ClaimAmt").Value);
                            oDbDataSource.SetValue("U_EPC_PendingAmt", 0, oRs.Fields.Item("U_EPC_PendingAmt").Value);
                            try
                            {
                                date = oRs.Fields.Item("U_ChallanDate1").Value;
                                datevalue = date.ToString("yyyyMMdd");
                                oDbDataSource.SetValue("U_ChallanDate1", 0, datevalue);
                            }
                            catch { }

                            oDbDataSource.SetValue("U_BillToID", 0, oRs.Fields.Item("U_BillToID").Value);
                            oDbDataSource.SetValue("U_ShiplToID", 0, oRs.Fields.Item("U_ShiplToID").Value);
                            oDbDataSource.SetValue("U_PaymnetTerm_4", 0, oRs.Fields.Item("U_PaymnetTerm_4").Value);
                            oDbDataSource.SetValue("U_EPC_PendingAmt1", 0, oRs.Fields.Item("U_EPC_PendingAmt1").Value);
                            oDbDataSource.SetValue("U_SignAddP", 0, oRs.Fields.Item("U_SignAddP").Value);
                            oDbDataSource.SetValue("U_Vehicle_Capacity", 0, oRs.Fields.Item("U_Vehicle_Capacity").Value);
                            oDbDataSource.SetValue("U_FreightAmount", 0, oRs.Fields.Item("U_FreightAmount").Value);
                            oDbDataSource.SetValue("U_FreightCostActual", 0, oRs.Fields.Item("U_FreightCostActual").Value);
                            oDbDataSource.SetValue("U_PrintType", 0, oRs.Fields.Item("U_PrintType").Value);
                            oDbDataSource.SetValue("U_PaymnetTerm_5", 0, oRs.Fields.Item("U_PaymnetTerm_5").Value);
                            oDbDataSource.SetValue("U_EPC_PendingAmt3", 0, oRs.Fields.Item("U_EPC_PendingAmt3").Value);
                            oDbDataSource.SetValue("U_LRReceived", 0, oRs.Fields.Item("U_LRReceived").Value);
                            oDbDataSource.SetValue("U_PODis", 0, oRs.Fields.Item("U_PODis").Value);
                            oDbDataSource.SetValue("U_BGRequire", 0, oRs.Fields.Item("U_BGRequire").Value);

                            oDbDataSource.SetValue("U_BGPersantage", 0, oRs.Fields.Item("U_BGPersantage").Value);
                            oDbDataSource.SetValue("U_LCRequired", 0, oRs.Fields.Item("U_LCRequired").Value);
                            oDbDataSource.SetValue("U_BGNo", 0, oRs.Fields.Item("U_BGNo").Value);

                            oDbDataSource.SetValue("U_BGAmt", 0, oRs.Fields.Item("U_BGAmt").Value);
                            oDbDataSource.SetValue("U_AmdNo", 0, oRs.Fields.Item("U_AmdNo").Value);

                            try
                            {
                                oDbDataSource.SetValue("U_BGClaim", 0, oRs.Fields.Item("U_BGClaim").Value);
                            }
                            catch { }
                            try
                            {
                                oDbDataSource.SetValue("U_FDRNO", 0, oRs.Fields.Item("U_FDRNO").Value);
                            }
                            catch { }
                            oDbDataSource.SetValue("U_FDRAMT", 0, oRs.Fields.Item("U_FDRAMT").Value);

                            #endregion

                            //Add Fields
                            #endregion

                            #region Rows
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" SELECT * FROM ");
                            sbQuery.Append(" QUT1 T0 ");
                            sbQuery.Append(" WHERE T0.DocEntry = '" + docEntry + "'");

                            oRs = objclsCommon.returnRecord(sbQuery.ToString());
                            oMatrix = oForm.Items.Item("mtx1").Specific;
                            oMatrix.FlushToDataSource();

                            oDbDataSource = oForm.DataSources.DBDataSources.Item(clsSalesAggrement.rowTable);
                            int rowNo = 0;
                            while (!oRs.EoF)
                            {
                                oDbDataSource.InsertRecord(rowNo);
                                oDbDataSource.SetValue("U_ItemCode", rowNo, oRs.Fields.Item("ItemCode").Value);
                                oDbDataSource.SetValue("U_BPCatNo", rowNo, oRs.Fields.Item("SubCatNum").Value);
                                oDbDataSource.SetValue("U_ItemName", rowNo, oRs.Fields.Item("Dscription").Value);
                                oDbDataSource.SetValue("U_WhsCode", rowNo, oRs.Fields.Item("WhsCode").Value);
                                oDbDataSource.SetValue("U_Location", rowNo, oRs.Fields.Item("LocCode").Value);
                                oDbDataSource.SetValue("U_Qty", rowNo, oRs.Fields.Item("Quantity").Value);
                                oDbDataSource.SetValue("U_DelQty", rowNo, oRs.Fields.Item("DelivrdQty").Value);

                                oDbDataSource.SetValue("U_Price", rowNo, oRs.Fields.Item("PriceBefDi").Value);
                                oDbDataSource.SetValue("U_PriceAD", rowNo, oRs.Fields.Item("Price").Value);
                                oDbDataSource.SetValue("U_DiscPer", rowNo, oRs.Fields.Item("DiscPrcnt").Value);
                                oDbDataSource.SetValue("U_DiscPer", rowNo, oRs.Fields.Item("DiscPrcnt").Value);
                                oDbDataSource.SetValue("U_TaxCode", rowNo, oRs.Fields.Item("TaxCode").Value);
                                oDbDataSource.SetValue("U_LineTot", rowNo, oRs.Fields.Item("LineTotal").Value);
                                oDbDataSource.SetValue("U_BaseType", rowNo, "23");
                                oDbDataSource.SetValue("U_BaseEn", rowNo, docEntry.ToString());
                                oDbDataSource.SetValue("U_BaseRef", rowNo, docNum.ToString());
                                oDbDataSource.SetValue("U_BaseLine", rowNo, oRs.Fields.Item("LineNum").Value);
                                oDbDataSource.SetValue("U_PackDesc", rowNo, oRs.Fields.Item("U_PackDesc").Value);
                                oDbDataSource.SetValue("U_GRWT", rowNo, oRs.Fields.Item("U_GRWT").Value);
                                oDbDataSource.SetValue("U_AddDescp", rowNo, oRs.Fields.Item("U_AddDescp").Value);
                                oDbDataSource.SetValue("U_SRNO", rowNo, oRs.Fields.Item("U_SRNO").Value);
                                oDbDataSource.SetValue("U_NeWt", rowNo, oRs.Fields.Item("U_NeWt").Value);
                                oDbDataSource.SetValue("U_TaxRate", rowNo, oRs.Fields.Item("VatPrcnt").Value);
                                oDbDataSource.SetValue("U_TaxSum", rowNo, oRs.Fields.Item("VatSum").Value);
                                oDbDataSource.SetValue("U_DistRule", rowNo, oRs.Fields.Item("OcrCode").Value);
                                oDbDataSource.SetValue("U_Project", rowNo, oRs.Fields.Item("Project").Value);
                                oDbDataSource.SetValue("U_HSN", rowNo, oRs.Fields.Item("HsnEntry").Value);
                                oDbDataSource.SetValue("U_FreeText", rowNo, oRs.Fields.Item("FreeTxt").Value);
                                oDbDataSource.SetValue("U_LegText", rowNo, oRs.Fields.Item("LegalText").Value);
                                try
                                {
                                    date = oRs.Fields.Item("DocDate").Value;
                                    datevalue = date.ToString("yyyyMMdd");
                                    oDbDataSource.SetValue("U_DelDate", rowNo, datevalue);
                                }
                                catch { }
                                //Add Fields

                                oDbDataSource.SetValue("U_PONum", rowNo, oRs.Fields.Item("U_PONum").Value);
                                oDbDataSource.SetValue("U_PUOM", rowNo, oRs.Fields.Item("U_PUOM").Value);

                                //Add Fields
                                rowNo++;
                                oRs.MoveNext();
                            }
                            oMatrix.LoadFromDataSource();
                            objclsCommon.ReleaseObject(oRs);

                            #endregion

                            #region Freight
                            SAPbouiCOM.DBDataSource oFreightDataSource = oForm.DataSources.DBDataSources.Item(clsSalesAggrement.freightrowTable);
                            oFreightDataSource.Clear();
                            rowNo = 0;
                            sbQuery = new StringBuilder();
                            sbQuery.Append(" SELECT * FROM  ");
                            sbQuery.Append(" QUT3 T1");
                            sbQuery.Append(" WHERE T1.DocEntry = '" + docEntry + "'  ");
                            oRs = objclsCommon.returnRecord(sbQuery.ToString());
                            while (!oRs.EoF)
                            {
                                oFreightDataSource.InsertRecord(rowNo);
                                oFreightDataSource.SetValue("U_ExpCode", rowNo, oRs.Fields.Item("ExpnsCode").Value.ToString());
                                oFreightDataSource.SetValue("U_TaxCode", rowNo, oRs.Fields.Item("TaxCode").Value.ToString());
                                oFreightDataSource.SetValue("U_TaxRate", rowNo, oRs.Fields.Item("VatPrcnt").Value.ToString());
                                oFreightDataSource.SetValue("U_TaxSum", rowNo, oRs.Fields.Item("VatSum").Value.ToString());
                                oFreightDataSource.SetValue("U_NetAmt", rowNo, oRs.Fields.Item("LineTotal").Value.ToString());
                                oFreightDataSource.SetValue("U_GrAmt", rowNo, oRs.Fields.Item("GrsAmount").Value.ToString());
                                rowNo++;
                                oRs.MoveNext();
                            }
                            #endregion

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        private void GenerateEC(string manSerialNum, string serialNum, string itemcode, string customerCode)
        {
            SAPbobsCOM.ICustomerEquipmentCards customerEquipmentCard;
            customerEquipmentCard = (SAPbobsCOM.ICustomerEquipmentCards)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oCustomerEquipmentCards);
            customerEquipmentCard.ManufacturerSerialNum = manSerialNum;
            customerEquipmentCard.InternalSerialNum = serialNum;
            customerEquipmentCard.ItemCode = itemcode;
            customerEquipmentCard.CustomerCode = customerCode;
            int iAdd = customerEquipmentCard.Add();
            if (iAdd != 0)
            {
                string errMessage = oCompany.GetLastErrorDescription();
                oApplication.SetStatusBarMessage(errMessage, BoMessageTime.bmt_Short, false);
            }
            else
            {
                oApplication.StatusBar.SetText("Equipment card created successfully", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
            }

        }

        #endregion
    }
}
