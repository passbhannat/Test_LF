﻿using SalesAgreement.Classes;
using SalesAgreement.Extensions;
using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace SalesAgreement.Custom_Form
{
    class clsSalesAggrement : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.Folder oFolder;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@SALESAGR";
        public const string rowTable = "@SALESAGR1";
        public const string freightrowTable = "@SALESAGR2";
        public const string objType = "SALESAGR";
        public const string formMenuUID = "SALESAGR";
        const string formTitle = "Sales Agreement";
        public const string matrixUID = "mtx1";
        const string matrixPrimaryUDF = "U_ItemCode";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string name = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).Trim();
                                if (name == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Customer is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                if (oMatrix.VisualRowCount == 0)
                                {
                                    oApplication.StatusBar.SetText("Row level data is mandatory", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    BubbleEvent = false;
                                    return;
                                }
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    if (i == 0)
                                    {
                                        string itemcode = oDbDataSource.GetValue("U_ItemCode", i);
                                        if (itemcode == string.Empty)
                                        {
                                            oApplication.StatusBar.SetText("Item Code is mandatory for Row No: " + (i + 1).ToString(), BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                            BubbleEvent = false;
                                            return;
                                        }
                                    }
                                }
                            }

                            else if (pVal.ItemUID == "btCanc")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Status", 0).Trim();
                                if (status == "L")
                                {
                                    oApplication.StatusBar.SetText("Document is already cancelled.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (oForm.Mode != BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                int i = oApplication.MessageBox("Do you really want to cancel document?", 1, "Yes", "No", "");
                                if (i == 1)
                                {
                                    string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                    objclsCommon.SelectRecord("UPDATE \"" + headerTable + "\" SET U_Status = 'L' WHERE DocEntry = '" + docEntry + "'");
                                    objclsCommon.RefreshRecord();
                                }
                            }

                            else if (pVal.ItemUID == "lbFreight")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(freightrowTable);
                                List<clsFreightEntity> _clsFreightEntityList = new List<clsFreightEntity>();
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    clsFreightEntity _clsFreightEntity = new clsFreightEntity();
                                    _clsFreightEntity.ExpCode = oDbDataSource.GetValue("U_ExpCode", i).ToString();
                                    _clsFreightEntity.TaxCode = oDbDataSource.GetValue("U_TaxCode", i).ToString();
                                    _clsFreightEntity.TaxRate = double.Parse(oDbDataSource.GetValue("U_TaxRate", i).ToString());
                                    _clsFreightEntity.TaxSum = double.Parse(oDbDataSource.GetValue("U_TaxSum", i).ToString());
                                    _clsFreightEntity.NetAmt = double.Parse(oDbDataSource.GetValue("U_NetAmt", i).ToString());
                                    _clsFreightEntity.GrAmt = double.Parse(oDbDataSource.GetValue("U_GrAmt", i).ToString());
                                    _clsFreightEntityList.Add(_clsFreightEntity);
                                }

                                clsVariables.BaseForm = oForm;
                                clsSalesAgreementFreight _clsSalesAgreementFreight = new clsSalesAgreementFreight();
                                _clsSalesAgreementFreight.LoadForm(clsSalesAgreementFreight.formMenuUID, "");
                                oForm = oApplication.Forms.ActiveForm;
                                oMatrix = oForm.Items.Item(clsSalesAgreementFreight.matrixUID).Specific;
                                SAPbouiCOM.DBDataSource freightDBDataSource = oForm.DataSources.DBDataSources.Item(clsSalesAgreementFreight.rowTable);

                                for (int i = 0; i < freightDBDataSource.Size; i++)
                                {
                                    string expnsecode = freightDBDataSource.GetValue("ExpnsCode", i).ToString();
                                    List<clsFreightEntity> expnseData = _clsFreightEntityList.Where(a => a.ExpCode == expnsecode).ToList();
                                    if (expnseData.Count > 0)
                                    {
                                        freightDBDataSource.SetValue("ExpnsCode", i, expnseData[0].ExpCode);
                                        freightDBDataSource.SetValue("TaxCode", i, expnseData[0].TaxCode);
                                        freightDBDataSource.SetValue("VatSum", i, expnseData[0].TaxSum.ToString());
                                        freightDBDataSource.SetValue("LineTotal", i, expnseData[0].NetAmt.ToString());
                                        freightDBDataSource.SetValue("VatPrcnt", i, expnseData[0].TaxRate.ToString());
                                        freightDBDataSource.SetValue("GrsAmount", i, expnseData[0].GrAmt.ToString());
                                    }
                                }
                                oMatrix.LoadFromDataSource();

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.FormTypeEx == formMenuUID && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).ToString();
                                if (docNum.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    return;
                                }

                            }
                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_BP")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                                oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                                string cardcode = oDataTable.GetValue(CommonFields.CardCode, 0).ToString();
                                oCombo = oForm.Items.Item("U_CntCode").Specific;
                                objclsCommon.FillCombo(oCombo, objclsCommon.FillContactPersonQuery(cardcode));

                                oDbDataSource.SetValue("U_CntCode", 0, oDataTable.GetValue("CntctPrsn", 0).ToString());


                                oCombo = oForm.Items.Item("U_BillTo").Specific;
                                objclsCommon.FillCombo(oCombo, objclsCommon.FillAddressQuery(cardcode, "B"));

                                oCombo = oForm.Items.Item("U_ShipTo").Specific;
                                objclsCommon.FillCombo(oCombo, objclsCommon.FillAddressQuery(cardcode, "S"));

                                string shipTo = oDataTable.GetValue("ShipToDef", 0).ToString();
                                oDbDataSource.SetValue("U_ShipTo", 0, shipTo);
                                string fulladdress = objclsCommon.GetFullBPAddress(cardcode, shipTo, "S");
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Address2", 0, fulladdress);

                                string billTo = oDataTable.GetValue("BillToDef", 0).ToString();
                                oDbDataSource.SetValue("U_BillTo", 0, billTo);
                                fulladdress = objclsCommon.GetFullBPAddress(cardcode, billTo, "B");
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Address", 0, fulladdress);

                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_ITEM")
                            {

                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                string itemcode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                oDbDataSource.SetValue("U_ItemCode", pVal.Row - 1, itemcode);
                                oDbDataSource.SetValue("U_ItemName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue("U_Qty", pVal.Row - 1, "1");

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_WHS")
                            {

                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_WhsCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_TAX")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_TaxCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue("U_TaxRate", pVal.Row - 1, oDataTable.GetValue("Rate", 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                CalculateLineTotal(pVal.FormUID, pVal.Row);
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == BoEventTypes.et_COMBO_SELECT)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "btCopyFrom")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).ToString();
                                if (cardcode == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select customer", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                clsVariables.BaseForm = oForm;
                                clsCopyFromSalesQuotation _clsCopyFromSalesQuotation = new clsCopyFromSalesQuotation();
                                _clsCopyFromSalesQuotation.LoadForm(clsCopyFromSalesQuotation.formMenuUID, cardcode);
                            }
                            else if (pVal.ItemUID == "U_ShipTo")
                            {
                                string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).ToString();
                                string address = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(pVal.ItemUID, 0).ToString();

                                string fulladdress = objclsCommon.GetFullBPAddress(cardcode, address, "S");
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Address2", 0, fulladdress);
                            }
                            else if (pVal.ItemUID == "U_BillTo")
                            {
                                string cardcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).ToString();
                                string address = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(pVal.ItemUID, 0).ToString();

                                string fulladdress = objclsCommon.GetFullBPAddress(cardcode, address, "B");
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Address", 0, fulladdress);
                            }
                        }
                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (clsVariables.boolCFLSelected)
                            {
                                clsVariables.boolCFLSelected = false;
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                clsVariables.RowNo = 0;
                                clsVariables.ColNo = 0;
                            }
                        }
                        #endregion

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ColUID == "U_Qty" || pVal.ColUID == "U_Price" || pVal.ColUID == "U_DiscPer")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;

                                CalculateLineTotal(pVal.FormUID, pVal.Row);
                                oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                clsVariables.RowNo = 0;
                                clsVariables.ColNo = 0;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD
                        || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();

                        //sbQuery = new StringBuilder();
                        //sbQuery.Append(" UPDATE T0");
                        //sbQuery.Append(" SET T0.U_OpenQty = T0.U_OpenQty - T1.Quantity ");
                        //sbQuery.Append(" FROM \"" + clsSalesAggrement.rowTable + "\" T0");
                        //sbQuery.Append(" INNER JOIN RDR1 T1 ON T0.LineId = T1.U_BaseLine AND T0.DocEntry = T1.U_BaseEn  ");
                        //sbQuery.Append(" WHERE T1.DocEntry = '" + docEntry + "' AND T0.Object = '" + clsSalesAggrement.objType + "' ");
                        //objclsCommon.SelectRecord(sbQuery.ToString());

                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    //string FormID;
                    //if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    //{
                    //    oForm = oApplication.Forms.Item(FormID);
                    //    oForm.Select();
                    //    return;
                    //}
                    objclsCommon.LoadXML(menuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DuplicateRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CancelRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.CloseRow), true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oForm.DataSources.DBDataSources.Add(freightrowTable);

                    SAPbouiCOM.ButtonCombo oButtonCombo = oForm.Items.Item("btCopyFrom").Specific;
                    oButtonCombo.ValidValues.Add("23", "Sales Quotation");

                    //oButtonCombo = oForm.Items.Item("btCopyTo").Specific;
                    //oButtonCombo.ValidValues.Add("17", "Sales Order");

                    oCombo = oForm.Items.Item("U_DocCur").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"CurrCode\", T0.\"CurrName\" FROM OCRN T0");

                    oCombo = oForm.Items.Item("U_SlpCode").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"SlpCode\", T0.\"SlpName\" FROM OSLP T0 ORDER BY T0.\"SlpCode\" ");


                    oCombo = oForm.Items.Item("U_Trnsp").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"TrnspCode\", T0.\"TrnspName\" FROM OSHP T0");

                    oCombo = oForm.Items.Item("U_LangCode").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"Code\", T0.\"Name\" FROM OLNG T0");

                    oCombo = oForm.Items.Item("U_GroupNum").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"GroupNum\", T0.\"PymntGroup\" FROM OCTG T0");

                    oCombo = oForm.Items.Item("U_PayMeth").Specific;
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"CrTypeCode\", T0.\"CrTypeName\" FROM OCRP T0");

                    //oCombo = oForm.Items.Item("U_Branch").Specific;
                    //objclsCommon.FillCombo(oCombo, "SELECT T0.\"BPLId\", T0.\"BPLName\" FROM OBPL T0 WHERE \"Disabled\" = 'N' ");

                    List<clsCFLEntity> clsCFLEntityList = new List<clsCFLEntity>();
                    clsCFLEntityList.Add(new clsCFLEntity { Alias = "CardType", CondVal = "C", Operation = BoConditionOperation.co_EQUAL });
                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_BP", clsCFLEntityList);

                    oMatrix = oForm.Items.Item(matrixUID).Specific;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    oCombo = oMatrix.GetCellSpecific("U_SlpCode", 1);
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"SlpCode\", T0.\"SlpName\" FROM OSLP T0 ORDER BY T0.\"SlpCode\" ");

                    oCombo = oMatrix.GetCellSpecific("U_Location", 1);
                    objclsCommon.FillCombo(oCombo, "SELECT T0.\"Code\", T0.\"Location\" FROM OLCT T0 ORDER BY T0.\"Code\" ");

                    oCombo = oMatrix.GetCellSpecific("U_HSN", 1);
                    objclsCommon.FillCombo(oCombo, "SELECT AbsEntry,ChapterID  FROM OCHP T0 ");

                    oCombo = oMatrix.GetCellSpecific("U_BaseType", 1);
                    objclsCommon.FillCombo(oCombo, "SELECT '23' Code,'Sales Quotation' Name ");

                    oCombo = oMatrix.GetCellSpecific("U_TrgtType", 1);
                    objclsCommon.FillCombo(oCombo, "SELECT '17' Code,'Sales Order' Name ");

                    oCombo = oMatrix.GetCellSpecific("U_RowStat", 1);
                    objclsCommon.FillCombo(oCombo, "SELECT 'O' Code,'Open' Name UNION ALL SELECT 'C' Code,'Closed' Name ");
                }
                oEdit = oForm.Items.Item("U_DocDate").Specific;
                oEdit.String = "t";
                oEdit = oForm.Items.Item("U_DueDate").Specific;
                oEdit.String = "t";
                oEdit = oForm.Items.Item("U_PostDate").Specific;
                oEdit.String = "t";
                oMatrix = oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oForm.Items.Item("DocNum").EnableinFindMode();
                oForm.Items.Item("DocEntry").EnableinFindMode();
                oForm.Items.Item("U_Status").EnableinFindMode();
                oForm.Items.Item("btCopyFrom").EnableinAddMode();

                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_DocDate").Specific;
                    oEdit.String = "t";

                    objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_DocDate", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                    #endregion

                }
                catch { }
                #endregion

                //oForm.Items.Item("DocEntry").EnableinFindMode();
                //string autoCode = objclsCommon.SelectRecord("SELECT MAX(Cast(Code as numeric(19,6))) FROM \"" + headerTable + "\"");
                //int iAutoCode = autoCode == string.Empty ? 1 : int.Parse(autoCode);
                //iAutoCode = iAutoCode + 1;
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Status", 0, "O");
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_DocCur", 0, "INR");
                oFolder = oForm.Items.Item("fld1").Specific;
                oFolder.Select();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsCommon.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void CalculateLineTotal(string formuid, int rowNo)
        {
            oForm = oApplication.Forms.Item(formuid);
            double headerDiscPer = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_DiscPer", 0));

            oMatrix = oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            double qty = double.Parse(oDbDataSource.GetValue("U_Qty", rowNo - 1));
            double price = double.Parse(oDbDataSource.GetValue("U_Price", rowNo - 1));
            double taxrate = double.Parse(oDbDataSource.GetValue("U_TaxRate", rowNo - 1));
            double discper = double.Parse(oDbDataSource.GetValue("U_DiscPer", rowNo - 1));

            double discAmount = (qty * price) * discper / 100;
            double rowTotal1 = qty * price;
            double rowTotal2 = qty * price * discper / 100;
            double rowTotal = rowTotal1 - rowTotal2;
            double taxamount = (rowTotal * taxrate / 100) - (rowTotal * taxrate / 100) * headerDiscPer / 100;

            oDbDataSource.SetValue("U_LineTot", rowNo - 1, rowTotal.ToString());
            oDbDataSource.SetValue("U_DiscSum", rowNo - 1, discAmount.ToString());
            oDbDataSource.SetValue("U_TaxSum", rowNo - 1, taxamount.ToString());
            oMatrix.LoadFromDataSource();
            CalculateSubTotal(formuid);
        }

        public void CalculateSubTotal(string formuid)
        {
            oForm = oApplication.Forms.Item(formuid);
            oMatrix = oForm.Items.Item(matrixUID).Specific;

            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            double dblTotalbeforeDiscount = 0;
            double totalTax = 0;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                double dblTotal = double.Parse(oDbDataSource.GetValue("U_LineTot", i));
                double dblTaxAmt = double.Parse(oDbDataSource.GetValue("U_TaxSum", i));
                dblTotalbeforeDiscount = dblTotalbeforeDiscount + dblTotal;
                totalTax = totalTax + dblTaxAmt;
            }
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotalBef", 0, dblTotalbeforeDiscount.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TaxSum", 0, totalTax.ToString());
            CalculateFooter(formuid);
        }

        private void CalculateFooter(string formuid)
        {
            oForm = oApplication.Forms.Item(formuid);
            double totalBefDisc = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotalBef", 0));
            double discAmt = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_DiscSum", 0));
            double freight = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_Freight", 0));
            double tax = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TaxSum", 0));

            //oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TaxSum", 0, dblTotalbeforeDiscount.ToString());
            //double freightTaxAmount = 0; //+this.oForm.controls['FreightTaxAmount'].value;
            double freightTaxAmount = double.Parse(oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FreightT", 0));

            double totalAfterDisc = totalBefDisc - discAmt;
            double totalTaxAmount = tax + freightTaxAmount;
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TaxSum", 0, totalTaxAmount.ToString());
            double doctotal = totalBefDisc - discAmt + freight + totalTaxAmount;
            double fractionAmount = +(doctotal % 1);
            if (fractionAmount >= 0.50)
            {
                fractionAmount = +(1 - fractionAmount);
            }
            else
            {
                fractionAmount = -fractionAmount;
            }
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_RoundSum", 0, fractionAmount.ToString());
            doctotal = doctotal + fractionAmount;
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_DocTotal", 0, Math.Round(doctotal, 2).ToString());

        }
    }
}
