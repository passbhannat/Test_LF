﻿using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using SalesAgreement.Classes;
using System.Linq;
using SalesAgreement.Standard_Forms;

namespace SalesAgreement.Custom_Form
{
    class clsSalesAgreementFreight : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Folder oFolder;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formMenuUID = "SALESAGRFREIGHT";
        const string formTitle = "Sales Agreement Freight";
        public const string matrixUID = "mtxFr";
        public const string rowTable = "QUT3";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btCopyFr")
                            {
                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                SAPbouiCOM.Form oBaseForm = clsVariables.BaseForm;
                                SAPbouiCOM.DBDataSource oFreightDataSource = oBaseForm.DataSources.DBDataSources.Item(clsSalesAggrement.freightrowTable);
                                oFreightDataSource.Clear();
                                int row = 0;
                                double freightTotalAmt = 0;
                                double freightTaxTotalAmt = 0;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    double freightAmt = double.Parse(oDbDataSource.GetValue("LineTotal", i));
                                    double freightTaxAmt = double.Parse(oDbDataSource.GetValue("VatSum", i));
                                    if (freightAmt > 0)
                                    {
                                        oFreightDataSource.InsertRecord(row);
                                        oFreightDataSource.SetValue("U_ExpCode", row, oDbDataSource.GetValue("ExpnsCode", i));
                                        oFreightDataSource.SetValue("U_TaxCode", row, oDbDataSource.GetValue("TaxCode", i));
                                        oFreightDataSource.SetValue("U_TaxRate", row, oDbDataSource.GetValue("VatPrcnt", i));
                                        oFreightDataSource.SetValue("U_TaxSum", row, oDbDataSource.GetValue("VatSum", i));
                                        oFreightDataSource.SetValue("U_NetAmt", row, oDbDataSource.GetValue("LineTotal", i));
                                        oFreightDataSource.SetValue("U_GrAmt", row, oDbDataSource.GetValue("GrsAmount", i));

                                        freightTotalAmt = freightTotalAmt + freightAmt;
                                        freightTaxTotalAmt = freightTaxTotalAmt + freightTaxAmt;
                                        row++;
                                    }
                                }

                                SAPbouiCOM.DBDataSource oHeaderDataSource = oBaseForm.DataSources.DBDataSources.Item(clsSalesAggrement.headerTable);
                                oHeaderDataSource.SetValue("U_Freight", 0, freightTotalAmt.ToString());
                                oHeaderDataSource.SetValue("U_FreightT", 0, freightTaxTotalAmt.ToString());
                                if (oBaseForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oBaseForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                                oForm.Items.Item("2").Click(BoCellClickType.ct_Regular);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_TAX")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("TaxCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue("VatPrcnt", pVal.Row - 1, oDataTable.GetValue("Rate", 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }


                        }
                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (clsVariables.boolCFLSelected)
                            {
                                clsVariables.boolCFLSelected = false;
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                clsVariables.RowNo = 0;
                                clsVariables.ColNo = 0;
                            }
                        }
                        #endregion

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ColUID == "LineTotal")
                            {
                                CalculateTax(pVal.Row);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {

                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID, string cardcode)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("CardCode", BoDataType.dt_LONG_TEXT, 50);
                    oForm.DataSources.UserDataSources.Item("CardCode").ValueEx = cardcode;
                    oMatrix = oForm.Items.Item(matrixUID).Specific;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    oMatrix.CommonSetting.EnableArrowKey = true;
                    oMatrix.AutoResizeColumns();
                    oCombo = oMatrix.GetCellSpecific("ExpCode", 1);
                    objclsCommon.FillCombo(oCombo, "SELECT ExpnsCode ,ExpnsName FROM OEXD ORDER BY ExpnsName");

                    oMatrix.FlushToDataSource();
                    oRs = objclsCommon.returnRecord("SELECT ExpnsCode ,ExpnsName FROM OEXD ORDER BY ExpnsName");
                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                    int rowNo = 0;
                    while (!oRs.EoF)
                    {
                        oDbDataSource.InsertRecord(rowNo);
                        oDbDataSource.SetValue("ExpnsCode", rowNo, oRs.Fields.Item("ExpnsCode").Value);
                        oRs.MoveNext();
                        rowNo++;
                    }
                    oMatrix.LoadFromDataSource();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void CalculateTax(int rowNo)
        {
            oForm = oApplication.Forms.ActiveForm;

            oMatrix = oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

            double taxrate = double.Parse(oDbDataSource.GetValue("VatPrcnt", rowNo - 1));
            double netamt = double.Parse(oDbDataSource.GetValue("LineTotal", rowNo - 1));
            double taxAmt = taxrate * netamt / 100;
            double grossamt = netamt + taxAmt;
            oDbDataSource.SetValue("VatSum", rowNo - 1, taxAmt.ToString());
            oDbDataSource.SetValue("GrsAmount", rowNo - 1, grossamt.ToString());
            oMatrix.LoadFromDataSource();
        }

    }
}
