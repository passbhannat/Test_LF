﻿using SAPbouiCOM;
using System;
using System.Text;
using System.Collections.Generic;
using SalesAgreement.Classes;
using System.Linq;
using SalesAgreement.Standard_Forms;

namespace SalesAgreement.Custom_Form
{
    class clsCopyFromSalesAgreement : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Folder oFolder;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string formMenuUID = "COPYFROMSALESAGR";
        const string formTitle = "Copy From Sales Agreement";
        const string gridDocumentsUID = "grdDoc";
        const string gridItemsUID = "grdItems";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == "btCopy")
                            {
                                SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridItemsUID);
                                List<clsItemEntity> _clsItemEntityList = new List<clsItemEntity>();
                                for (int i = 0; i < dataTable.Rows.Count; i++)
                                {
                                    if (dataTable.GetValue("Selection", i) == "Y")
                                    {
                                        clsItemEntity _clsItemEntity = new clsItemEntity();

                                        _clsItemEntity.LineId = dataTable.GetValue("LineNum", i);
                                        _clsItemEntity.DocEntry = dataTable.GetValue("DocEntry", i);
                                        _clsItemEntity.DocNum = dataTable.GetValue("DocNum", i);
                                        _clsItemEntityList.Add(_clsItemEntity);
                                    }
                                }
                                if (_clsItemEntityList.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("Please select row", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oForm.Items.Item("2").Click(BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = clsVariables.BaseForm;
                                oMatrix = oBaseForm.Items.Item(clsSalesOrder.matrixUID).Specific;
                                int rowNo = 1;
                                int firstDocEntry = 0;
                                for (int i = 0; i < _clsItemEntityList.Count; i++)
                                {
                                    int lineId = _clsItemEntityList[i].LineId;
                                    int docEntry = _clsItemEntityList[i].DocEntry;
                                    int docNum = _clsItemEntityList[i].DocNum;
                                    if (i == 0)
                                    {
                                        firstDocEntry = docEntry;
                                    }
                                    oRs = objclsCommon.returnRecord("SELECT * FROM \"" + clsSalesAggrement.rowTable + "\" WHERE DocEntry = '" + docEntry + "' AND LineId='" + lineId + "'");

                                    if (!oRs.EoF)
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", rowNo)).String = oRs.Fields.Item("U_ItemCode").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", rowNo)).String = oRs.Fields.Item("U_OpenQty").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", rowNo)).String = oRs.Fields.Item("U_WhsCode").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("14", rowNo)).String = oRs.Fields.Item("U_Price").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("15", rowNo)).String = oRs.Fields.Item("U_DiscPer").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("160", rowNo)).String = oRs.Fields.Item("U_TaxCode").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PackDesc", rowNo)).String = oRs.Fields.Item("U_PackDesc").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRWT", rowNo)).String = oRs.Fields.Item("U_GRWT").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_AddDescp", rowNo)).String = oRs.Fields.Item("U_AddDescp").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SRNO", rowNo)).String = oRs.Fields.Item("U_SRNO").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NeWt", rowNo)).String = oRs.Fields.Item("U_NeWt").Value.ToString();
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("2", rowNo)).String = oRs.Fields.Item("U_BPCatNo").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10002037", rowNo)).String = oRs.Fields.Item("U_DistRule").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("31", rowNo)).String = oRs.Fields.Item("U_Project").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("163", rowNo)).String = oRs.Fields.Item("U_FreeText").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1980000354", rowNo)).String = oRs.Fields.Item("U_LegText").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PONum", rowNo)).String = oRs.Fields.Item("U_PONum").Value.ToString(); } catch { }
                                        try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PUOM", rowNo)).String = oRs.Fields.Item("U_PUOM").Value.ToString(); } catch { }

                                        //Add Fields
                                        rowNo++;

                                    }

                                }
                                DateTime date;
                                string datevalue="";
                                oRs = objclsCommon.returnRecord("SELECT * FROM \"" + clsSalesAggrement.headerTable + "\" WHERE DocEntry = '" + firstDocEntry + "' ");
                                if (!oRs.EoF)
                                {
                                    #region Logistics
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("92", rowNo)).String = oRs.Fields.Item("U_Address2").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("6", rowNo)).String = oRs.Fields.Item("U_Address").Value.ToString(); } catch { }

                                    //oDbDataSource.SetValue("U_Trnsp", 0, oRs.Fields.Item("TrnspCode").Value);
                                    //oDbDataSource.SetValue("U_LangCode", 0, oRs.Fields.Item("LangCode").Value);
                                    //oDbDataSource.SetValue("U_UseBill", 0, oRs.Fields.Item("UseBilAddr").Value);
                                    //oDbDataSource.SetValue("U_ProPres", 0, oRs.Fields.Item("PoPrss").Value);
                                    //oDbDataSource.SetValue("U_ProDrop", 0, oRs.Fields.Item("PoDropPrss").Value);
                                    //oDbDataSource.SetValue("U_BPCh", 0, oRs.Fields.Item("BPChCode").Value);
                                    //oCombo = oForm.Items.Item("U_BPChCnt").Specific;
                                    //objclsCommon.FillCombo(oCombo, objclsCommon.FillContactPersonQuery(oRs.Fields.Item("BPChCode").Value));

                                    //oDbDataSource.SetValue("U_BPChCnt", 0, oRs.Fields.Item("BPChCntc").Value);

                                    #endregion

                                    #region UDF
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EMD", rowNo)).String = oRs.Fields.Item("U_EMD").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EMDDate", rowNo)).String = oRs.Fields.Item("U_EMDDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EMDDate", rowNo)).String = oRs.Fields.Item("U_EMDDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EMDAmt", rowNo)).String = oRs.Fields.Item("U_EMDAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EMDValid", rowNo)).String = oRs.Fields.Item("U_EMDValid").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EMDDetails", rowNo)).String = oRs.Fields.Item("U_EMDDetails").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EMDRDate", rowNo)).String = oRs.Fields.Item("U_EMDRDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LCNo", rowNo)).String = oRs.Fields.Item("U_LCNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LCSDate", rowNo)).String = oRs.Fields.Item("U_LCSDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LCEDate", rowNo)).String = oRs.Fields.Item("U_LCEDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LCAMT", rowNo)).String = oRs.Fields.Item("U_LCAMT").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Purchase", rowNo)).String = oRs.Fields.Item("U_Purchase").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Overhead", rowNo)).String = oRs.Fields.Item("U_Overhead").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_DeliveryTerm", rowNo)).String = oRs.Fields.Item("U_DeliveryTerm").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_OffeNo", rowNo)).String = oRs.Fields.Item("U_OffeNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PaymentTerm", rowNo)).String = oRs.Fields.Item("U_PaymentTerm").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Insurance", rowNo)).String = oRs.Fields.Item("U_Insurance").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ConPF", rowNo)).String = oRs.Fields.Item("U_ConPF").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_VehicleNo", rowNo)).String = oRs.Fields.Item("U_VehicleNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NoofPack", rowNo)).String = oRs.Fields.Item("U_NoofPack").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRNo", rowNo)).String = oRs.Fields.Item("U_LRNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Location", rowNo)).String = oRs.Fields.Item("U_Location").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_REVNO", rowNo)).String = oRs.Fields.Item("U_REVNO").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_REVDATE", rowNo)).String = oRs.Fields.Item("U_REVDATE").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PriceBasis", rowNo)).String = oRs.Fields.Item("U_PriceBasis").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PackDetails", rowNo)).String = oRs.Fields.Item("U_PackDetails").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Returnable", rowNo)).String = oRs.Fields.Item("U_Returnable").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_RMName", rowNo)).String = oRs.Fields.Item("U_RMName").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Owner_IT", rowNo)).String = oRs.Fields.Item("U_Owner_IT").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Note", rowNo)).String = oRs.Fields.Item("U_Note").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Shippedper", rowNo)).String = oRs.Fields.Item("U_Shippedper").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BOLNo", rowNo)).String = oRs.Fields.Item("U_BOLNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SBNo", rowNo)).String = oRs.Fields.Item("U_SBNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PortS", rowNo)).String = oRs.Fields.Item("U_PortS").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PordD", rowNo)).String = oRs.Fields.Item("U_PordD").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FinalD", rowNo)).String = oRs.Fields.Item("U_FinalD").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ShipingMasrks", rowNo)).String = oRs.Fields.Item("U_ShipingMasrks").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CaseNo", rowNo)).String = oRs.Fields.Item("U_CaseNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_NETWT", rowNo)).String = oRs.Fields.Item("U_NETWT").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ORIGIN", rowNo)).String = oRs.Fields.Item("U_ORIGIN").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Type", rowNo)).String = oRs.Fields.Item("U_Type").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Packing", rowNo)).String = oRs.Fields.Item("U_Packing").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ContainerNo", rowNo)).String = oRs.Fields.Item("U_ContainerNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SealNo", rowNo)).String = oRs.Fields.Item("U_SealNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_GRWT", rowNo)).String = oRs.Fields.Item("U_GRWT").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CARBOYS", rowNo)).String = oRs.Fields.Item("U_CARBOYS").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ShipBillNo", rowNo)).String = oRs.Fields.Item("U_ShipBillNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ShipBillDate", rowNo)).String = oRs.Fields.Item("U_ShipBillDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_DrwbkAmt", rowNo)).String = oRs.Fields.Item("U_DrwbkAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CompositeContract", rowNo)).String = oRs.Fields.Item("U_CompositeContract").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Composite", rowNo)).String = oRs.Fields.Item("U_Composite").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Documents", rowNo)).String = oRs.Fields.Item("U_Documents").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_po_loi_basic_rate", rowNo)).String = oRs.Fields.Item("U_po_loi_basic_rate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_eway_bill_no", rowNo)).String = oRs.Fields.Item("U_eway_bill_no").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_eway_bill_date", rowNo)).String = oRs.Fields.Item("U_eway_bill_date").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_To", rowNo)).String = oRs.Fields.Item("U_To").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_CC", rowNo)).String = oRs.Fields.Item("U_CC").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BCC", rowNo)).String = oRs.Fields.Item("U_BCC").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_contact_person_at_factory", rowNo)).String = oRs.Fields.Item("U_contact_person_at_factory").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ShopOrderNo", rowNo)).String = oRs.Fields.Item("U_ShopOrderNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Plant", rowNo)).String = oRs.Fields.Item("U_Plant").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ChallanDate2", rowNo)).String = oRs.Fields.Item("U_ChallanDate2").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_AmendmentNo", rowNo)).String = oRs.Fields.Item("U_AmendmentNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_AmendmentDate", rowNo)).String = oRs.Fields.Item("U_AmendmentDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRDate", rowNo)).String = oRs.Fields.Item("U_LRDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TransporterBillNo", rowNo)).String = oRs.Fields.Item("U_TransporterBillNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TransporterBillDate", rowNo)).String = oRs.Fields.Item("U_TransporterBillDate").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TransporterBillAmt", rowNo)).String = oRs.Fields.Item("U_TransporterBillAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_IGST", rowNo)).String = oRs.Fields.Item("U_IGST").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SupplyType", rowNo)).String = oRs.Fields.Item("U_SupplyType").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SignAdd", rowNo)).String = oRs.Fields.Item("U_SignAdd").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LogoRequire", rowNo)).String = oRs.Fields.Item("U_LogoRequire").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PaymentTerm_1", rowNo)).String = oRs.Fields.Item("U_PaymentTerm_1").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PaymentTerm_2", rowNo)).String = oRs.Fields.Item("U_PaymentTerm_2").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PaymnetTerm_3", rowNo)).String = oRs.Fields.Item("U_PaymnetTerm_3").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EPC_ReceivedAmt", rowNo)).String = oRs.Fields.Item("U_EPC_ReceivedAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EPC_ClaimAmt", rowNo)).String = oRs.Fields.Item("U_EPC_ClaimAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EPC_PendingAmt", rowNo)).String = oRs.Fields.Item("U_EPC_PendingAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ChallanDate1", rowNo)).String = oRs.Fields.Item("U_ChallanDate1").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BillToID", rowNo)).String = oRs.Fields.Item("U_BillToID").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_ShiplToID", rowNo)).String = oRs.Fields.Item("U_ShiplToID").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PaymnetTerm_4", rowNo)).String = oRs.Fields.Item("U_PaymnetTerm_4").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EPC_PendingAmt1", rowNo)).String = oRs.Fields.Item("U_EPC_PendingAmt1").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SignAddP", rowNo)).String = oRs.Fields.Item("U_SignAddP").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_SDATE", rowNo)).String = oRs.Fields.Item("U_SDATE").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EDATE", rowNo)).String = oRs.Fields.Item("U_EDATE").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Vehicle_Capacity", rowNo)).String = oRs.Fields.Item("U_Vehicle_Capacity").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FreightAmount", rowNo)).String = oRs.Fields.Item("U_FreightAmount").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FreightCostActual", rowNo)).String = oRs.Fields.Item("U_FreightCostActual").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PrintType", rowNo)).String = oRs.Fields.Item("U_PrintType").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PaymnetTerm_5", rowNo)).String = oRs.Fields.Item("U_PaymnetTerm_5").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_EPC_PendingAmt3", rowNo)).String = oRs.Fields.Item("U_EPC_PendingAmt3").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LRReceived", rowNo)).String = oRs.Fields.Item("U_LRReceived").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_PODis", rowNo)).String = oRs.Fields.Item("U_PODis").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BGRequire", rowNo)).String = oRs.Fields.Item("U_BGRequire").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BGPersantage", rowNo)).String = oRs.Fields.Item("U_BGPersantage").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LCRequired", rowNo)).String = oRs.Fields.Item("U_LCRequired").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BGNo", rowNo)).String = oRs.Fields.Item("U_BGNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BGDt", rowNo)).String = oRs.Fields.Item("U_BGDt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BGAmt", rowNo)).String = oRs.Fields.Item("U_BGAmt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_AmdNo", rowNo)).String = oRs.Fields.Item("U_AmdNo").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_AmdDt", rowNo)).String = oRs.Fields.Item("U_AmdDt").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BGExp", rowNo)).String = oRs.Fields.Item("U_BGExp").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BGClaim", rowNo)).String = oRs.Fields.Item("U_BGClaim").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FDRNO", rowNo)).String = oRs.Fields.Item("U_FDRNO").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FDRDATE", rowNo)).String = oRs.Fields.Item("U_FDRDATE").Value.ToString(); } catch { }
                                    try { ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_FDRAMT", rowNo)).String = oRs.Fields.Item("U_FDRAMT").Value.ToString(); } catch { }


                                    #endregion


                                }
                            }

                            else if (pVal.ItemUID == "btNext")
                            {
                                SAPbouiCOM.DataTable dataTable = oForm.DataSources.DataTables.Item(gridDocumentsUID);
                                List<string> list = new List<string>();
                                for (int i = 0; i < dataTable.Rows.Count; i++)
                                {
                                    string chk = dataTable.GetValue("Selection", i);
                                    if (chk == "Y")
                                    {
                                        list.Add(dataTable.GetValue("DocEntry", i).ToString());
                                    }
                                }
                                string sodocentry = String.Join(",", list);
                                FillItemGrid(sodocentry);
                                oFolder = oForm.Items.Item("fld2").Specific;
                                oFolder.Select();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "btCopyFrom")
                            {

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID, "");
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        #endregion

        public void LoadForm(string menuID, string cardcode)
        {
            try
            {
                if (menuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(menuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(menuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("CardCode", BoDataType.dt_LONG_TEXT, 50);
                    oForm.DataSources.UserDataSources.Item("CardCode").ValueEx = cardcode;
                    oFolder = oForm.Items.Item("fld1").Specific;
                    oFolder.Select();
                    FillGrid();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void FillGrid()
        {
            oForm = oApplication.Forms.ActiveForm;
            string cardcode = oForm.DataSources.UserDataSources.Item("CardCode").ValueEx;
            sbQuery.Length = 0;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append("call PROC_COPY_FROM_ARC ('" + cardcode + "')");
            }
            else
            {
                //sbQuery.Append("EXEC PROC_COPY_FROM_ARC '" + cardcode + "' ");
                sbQuery.Append("SELECT 'N' AS 'Selection',DocEntry,DocNum,U_DocDate AS DocDate,U_CardCode AS CardCode,U_CardName CardName,U_NumAtCa 'Customer Ref No.'FROM \"" + clsSalesAggrement.headerTable + "\" WHERE U_Status = 'O' AND U_CardCode='" + cardcode + "' ");
            }
            objclsCommon.FillGrid(oForm.UniqueID, gridDocumentsUID, gridDocumentsUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridDocumentsUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;
        }

        private void FillItemGrid(string docentry)
        {
            oForm = oApplication.Forms.ActiveForm;
            sbQuery.Length = 0;
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
            }
            else
            {
                sbQuery.Append(" SELECT 'N' AS 'Selection',U_ItemCode AS ItemCode ,U_ItemName as ItemName,U_Qty as Quantity,U_OpenQty AS OpenQty,T1.DocEntry,T2.DocNum,T1.LineId as LineNum ");
                sbQuery.Append(" FROM \"" + clsSalesAggrement.rowTable + "\" T1 ");
                sbQuery.Append(" INNER JOIN \"" + clsSalesAggrement.headerTable + "\" T2 ON T1.DocEntry = T2.DocEntry ");
                sbQuery.Append(" WHERE T2.U_Status = 'O' AND T2.DocEntry  in (" + docentry + ") ");
                sbQuery.Append(" AND T1.U_ItemCode IS NOT NULL AND T1.U_OpenQty > 0 ");
            }
            objclsCommon.FillGrid(oForm.UniqueID, gridItemsUID, gridItemsUID, sbQuery.ToString());
            SAPbouiCOM.Grid oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridItemsUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
                oGrid.Columns.Item(i).TitleObject.Sortable = true;
            }
            oGrid.Columns.Item(0).Type = BoGridColumnType.gct_CheckBox;
        }
    }
}
